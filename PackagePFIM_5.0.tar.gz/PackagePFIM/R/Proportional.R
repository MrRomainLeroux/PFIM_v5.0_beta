##################################################################################
##' Class "Proportional"
##'
##' @description ...
##'
##' @name Proportional-class
##' @aliases Proportional
##' @docType class
##' @include Combined1.R
##' @exportClass Proportional
##'
##' @section Objects from the Class: Proportional objects
##' are typically created by calls to \code{{...}} and contain the following slots
##' that are heritated from the class Combined1:
##'
#' @section Slots for the \code{Proportional} objects:
#' \describe{
#' \item{\code{sigma_inter}:}{}
#' \item{\code{sigma_slope}:}{}
#' }

Proportional<-setClass(
  Class="Proportional",
  contains = "Combined1",
  validity=function(object)
  {
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f="initialize",
  signature="Proportional",
  definition= function (.Object, sigma_slope)
  {
    sigma_inter = 0
    # Object validation
    validObject(.Object)
    .Object = callNextMethod(.Object, sigma_inter, sigma_slope)
    return (.Object )
  }
)


