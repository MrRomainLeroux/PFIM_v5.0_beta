#################################################################################
#' Class "PFIM"
#'
#' @description
#' The Class "PFIM" implements the evaluation of the Fisher Information Matrix through the use
#' of a statistical model. This classe also plot the graphic for the evolution over time of the
#' conventraton, the sensitivity indices and the standard errors (SE, RSE)of a model.
#'
#' @name PFIM-class
#' @aliases PFIM
#' @docType class
#' @include StatisticalModel.R
#' @exportClass PFIM
#'
#' @section Objects from the Class PFIM:
#' Objects form the Class \code{PFIM} can be created by calls of the form \code{PFIM(...)} where
#' (...) are the parameters for the \code{PFIM} objects.
#'
#'@section Slots for the \code{PFIM} objects:
#' \describe{
#' \item{\code{name}:}{A character strings giving the name of the project.}
#' \item{\code{previous_fim}:}{A matrix of numerical values giving the information matrix obtained from a previous study.}
#' \item{\code{fim}:}{A list of Fims (population or individual or Bayesian information).}
#' \item{\code{statistical_model}:}{A list of StatisticalModels or ODEStatisticalModels.}
#' \item{\code{designs}:}{A list of all designs.}
#' \item{\code{constraints}:}{design constraint.}
#' \item{\code{graph_options}:}{List of graphical options.}
#' }
#'
#'
PFIM<-setClass(
  Class="PFIM",
  representation=representation(
    name = "character",
    previous_fim = "list",
    fim = "list",
    statistical_model = "StatisticalModel",
    designs = "list",
    constraint = "DesignConstraint",
    graph_options = "list"
  ),
  prototype=prototype(#default options
    name = "MyPFIMproject",
    previous_fim = list(new(Class = "Fim")),
    fim = list(new(Class = "Fim")),
    designs = list(),
    graph_options = list()
  ),
  validity=function(object)
  {
    if(is(object@previous_fim, "Fim")==TRUE)
      stop("All elements of the slot previous_fim have to be of type Fim or its subclasses")
    if(any(lapply(object@designs, class)!="Design"))
      stop("All elements of the slot design have to be of type Design")
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f = "initialize",
  signature = "PFIM",
  definition = function(.Object, name, previous_fim, fim, statistical_model,
                        designs, constraint, graph_options, computeFIM)
  {
    if(!missing(name))
      .Object@name <- name
    if(!missing(previous_fim))
      .Object@previous_fim <- previous_fim
    if(!missing(fim))
      .Object@fim <- fim
    if(!missing(statistical_model))
      .Object@statistical_model <- statistical_model
    if(!missing(designs))
      .Object@designs <- designs
    if(!missing(constraint))
      .Object@constraint <- constraint
    if(!missing(graph_options))
      .Object@graph_options <- graph_options
    validObject(.Object)
    return(.Object)
  }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the name of a PFIM project.
#' @name getNamePFIM
#' @param object A \code{PFIM} object.
#' @return The character string \code{name} giving the name of a PFIM project.

setGeneric("getNamePFIM",
           function(object)
           {
             standardGeneric("getNamePFIM")
           })

setMethod("getNamePFIM",
          "PFIM",
          function(object)
          {
            return(object@name)
          })

# -------------------------------------------------------------------------------------------------------------------
#' Set the name of a PFIM projet.
#' @name setNamePFIM<-
#' @param object A \code{PFIM} object.
#' @param value A character string.
#' @return The \code{PFIM} object with a new name.

setGeneric("setNamePFIM<-",
           function(object, value)
           {
             standardGeneric("setNamePFIM<-")
           })

setReplaceMethod( f="setNamePFIM",
                  signature="PFIM",
                  definition = function(object, value)
                  {
                    object@name <- value
                    validObject(object)
                    return(object)
                  })

# -------------------------------------------------------------------------------------------------------------------
#' Get the Fisher Information Matrices.
#' @name getFims
#' @param object A \code{PFIM} object.
#' @return A list \code{fimList} giving the Fisher Information Matrices for all the designs of a PFIM project.

setGeneric("getFims",
           function(object)
           {
             standardGeneric("getFims")
           })

setMethod("getFims",
          "PFIM",
          function(object)
          {
            fimList = list()
            for(design in object@designs)
              fimList[[ getNameDesign(design) ]] = getFimOfDesign( design )
            return( fimList )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the Fisher Information Matrix.
#' @name getFims
#' @param object A \code{PFIM} object.
#' @param index index
#' @return A \code{Fim} object giving the Fisher Information Matrix of a design.

setGeneric("getFim",
           function(object, index)
           {
             standardGeneric("getFim")
           })

setMethod("getFim",
          "PFIM",
          function(object, index=1 )
          {
            design = object@designs[[ index ]]
            return( getFimOfDesign( design )  )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the fims matrices from all designs of a PFIM object.
#' @name getFisherMatrices
#' @param object A \code{PFIM} object.
#' @return A list of matrices \code{fimList} giving the Fisher Information Matrix of all the designs of a PFIM project.

setGeneric("getFisherMatrices",
           function(object)
           {
             standardGeneric("getFisherMatrices")
           }
)

setMethod("getFisherMatrices",
          "PFIM",
          function(object)
          {
            fimList = list()
            for(design in object@designs)
              fimList[[ getNameDesign(design) ]] = getMfisher( getFimOfDesign( design ) )
            return( fimList )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the previous Fisher Information Matrix of a PFIM object.
#' @name getPreviousFim
#' @param object A \code{PFIM} object.
#' @return A list \code{previous_fim} of matrices of numerical values giving the information matrices obtained from a previous study.

setGeneric("getPreviousFim",
           function(object)
           {
             standardGeneric("getPreviousFim")
           }
)

setMethod("getPreviousFim",
          "PFIM",
          function(object)
          {
            return(object@previous_fim)
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Set the previous Fisher Information Matrix of a PFIM object.
#' @param object A \code{PFIM} object.
#' @param value A Matrix of numerical values.
#' @return The \code{PFIM} object with a new previous Fisher Information Matrix.

setGeneric("setPreviousFim<-",
           function(object, value)
           {
             standardGeneric("setPreviousFim<-")
           }
)

setReplaceMethod( f="setPreviousFim",
                  signature="PFIM",
                  definition = function(object, value)
                  {
                    object@previous_fim <- value
                    validObject(object)
                    return(object)
                  }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the \code{StatisticalModel} object of the PFIM object.
#' @name getStatisticalModel
#' @param object A \code{PFIM} object.
#' @return Return the object \code{statistical_model} of the \linkS4class{StatisticalModel} of the PFIM object.

setGeneric("getStatisticalModel",
           function(object)
           {
             standardGeneric("getStatisticalModel")
           }
)

setMethod("getStatisticalModel",
          "PFIM",
          function(object)
          {
            return(object@statistical_model)
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Define the \code{StatisticalModel} object of the PFIM object.
#' @name defineStatisticalModel
#' @param object A \code{PFIM} object.
#' @param value A \code{StatisticalModel} or \code{ODEStatisticalModel} object.
#' @return The \code{StatisticalModel} object of the PFIM object.
#

setGeneric("defineStatisticalModel",
           function(object, value)
           {
             standardGeneric("defineStatisticalModel")
           }
)

setMethod( f="defineStatisticalModel",
           signature="PFIM",
           definition = function(object, value)
           {
             object@statistical_model <- value
             validObject(object)
             return(object)
           }
)

# -------------------------------------------------------------------------------------------------------------------
#' Add a design to the PFIM project.
#' @name addDesign
#' @param object A \code{PFIM} object.
#' @param value A \code{Design} object.
#' @return The \code{PFIM} object with the \code{Design} object added.

setGeneric("addDesign",
           function(object, value)
           {
             standardGeneric("addDesign")
           }
)

setMethod( f="addDesign",
           signature="PFIM",
           definition = function(object, value)
           {
             object@designs[[ getNameDesign( value ) ]] <- value
             validObject(object)
             return(object)
           }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the design of \code{PFIM} object.
#' @name getDesign
#' @param object \code{PFIM} object.
#' @return The list \code{design} of the designs in the \code{PFIM} object.

setGeneric("getDesign",
           function(object)
           {
             standardGeneric("getDesign")
           }
)

setMethod("getDesign",
          "PFIM",
          function(object)
          {
            return(object@designs)
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Set the design of \code{PFIM} object.
#' @name setDesign
#' @param object A \code{PFIM} object.
#' @param value A \code{Design} object.
#' @return The \code{PFIM} object with the list of the new \code{Designs}.

setGeneric("setDesign",
           function(object,value)
           {
             standardGeneric("setDesign")
           }
)

setMethod("setDesign",
          "PFIM",
          function(object,value)
          {
            object@designs<- value
            validObject(object)
            return(object)
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Set the constraint to the PFIM projet.
#' @name setConstraint
#' @param object A \code{PFIM} object.
#' @param constraint The constraint to set
#' @return The \code{PFIM} object with the \code{constraint} sat

setGeneric("setConstraint",
           function(object, constraint)
           {
             standardGeneric("setConstraint")
           }
)

setMethod( f="setConstraint",
           signature="PFIM",
           definition = function(object, constraint)
           {
             object@constraint <- constraint
             validObject(object)
             return(object)
           }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the graph options.
#' @name getGraphOptions
#' @param object \code{PFIM} object.
#' @return A character string \code{graph_options} giving the graph options.

setGeneric("getGraphOptions",
           function(object)
           {
             standardGeneric("getGraphOptions")
           }
)

setMethod("getGraphOptions",
          "PFIM",
          function(object)
          {
            return(object@graph_options)
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Set the graph options.
#' @param object A \code{PFIM} object.
#' @param value  A character strings giving the parameters for the graph options.
#' @return The \code{PFIM} object with the graph options.

setGeneric("setGraphOptions<-",
           function(object, value)
           {
             standardGeneric("setGraphOptions<-")
           }
)

setReplaceMethod( f="setGraphOptions",
                  signature="PFIM",
                  definition = function(object, value)
                  {
                    object@graph_options <- value
                    validObject(object)
                    return(object)
                  }
)

# -------------------------------------------------------------------------------------------------------------------
#' Evaluate the design for each arm.
#' @name EvaluateDesign
#' @param object A \code{PFIM} object.
#' @param fimType A character string giving the type of FIM: "Population", "Individual" or "Bayesian".
#' @param TheDesign  A \code{Design} object to be evaluated.
#' @return The \code{PFIM} object with the list \code{designs} that contains the evaluation of each design for each arm.

setGeneric("EvaluateDesign",
           function(object, fimType, TheDesign)
           {
             standardGeneric("EvaluateDesign")
           }
)

setMethod(f="EvaluateDesign",
          signature=  "PFIM",
          definition=function( object, fimType, TheDesign )
          {

            if(!missing(TheDesign))
            {
              evaluatedDesign = EvaluateDesignForEachArm( TheDesign , object@statistical_model, fimType)

              object@designs[[ getNameDesign(TheDesign) ]] <- evaluatedDesign
            }
            else  ###Just print all FIMs of design, no return( MF_i_total )
            {

              for ( design in object@designs )
              {
                evaluatedDesign = EvaluateDesignForEachArm( design, object@statistical_model, fimType)
                object@designs[[ getNameDesign(design) ]] <- evaluatedDesign
              }
            }
            return( object )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Evaluate a design for each arm for a Population FIM.
#' @name EvaluatePopulationFIM
#' @param object A \code{PFIM} object.
#' @return The \code{PFIM} object with the list \code{designs} that contains the evaluation of the Population FIM of each design for each arm.

setGeneric("EvaluatePopulationFIM",
           function(object )
           {
             standardGeneric("EvaluatePopulationFIM")
           }
)

setMethod(f="EvaluatePopulationFIM",
          signature=  "PFIM",
          definition=function( object )
          {

            for ( design in object@designs )
            {

              evaluatedDesign = EvaluateDesignForEachArm( design, object@statistical_model, PopulationFim() )
              object@designs[[ getNameDesign(design) ]] <- evaluatedDesign
            }
            return( object )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Evaluate design for each arm for a Bayesian FIM.
#' @name EvaluateBayesianFIM
#' @param object A \code{PFIM} object.
#' @return The \code{PFIM} object with the list \code{designs} that contains the evaluation of the Bayesian FIM of each design for each arm.

setGeneric("EvaluateBayesianFIM",
           function(object)
           {
             standardGeneric("EvaluateBayesianFIM")
           })

setMethod(f="EvaluateBayesianFIM",
          signature=  "PFIM",
          definition=function( object )
          {
            for ( design in object@designs )
            {
              evaluatedDesign = EvaluateDesignForEachArm( design, object@statistical_model, BayesianFim() )
              object@designs[[ getNameDesign(design) ]] <- evaluatedDesign
            }
            return( object )
          })

# -------------------------------------------------------------------------------------------------------------------
#' Evaluate design for each arm for a Individual FIM
#' @name EvaluateIndividualFIM
#' @param object \code{PFIM} object.
#' @return The \code{PFIM} object with the list \code{designs} that contains the evaluation of the Individual FIM of each design for each arm.

setGeneric("EvaluateIndividualFIM",
           function(object)
           {
             standardGeneric("EvaluateIndividualFIM")
           }
)

setMethod(f="EvaluateIndividualFIM",
          signature=  "PFIM",
          definition=function( object )
          {

            for ( design in object@designs )
            {
              evaluatedDesign = EvaluateDesignForEachArm( design, object@statistical_model, IndividualFim() )
              object@designs[[ getNameDesign(design) ]] <- evaluatedDesign
            }
            return( object )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Optimize the designs for each arms.
#' @name OptimizeDesign
#' @param object A \code{PFIM} object.
#' @param optimizer A \code{Optimization} object.
#' @param fim A character string giving the type of Fisher Information Matrix (Population, Indidivual or Bayesian).
#' @param theConstraint A \code{Constraint} object.
#' @return The \code{PFIM} object with the optimised designs for each arms.

setGeneric("OptimizeDesign",
           function(object, optimizer, fim )
           {
             standardGeneric("OptimizeDesign")
           }
)

setMethod(f = "OptimizeDesign",
          signature = "PFIM",
          definition = function( object, optimizer, fim )
          {
            # warning : Refaire le code pour la proportion de sujets dans l'algo multiplicatif.

            theConstraint = object@constraint

            # cond init
            cond_init = list()

            for ( design in  object@designs ){
              for ( arm in design@arms ){

                cond_init = append( cond_init, getCondInit( arm ) )

              }}


            OptimizationResult <- Optimize(optimizer, object, object@designs, object@statistical_model, cond_init, theConstraint, fim)

            evaluatedDesign = EvaluateDesignForEachArm(OptimizationResult@OptimalDesign, object@statistical_model, fim)

            evaluatedDesign@optimizationResult <- OptimizationResult

            object <- addDesign(object, evaluatedDesign)

            return(object)
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Show the Fisher Information Matrix for all the designs.
#' @name showFims
#' @param object A \code{PFIM} object.
#' @return Show the Fisher Information Matrix \code{fimOfDesign} for all the designs.

setGeneric("showFims",
           function(object)
           {
             standardGeneric("showFims")
           }
)

setMethod(f = "showFims",
          signature = "PFIM",
          definition = function(object)
          {
            for(design in object@designs)
            {
              cat("\n FIM evaluated for design: ", getNameDesign(design), "\n")
              show(design@fimOfDesign)
            }
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Show the all the Designs.
#' @name showDesigns
#' @param object A \code{PFIM} object.
#' @return Show all the design \code{designs} in the \code{PFIM} object.)

setGeneric("showDesigns",
           function(object)
           {
             standardGeneric("showDesigns")
           }
)

setMethod(f = "showDesigns",
          signature = "PFIM",
          definition = function(object)
          {
            for(design in object@designs)
            {
              show(design)
              cat("\n\n\n")
            }
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Show all the constraints.
#' @name showConstraints
#' @param object \code{PFIM} object.
#' @return Show the all the objects \code{Constraints} in the \code{PFIM} object.

setGeneric("showConstraints",
           function(object)
           {
             standardGeneric("showConstraints")
           }
)

setMethod(f = "showConstraints",
          signature = "PFIM",
          definition = function(object)
          {

            show( object@constraint )
            cat("\n\n\n")

          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Show the content of a PFIM \code{PFIM} object.
#' @name show
#' @param object A \code{PFIM} object.
#' @return Show the content of the PFIM \code{PFIM} object : Statistical Model, Constraints, Fim of optimal design, Determinant, D-criterion, Eigenvalues.

setMethod("show",
          signature = "PFIM",
          definition = function( object )
          {
            parameters <- getModelParameters(object@statistical_model)
            lengthParameters <- length(parameters)

            cat("*********************** Name of project  ******************************\n")

            cat( "\n", object@name, "\n\n")

            show( object@statistical_model )

            cat( "\n\n")

            # cat("*********************** Constraint  ******************************\n")
            # print( object@constraint )

            # ------------------------------------------------------------------------
            # Designs
            # ------------------------------------------------------------------------

            #optimalDesign = getDesign( object )

            for(design in object@designs)
            {

              show(design)

              if(dim(getMfisher(design@fimOfDesign))[1] > 0)
              {
                fim <- design@fimOfDesign

                fimOfDesignOptimal <- getMfisher(fim)

                cat ( "\n ", getDescription( fim ), "\n " )

                print( fimOfDesignOptimal )

                cat("\n Determinant\n", getDeterminant(fim), "\n")

                cat("\n D-criterion\n", getDcriterion(fim), "\n")

                cat("\n Eigenvalues\n")
                print(getEigenValue( fim ))

                conditionNumbers <-getConditionNumberMatrix( fim, lengthParameters )

                seFrameOfStatisticalModelParameters <- showStatisticalModelStandardErrors( fim, parameters )

                seFrameOfErrorModelParameters <- showErrorModelStandardErrors( object@statistical_model, fim )

              }
            }

          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Summary of the PFIM \code{PFIM} object.
#' @name summary
#' @param object \code{PFIM} object.
#' @return Summary of the PFIM \code{PFIM} object given by the:
#' PopulationFim, IndividualFim, Fim, Determinant, Dcriterion,
#' Eigenvalues, SEfixedEffects,
#' SEstandardDeviationOfRandomEffect, SEerrorModel, Designs

setMethod("summary",
          "PFIM",
          function(object)
          {

            parameters <- getModelParameters(object@statistical_model)
            lengthParameters <- length(parameters)
            i = 0
            DesignAndFims <- list()
            for(design in object@designs)
            {
              i = i + 1
              DesignAndFim<- summary(design)
              if(dim(getMfisher(design@fimOfDesign))[1] > 0)
              {
                fim <- design@fimOfDesign
                fimOfDesignOptimal <- getMfisher(fim)

                if(is(fim,"PopulationFim"))
                  DesignAndFim[["PopulationFisherInformationMatrix "]] <- fimOfDesignOptimal
                else
                  if(is(fim,"IndividualFim"))
                    DesignAndFim[["IndividualFisherInformationMatrix "]] <- fimOfDesignOptimal
                else
                  DesignAndFim[["FisherInformationMatrix "]] <- fimOfDesignOptimal

                DesignAndFim[["Determinant"]] <- getDeterminant(fim)

                DesignAndFim[["Dcriterion"]] <- getDcriterion(fim)


                conditionNumbers <-getConditionNumberMatrix(fim, lengthParameters)
                DesignAndFim[["Eigenvalues"]] <- conditionNumbers

                seFrameOfStatisticalModelParameters <- getStatisticalModelStandardErrors(fim, parameters)
                seFrameOfErrorModelParameters <- getErrorModelStandardErrors(object@statistical_model, fim)

                DesignAndFim[["SEfixedEffects"]] <- seFrameOfStatisticalModelParameters$fixed

                if( is(fim,"PopulationFim"))
                  DesignAndFim[["SEstandardDeviationOfRandomEffect"]] <- seFrameOfStatisticalModelParameters$random

                DesignAndFim[["SEerrorModel"]] <- seFrameOfErrorModelParameters

              }

              DesignAndFims[[paste0("design_",i)]] <- DesignAndFim
            }
            x = summaryPFIM()
            x@name = object@name
            x@designs = DesignAndFims
            x
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the weights for the optimal designs.
#' @name getWeights
#' @param object A \code{PFIM} object.
#' @return A data frame \code{weights} giving the weights of the optimal designs.

setGeneric("getWeights",
           function(object)
           {
             standardGeneric("getWeights")
           }
)

setMethod("getWeights",
          signature = "PFIM",
          definition = function(object)
          {
            weights <- list()
            for(design in object@designs)
            {
              tryCatch({
                w<-getWeightFrame(design@optimizationResult)

                weights[[length(weights)+1]] <- w
              }, error=function(e){cat("\n Impossible to get weights.\n")}

              )
            }
            return(weights)
          }
)

# --------------------------------------------------------------------------------------------------------------------------------

# Plot Results

# --------------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------
#' Plot the d criteria over time.
#' @name plotCriteria
#' @param object \code{PFIM} object.
#' @param ... A list giving the plot options.
#' @return A plot of the d criteria over time for a Design optimization.

setGeneric(
  "plotCriteria",
  function(object,...) {
    standardGeneric("plotCriteria")
  })

setMethod(f="plotCriteria",
          signature("PFIM"),

          function(object,...){


            optimalDesign = getDesign( object )
            optimizationResult = getOptimizationResult( optimalDesign[[1]] )
            results = optimizationResult@resultsOptimization
            maxIter = optimizationResult@maxIteration
            results = do.call(cbind, lapply(results, rev))
            results = as.data.frame(results)

            p <- ggplot(results, aes(Iteration,Criteria)) +
              theme(legend.position = "none",plot.title = element_text(hjust = 0.5))+
              labs(y = paste0("1/D"), x = paste0(paste0("Iteration")))+
              #ggtitle("Iteration plot of the D-criteria.") +
              geom_step()+
              annotate("text",  x=Inf, y = Inf, label = paste0(" \n", "iter = ", max(results$Iteration)," \n" , "D = ", round(1/min(results$Criteria),2)  ), vjust=1, hjust=1) +
              geom_point(results, mapping = aes(x = Iteration, y = Criteria),color="red")+
              expand_limits( x = 0) +
              scale_x_continuous(limits=c(0,maxIter), breaks = scales::pretty_breaks(n = 10))
            print(p)


          })


# -------------------------------------------------------------------------------------------------------------------
#' Plot the optimal weights for hte Multiplicative algorithm.
#'
#' @name plotWeightOptimisation
#' @param object A \code{PFIM} object.
#' @param threshold A numeric giving the threshold for the weights.
#' @return A barplot of the optimal weights above the threshold.

setGeneric(
  "plotWeightOptimisation",
  function(object,threshold) {
    standardGeneric("plotWeightOptimisation")
  })

setMethod(f="plotWeightOptimisation",
          signature("PFIM"),
          function(object,threshold){

            w <- getWeights(optimization)

            weightDataFrame = as.data.frame(w)

            weightDataFrame = weightDataFrame[weightDataFrame$Amount_dose!=0, ]

            colnames( weightDataFrame ) = c( "Arm_name","Response","Time_dose", "Amount_dose","Sampling_times","Importance")

            weightDataFrame$Importance = as.numeric(weightDataFrame$Importance)

            plotFrame = subset(weightDataFrame, weightDataFrame$Importance>threshold)

            plotFrame = plotFrame[order(plotFrame$Importance,decreasing = TRUE),]
            xlab = rev(seq(length(plotFrame$Arm_name)))
            plotFrame$x = xlab

            p <- ggplot(plotFrame, aes(x =  x, y = Importance)) +

              theme(axis.text.x.top = element_text(angle = 90, hjust = 0,colour="red")) +

              geom_bar(width = 0.5,position="identity", stat="identity") +

              #geom_blank(data=plotFrame, aes(x=x, y=y*1.05, label=y))+

              scale_y_continuous("\nWeight Importance", limits=c(0,1.05),
                                 scales::pretty_breaks(n = 10), expand = c(0, 0)) +

              scale_x_continuous("Arms \n", breaks = max(plotFrame$x):min(plotFrame$x),
                                 labels = (plotFrame$Arm_name),
                                 sec.axis = sec_axis(~ . * 1,
                                                     breaks = (plotFrame$x),
                                                     labels = (plotFrame$Sampling_times),
                                                     name = "Sampling Times  \n  "))  + coord_flip()

            print(p)
            cat("\n The weight vectors after thresholding are: \n\n")

            print( plotFrame )
            #return( plotFrame )
          })

# ------------------------------------------------------------
#' resultsFedorovWynnAlgorithm
#'
#' @name resultsFedorovWynnAlgorithm
#' @param optimization
#' @return ...
# ------------------------------------------------------------

setGeneric(
  "resultsFedorovWynnAlgorithm",
  function(object) {
    standardGeneric("resultsFedorovWynnAlgorithm")
  })


setMethod(f="resultsFedorovWynnAlgorithm",
          signature("PFIM"),
          function(object){

            for ( design in object@designs )  {

              if ( design@isOptimalDesign ) {

                slot_names = c(slotNames(design@optimizationResult))

                if (  !is.na( match( "FisherMatrix",slot_names ) ) )
                {
                  cat("\n The Fisher matrix is : \n")

                  print(design@optimizationResult@FisherMatrix )
                }

                if (  !is.na( match( "optimalFrequencies",slot_names ) ) )
                {
                  cat("\n The optimal frequencies are : \n")

                  print(design@optimizationResult@optimalFrequencies )
                }

                if (  !is.na( match( "optimalSamplingTimes",slot_names ) ) )
                {
                  cat("\n The optimal sampling times are : \n")

                  print(design@optimizationResult@optimalSamplingTimes )
                }

                if (  !is.na( match( "optimalDoses",slot_names ) ) )
                {
                  cat("\n The optimal doses are : \n")

                  print(design@optimizationResult@optimalDoses )
                }
              }

            }})

# -------------------------------------------------------------------------------------------------------------------
#' Plot the concentration over time of a model.
#' @name plotResponse
#' @param object \code{PFIM} object.
#' @param ... A list giving the plot options.
#' @return A plot of the concentration over time of a model.
# -------------------------------------------------------------------------------------------------------------------

setGeneric(
  "plotResponse",
  function(object,...) {
    standardGeneric("plotResponse")
  })

setMethod(f="plotResponse",
          signature("PFIM"),

          function(object,...){

            # Results for the evaluation of the PFIM project
            concentrationDesign = list()
            samplingTimesDesign = list()
            outputPlotConcentration = list()
            concentration = list()
            concentrationPlot = list()
            Tinfs = list()
            timeDoses = list()

            # options for plot
            plot.options = list(...)
            unitXAxis = plot.options$units[1]
            unitYAxis = plot.options$units[2]

            # model components
            designs = getDesign( object )
            statisticalModel = getStatisticalModel( object )
            equations = statisticalModel@modelEquations
            responses = getResponsesStatisticalModel( statisticalModel )
            numberOfResponse = length(responses)
            parameters = names( getModelParameters( statisticalModel ) )

            # remove dose from parameters
            if (  "dose" %in% parameters )
            {
              parameters = parameters[ -grep( "dose", parameters ) ]
            }

            # -------------------------------------------------------------------------------
            # read results from evaluation and set the samplings times for plot
            # -------------------------------------------------------------------------------

            for ( nameDesign in names( designs ) )
            {
              design = designs[[ nameDesign ]]

              arms = getArms( design )

              # time step for plot
              samplingTimesDesign = design@samplingTimesWithTauAndTinf
              df = as.data.frame( do.call( rbind, lapply( samplingTimesDesign, unlist ) ) )
              minSampleTimeForPlot = min( df )
              maxSampleTimeForPlot = max( df )
              stepSampleTimeForPlot = min( df[ df > 0 ] )
              stepSampleTimeForPlot = 0.5 ##min( stepSampleTimeForPlot, 0.5 )

              for ( arm in arms)
              {
                nameArm = getNameArm( arm )
                sampling_times = getSamplings( arm )
                cond_init = getCondInit( arm )
                administration = getAdministration( arm )

                numberOfResponsePK = length( administration)
                numberOfResponsePD = numberOfResponse - numberOfResponsePK
                indicesRespPK = 1:length( administration)
                indicesRespPD = (length( administration)+1):numberOfResponse

                for ( response in responses )
                {
                  nameResponse = getNameResponse( response )

                  responseIndice = getResponseIndice(equations,nameResponse)

                  if ( responseIndice %in%  indicesRespPK )
                  {
                    timeDoses = append( timeDoses, getTimeDose( administration[[ nameResponse ]] )  )
                    Tinfs = append( Tinfs, getTinf( administration[[ nameResponse ]] )  )
                  }

                  # concentration from evaluation
                  concentrationDesign[[ nameResponse ]] = design@concentration[[nameArm]][[ nameResponse ]]
                  samplingTimesDesign[[ nameResponse ]] = design@samplingTimesWithTauAndTinf[[nameArm]][[ nameResponse ]]

                  concentration[[ nameDesign ]][[ nameArm ]][[ nameResponse ]] = data.frame( Concentration = unlist( concentrationDesign[[ nameResponse ]] ),
                                                                                             Time = unlist( samplingTimesDesign[[ nameResponse ]] ) )
                  # set the sampling times for evaluation
                  #stepSampleTimeForPlot = 1.0
                  object@designs[[ nameDesign ]]@arms[[nameArm]]@samplings[[ nameResponse ]]@sample_time = sort( unique ( c( unlist(Tinfs), seq( minSampleTimeForPlot,
                                                                                                                                                 maxSampleTimeForPlot,
                                                                                                                                                 length.out = 100 ) ) ) )
                }}} # end responses, arms, designs

            # -------------------------------------------------------------------------------
            # evaluation with the new sampling times
            # -------------------------------------------------------------------------------

            # boolean flag to run only the evaluation and not the FIM evaluation
            object@statistical_model@computeFIM = FALSE

            MyEvaluationPop <- EvaluatePopulationFIM( object )

            # iter for the output plot list
            iterPlot = 1

            # model components
            designs = getDesign( MyEvaluationPop )
            statisticalModel = getStatisticalModel( MyEvaluationPop )
            responses = getResponsesStatisticalModel( statisticalModel )

            # min, max X-Y axis RespPK and ResPD
            parameters = names( getModelParameters( statisticalModel ) )

            for ( nameDesign in names( designs ))
            {
              design = designs[[ nameDesign ]]

              arms = getArms( design )

              samplingTinfTauForPlot = design@samplingTinfTauForPlot
              samplingTinfTauForPlot = sort( c( do.call( rbind, lapply( samplingTinfTauForPlot, unlist ) ) ) )

              for ( arm in arms)
              {
                nameArm = getNameArm( arm )
                sampling_times = getSamplings( arm )
                cond_init = getCondInit( arm )

                for ( response in responses )
                {
                  nameResponse = getNameResponse( response )

                  samplingTinfTauForPlot = sort( unique( c( samplingTinfTauForPlot, c( unlist( timeDoses ), unlist ( Tinfs ) ) ) ) )

                  # concentration from evaluation
                  concentrationDesign[[ nameResponse ]] = design@concentration[[nameArm]][[ nameResponse ]]
                  samplingTimesDesign[[ nameResponse ]] = design@samplingTimesWithTauAndTinf[[nameArm]][[ nameResponse ]]

                  # concentration evaluation project PFIM
                  concentrationResponse = concentration[[ nameDesign ]][[ nameArm ]][[ nameResponse ]]

                  namesResponsePK = names( responses )[ indicesRespPK ]
                  namesResponsePD = names( responses )[ indicesRespPD ]

                  minXAxisRespPK = min( unlist( samplingTimesDesign[ namesResponsePK ] ) )
                  maxXAxisRespPK = max( unlist( samplingTimesDesign[ namesResponsePK ] ) )
                  maxYAxisRespPK = max( unlist( concentrationDesign[ namesResponsePK ] ) )

                  minXAxisRespPD = min( unlist( samplingTimesDesign[ namesResponsePD ] ) )
                  maxXAxisRespPD = max( unlist( samplingTimesDesign[ namesResponsePD ] ) )
                  maxYAxisRespPD = max( unlist( concentrationDesign[ namesResponsePD ] ) )

                  # add columns for min-max x-y acis depending RespPK, RespPD
                  if ( nameResponse %in% namesResponsePK )
                  {
                    concentrationPlot = data.frame( Concentration = unlist( concentrationDesign[[ nameResponse ]] ),
                                                    Time = unlist( samplingTimesDesign[[ nameResponse ]] ),
                                                    minXAxis = minXAxisRespPK,
                                                    maxXAxis = maxXAxisRespPK,
                                                    maxYAxis = maxYAxisRespPK )

                  }else if ( nameResponse %in% namesResponsePD)
                  {
                    concentrationPlot = data.frame( Concentration = unlist( concentrationDesign[[ nameResponse ]] ),
                                                    Time = unlist( samplingTimesDesign[[ nameResponse ]] ),
                                                    minXAxis = minXAxisRespPD,
                                                    maxXAxis = maxXAxisRespPD,
                                                    maxYAxis = maxYAxisRespPD )
                  }

                  # sampling time text in black for Tinfs
                  concentrationPlot["Color"] = rep("red", dim(concentrationPlot)[1] )
                  concentrationResponse["Color"] = rep("red", dim(concentrationResponse)[1] )
                  concentrationPlot$Color[concentrationPlot$Time %in% samplingTinfTauForPlot] = "black"
                  concentrationPlot$Color[1] = "red"
                  concentrationPlot$Color[dim(concentrationPlot)[1]] = "red"
                  concentrationPlotTinf = concentrationPlot[concentrationPlot$Time %in% samplingTinfTauForPlot,]
                  concentrationResponseTinf = rbind(concentrationResponse, concentrationPlotTinf[ c( "Concentration","Time","Color" ) ] )

                  # -------------------------------------------------------------------------------
                  # ggplot template
                  # -------------------------------------------------------------------------------

                  p <- ggplot() +

                    theme(legend.position = "none",plot.title = element_text(hjust = 0.5),
                          axis.title.x.top = element_text(color = "red"),
                          axis.text.x.top = element_text(angle = 90, hjust = 0, color = as.character( concentrationResponseTinf$Color ) ) ) +

                    labs(y = paste0(nameResponse," ", "(",unitYAxis,") \n"),
                         x = paste0(paste0("Time"," ", "(",unitXAxis,")"),
                                    "\n \n Design : ",  sub("_", " ",nameDesign),
                                    "      Arm : ",  nameArm)) +

                    geom_line(concentrationPlot, mapping = aes(x = Time, y = Concentration)) +

                    geom_point(concentrationResponse, mapping = aes(x = Time, y = Concentration ), color = "red" )+

                    coord_cartesian(xlim=c( unique( concentrationPlot$minXAxis ), unique(concentrationPlot$maxXAxis) ),
                                    ylim=c( 0, unique( concentrationPlot$maxYAxis))) +

                    scale_y_continuous(breaks = scales::pretty_breaks(n = 10)) +

                    scale_x_continuous(breaks = scales::pretty_breaks(n = 10),
                                       sec.axis = sec_axis(~ . * 1,
                                                           breaks = c(concentrationResponseTinf$Time),
                                                           name = "Sampling Time \n"))

                  outputPlotConcentration[[ iterPlot ]] <- p

                  iterPlot = iterPlot + 1

                }}} # end response, arm, design

            return( outputPlotConcentration )

          }) # end method

# -------------------------------------------------------------------------------------------------------------------

setGeneric(
  "plotSensitivity",
  function(object,...) {
    standardGeneric("plotSensitivity")
  })

#' Plot the sensitivity indices of a model over time.
#' @name plotSensitivity
#' @param object \code{PFIM} object.
#' @param ... A list giving the plot options.
#' @return Plot the sensitivity indices of a model over time.
# -------------------------------------------------------------------------------------------------------------------

setMethod(f="plotSensitivity",
          signature("PFIM"),

          function(object,...){

            # Results for the evaluation of the PFIM project
            sensitiviyIndicesDesign = list()
            samplingTimesDesign = list()
            outputPlotSensitiviyIndices = list()
            sensitiviyIndices = list()
            sensitiviyIndicesPlot = list()
            Tinfs = list()
            timeDoses = list()

            # options for plot
            plot.options = list(...)
            unitXAxis = plot.options$units[1]
            unitYAxis = plot.options$units[2]

            # model components
            designs = getDesign( object )
            statisticalModel = getStatisticalModel( object )
            equations = statisticalModel@modelEquations
            responses = getResponsesStatisticalModel( statisticalModel )
            numberOfResponse = length(responses)
            parameters = names( getModelParameters( statisticalModel ) )

            # remove dose from parameters
            if (  "dose" %in% parameters )
            {
              parameters = parameters[ -grep( "dose", parameters ) ]
            }

            # -------------------------------------------------------------------------------
            # read results from evaluation and set the samplings times for plot
            # -------------------------------------------------------------------------------

            for ( nameDesign in names( designs ))
            {
              design = designs[[ nameDesign ]]

              arms = getArms( design )

              # time step for plot
              samplingTimesDesign = design@samplingTimesWithTauAndTinf
              df = as.data.frame( do.call( rbind, lapply( samplingTimesDesign, unlist ) ) )
              minSampleTimeForPlot = min( df )
              maxSampleTimeForPlot = max( df )
              stepSampleTimeForPlot = min( df[ df > 0 ] )
              stepSampleTimeForPlot = 0.5 # min( stepSampleTimeForPlot, 0.5 )

              for ( arm in arms)
              {
                nameArm = getNameArm( arm )
                sampling_times = getSamplings( arm )
                cond_init = getCondInit( arm )
                administration = getAdministration( arm )

                numberOfResponsePK = length( administration)
                numberOfResponsePD = numberOfResponse - numberOfResponsePK
                indicesRespPK = 1:length( administration)
                indicesRespPD = (length( administration)+1):numberOfResponse

                for ( response in responses )
                {
                  nameResponse = getNameResponse( response )

                  responseIndice = getResponseIndice(equations,nameResponse)

                  if ( responseIndice %in%  indicesRespPK )
                  {
                    timeDoses = append( timeDoses, getTimeDose( administration[[ nameResponse ]] )  )
                    Tinfs = append( Tinfs, getTinf( administration[[ nameResponse ]] )  )
                  }

                  # concentration from evaluation
                  sensitiviyIndicesDesign[[ nameResponse ]] = design@sensitivityindices[[nameArm]][[ nameResponse ]]
                  samplingTimesDesign[[ nameResponse ]] = design@samplingTimesWithTauAndTinf[[nameArm]][[ nameResponse ]]

                  sensitiviyIndices[[ nameDesign ]][[ nameArm ]][[ nameResponse ]] =
                    data.frame( SensitiviyIndices = unlist( sensitiviyIndicesDesign[[ nameResponse ]] ),
                                Time = unlist( samplingTimesDesign[[ nameResponse ]] ) )

                  # set colnames, rownames for sensitiviyIndices
                  colnames( sensitiviyIndices[[ nameDesign ]][[ nameArm ]][[ nameResponse ]] ) = c( parameters,"Time")
                  rownames( sensitiviyIndices[[ nameDesign ]][[ nameArm ]][[ nameResponse ]] ) = NULL

                  # set the sampling times for evaluation
                  object@designs[[ nameDesign ]]@arms[[nameArm]]@samplings[[ nameResponse ]]@sample_time =
                    sort( unique ( c(  unlist(Tinfs), seq( minSampleTimeForPlot, maxSampleTimeForPlot, length.out = 100 ) ) ) )


                }}} # end responses, arms, designs

            # -------------------------------------------------------------------------------
            # evaluation with the new sampling times
            # -------------------------------------------------------------------------------

            # boolean flag to run only the evaluation and not the FIM evaluation
            object@statistical_model@computeFIM = FALSE
            MyEvaluationPop <- EvaluatePopulationFIM( object )

            # iter for the output plot list
            iterPlot = 1

            # model components
            designs = getDesign( MyEvaluationPop )
            statisticalModel = getStatisticalModel( MyEvaluationPop )
            responses = getResponsesStatisticalModel( statisticalModel )

            parameters = names( getModelParameters( statisticalModel ) )

            for ( nameDesign in names( designs ))
            {
              design = designs[[ nameDesign ]]

              arms = getArms( design )

              samplingTinfTauForPlot = design@samplingTinfTauForPlot
              samplingTinfTauForPlot = sort( c( do.call( rbind, lapply( samplingTinfTauForPlot, unlist ) ) ) )

              for ( arm in arms)
              {
                nameArm = getNameArm( arm )
                sampling_times = getSamplings( arm )
                cond_init = getCondInit( arm )

                for ( response in responses )
                {
                  nameResponse = getNameResponse( response )

                  samplingTinfTauForPlot = sort( unique( c( samplingTinfTauForPlot, c( unlist( timeDoses ), unlist ( Tinfs ) ) ) ) )

                  # concentration from evaluation
                  sensitiviyIndicesDesign[[ nameResponse ]] = design@sensitivityindices[[ nameArm ]][[ nameResponse ]]
                  samplingTimesDesign[[ nameResponse ]] = design@samplingTimesWithTauAndTinf[[ nameArm ]][[ nameResponse ]]

                  # concentration evaluation project PFIM
                  sensitiviyIndicesResponse = sensitiviyIndices[[ nameDesign ]][[ nameArm ]][[ nameResponse ]]

                  namesResponsePK = names( responses )[ indicesRespPK ]
                  namesResponsePD = names( responses )[ indicesRespPD ]

                  minXAxisRespPK = min( unlist( samplingTimesDesign[ namesResponsePK ] ) )
                  maxXAxisRespPK = max( unlist( samplingTimesDesign[ namesResponsePK ] ) )
                  minYAxisRespPK = min( unlist( sensitiviyIndicesDesign[ namesResponsePK ] ) )
                  maxYAxisRespPK = max( unlist( sensitiviyIndicesDesign[ namesResponsePK ] ) )

                  minXAxisRespPD = min( unlist( samplingTimesDesign[ namesResponsePD ] ) )
                  maxXAxisRespPD = max( unlist( samplingTimesDesign[ namesResponsePD ] ) )
                  minYAxisRespPD = min( unlist( sensitiviyIndicesDesign[ namesResponsePD ] ) )
                  maxYAxisRespPD = max( unlist( sensitiviyIndicesDesign[ namesResponsePD ] ) )

                  # add columns for min-max x-y acis depending RespPK, RespPD
                  if ( nameResponse %in% namesResponsePK )
                  {
                    sensitiviyIndicesPlot = data.frame( sensitiviyIndices = unlist( sensitiviyIndicesDesign[[ nameResponse ]] ),
                                                        Time = unlist( samplingTimesDesign[[ nameResponse ]] ),
                                                        minXAxis = minXAxisRespPK,
                                                        maxXAxis = maxXAxisRespPK,
                                                        minYAxis = minYAxisRespPK,
                                                        maxYAxis = maxYAxisRespPK )

                  }else if ( nameResponse %in% namesResponsePD )
                  {
                    sensitiviyIndicesPlot = data.frame( sensitiviyIndices = unlist( sensitiviyIndicesDesign[[ nameResponse ]] ),
                                                        Time = unlist( samplingTimesDesign[[ nameResponse ]] ),
                                                        minXAxis = minXAxisRespPD,
                                                        maxXAxis = maxXAxisRespPD,
                                                        minYAxis = minYAxisRespPD,
                                                        maxYAxis = maxYAxisRespPD )

                  }

                  # set colnames, rownames for sensitiviyIndicesPlot
                  colnames( sensitiviyIndicesPlot ) = c( parameters,"Time","minXAxis","maxXAxis","minYAxis","maxYAxis")
                  rownames( sensitiviyIndicesPlot ) = NULL

                  # sampling time text in black for Tinfs
                  sensitiviyIndicesPlot[ "Color" ] = rep( "red", dim( sensitiviyIndicesPlot )[1] )
                  sensitiviyIndicesResponse[ "Color" ] = rep( "red", dim( sensitiviyIndicesResponse )[1] )
                  sensitiviyIndicesPlot$Color[ sensitiviyIndicesPlot$Time %in% samplingTinfTauForPlot ] = "black"
                  sensitiviyIndicesPlot$Color[1] = "red"
                  sensitiviyIndicesPlot$Color[ dim( sensitiviyIndicesPlot )[1] ] = "red"
                  sensitiviyIndicesPlotTinf = sensitiviyIndicesPlot[ sensitiviyIndicesPlot$Time %in% samplingTinfTauForPlot, ]
                  sensitiviyIndicesResponseTinf = rbind( sensitiviyIndicesResponse, sensitiviyIndicesPlotTinf[ c( parameters,"Time","Color" ) ] )

                  # -------------------------------------------------------------------------------
                  # ggplot template
                  # -------------------------------------------------------------------------------

                  for(i in parameters){

                    p <- ggplot() +

                      theme(legend.position = "none",plot.title = element_text(hjust = 0.5),
                            axis.title.x.top = element_text(color = "red"),
                            axis.text.x.top = element_text(angle = 90, hjust = 0,
                                                           color = as.character( sensitiviyIndicesResponseTinf$Color ) ) ) +

                      labs(y = paste("df/d", i, sep=""),
                           x = paste0(paste0("Time"," ", "(",unitXAxis,")"),
                                      "\n \n Design : ",  sub("_", " ",nameDesign),
                                      "      Arm : ",  nameArm,
                                      "      Response : ",  nameResponse))+

                      geom_line(sensitiviyIndicesPlot, mapping = aes_string(x = sensitiviyIndicesPlot$Time, y = i)) +

                      geom_point( sensitiviyIndicesResponse, mapping = aes_string(x = sensitiviyIndicesResponse$Time, y = i ), color = "red" ) +

                      coord_cartesian(xlim=c( unique( sensitiviyIndicesPlot$minXAxis ), unique(sensitiviyIndicesPlot$maxXAxis) ),
                                      ylim=c( unique( sensitiviyIndicesPlot$minYAxis), unique( sensitiviyIndicesPlot$maxYAxis))) +

                      scale_y_continuous(breaks = scales::pretty_breaks(n = 10)) +

                      scale_x_continuous(breaks = scales::pretty_breaks(n = 10),
                                         sec.axis = sec_axis(~ . * 1,
                                                             breaks = c( sensitiviyIndicesResponseTinf$Time ),
                                                             name = "Sampling Time \n"))

                    outputPlotSensitiviyIndices[[ iterPlot ]] <- p

                    iterPlot = iterPlot + 1

                  } # end loop parameters

                }}} # end lop design, arm, response

            return( outputPlotSensitiviyIndices )
          }) # end function

# -------------------------------------------------------------------------------------------------------------------
#' Plot the relative standard errors RSE of the model parameters.
#' @name plotRSE
#' @param object \code{PFIM} object.
#' @return Plot the RSE of the model parameters.

setGeneric(
  "plotRSE",
  function(object) {
    standardGeneric("plotRSE")
  })

setMethod(f="plotRSE",
          signature("PFIM"),

          function(object){

            plotlist_rse = list()

            allDesignsObject = getDesign(object)
            MyStatisticalModel = getStatisticalModel(object)

            for (iterDesign in 1:length(allDesignsObject)){

              design = allDesignsObject[[iterDesign]]

              nameDesign = getNameDesign(design)
              fimOfDesign  = getFimOfDesign(design)

              results = EvaluateRSEforEachDesign( design, MyStatisticalModel )

              # plot template

              p = ggplot(results[[1]],
                         aes(Parameters, Values)) +
                theme(legend.position = "none",
                      axis.text.x = element_text(angle = 0, vjust = 0.5))+
                geom_bar(stat="identity",
                         width = 0.8,
                         position = position_dodge2(width = 0.8, preserve = "single")) +
                facet_grid(. ~ RSE, labeller=label_parsed, scales="free", space = "free")

              z <- ggplotGrob(p)
              z <- gtable_add_rows(z, z$height[7], pos = 6)
              gtable_show_layout(z)
              z <- gtable_add_grob(z,
                                   list(rectGrob(gp = gpar(col = NA, fill = "gray85", size = .5)),
                                        textGrob(paste0(nameDesign," : " , results[[2]]), gp = gpar(cex = .75, col = "black"))),
                                   t=7, l=5, b=7, r=9, name = c("a", "b"))
              z <- gtable_add_rows(z, unit(2/10, "line"), 7)
              #grid.newpage()
              grid.draw(z)
              plotlist_rse[[iterDesign]] <- z

            }
            # return(plotlist_rse)
          })

# -------------------------------------------------------------------------------------------------------------------
#' Plot the standard errors SE of the model parameters.
#' @name plotSE
#' @param object \code{PFIM} object.
#' @return Plot the standard errors SE of the model parameters.

setGeneric(
  "plotSE",
  function(object) {
    standardGeneric("plotSE")
  })

setMethod(f="plotSE",
          signature("PFIM"),

          function(object){

            plotlist_se = list()


            allDesignsObject = getDesign(object)
            statisticalModel = getStatisticalModel(object)

            for (iterDesign in 1:length(allDesignsObject)){

              design = allDesignsObject[[iterDesign]]

              nameDesign = getNameDesign(design)
              fimOfDesign  = getFimOfDesign(design)

              results = EvaluateSEforEachDesign(design,statisticalModel)

              # plot template

              p = ggplot(results[[1]],
                         aes(Parameters, Values)) +
                theme(legend.position = "none",
                      axis.text.x = element_text(angle = 0, vjust = 0.5))+
                geom_bar(stat="identity",
                         width = 0.8,
                         position = position_dodge2(width = 0.8, preserve = "single")) +
                facet_grid(. ~ SE, labeller=label_parsed, scales="free", space = "free")

              z <- ggplotGrob(p)
              z <- gtable_add_rows(z, z$height[7], pos = 6)
              gtable_show_layout(z)
              z <- gtable_add_grob(z,
                                   list(rectGrob(gp = gpar(col = NA, fill = "gray85", size = .5)),
                                        textGrob(paste0(nameDesign," : " , results[[2]]), gp = gpar(cex = .75, col = "black"))),
                                   t=7, l=5, b=7, r=9, name = c("a", "b"))
              z <- gtable_add_rows(z, unit(2/10, "line"), 7)
              #grid.newpage()
              grid.draw(z)
              plotlist_se[[iterDesign]] <- z

            }
            #return(plotlist_se)
          })

# -------------------------------------------------------------------------------------------------------------------
#' Print a summary of the PFIM project.
#' @name summaryProjectPFIM
#' @param object \code{PFIM} object.
#' @param modelDescription ...
#' @return Print a summary of the PFIM project.

setGeneric(
  "summaryProjectPFIM",
  function(object, modelDescription="") {
    standardGeneric("summaryProjectPFIM")
  })

setMethod(f="summaryProjectPFIM",
          signature("PFIM"),
          function(object, modelDescription){

            # name of the project
            projectPFIMName = paste0("Results of the project ",  object@name)

            # all designs
            allDesignsObject = getDesign( object )

            # -----------------------------------------------
            # matrixFisherPopulationFIM
            # -----------------------------------------------

            # model parameters
            statisticalModel = getStatisticalModel( object )
            responses = getResponsesStatisticalModel(statisticalModel)
            namesResponses = names( responses )
            namesVariables = names( statisticalModel@variables )
            modelParameters = getStatisticalModelParameters( statisticalModel )
            namesParameters = names( getStatisticalModelParameters( statisticalModel ) )

            # values and distribution nof model parameters

            muValueModelsParameters = unlist( lapply( modelParameters, slot, name = "mu" ) )
            sigmaValueModelsParameters = unlist( lapply( modelParameters, slot, name = "omega" ) )
            distributionsModelsParameters = lapply( modelParameters, slot, name = "distribution" )
            distributionsModelsParameters = lapply( distributionsModelsParameters, class )
            distributionsModelsParameters = unlist( lapply( distributionsModelsParameters, `[[`, 1 ) )
            distributionsModelsParameters = gsub("Distribution", "", distributionsModelsParameters )

            sigmaValueModelsParameters = round( sigmaValueModelsParameters, 2 )

            matrixParameters = cbind( muValueModelsParameters, sigmaValueModelsParameters, distributionsModelsParameters )
            colnames( matrixParameters ) = c( "$\\mu$","$\\omega$","Distribution" )
            rownames( matrixParameters ) = namesParameters

            # latex expression
            latexMu = paste0( "$\\mu_{",namesParameters,"}$" )
            latexOmega = paste0( "$\\omega^2_{",namesParameters,"}$" )

            ## model equations
            slotNames = slotNames( statisticalModel@modelEquations)
            slotDerivatives = grep("derivatives",slotNames )

            # analytic
            if ( length( slotDerivatives ) == 0){
              modelEquations = getEquations( statisticalModel@modelEquations )
              # ode
            }else{
              modelEquations = getDerivatives( statisticalModel@modelEquations )
            }

            numberOfEquations = length( modelEquations )
            namesEquations = names( modelEquations )
            numberOfVariables = length( namesVariables )

            equations = list()

            for ( i in 1:numberOfEquations ){

              equations[[i]] = paste0( namesEquations[i] , " = ", modelEquations[[i]][1] )

            }

            for ( i in 1:numberOfEquations ){
              for ( j in 1:numberOfVariables ){

                equations[[i]] = gsub(namesVariables[j], namesResponses[j], equations[[i]])

              }}

            modelEquations = matrix( unlist( equations ), ncol = 1 )

            # find parameters with omega = 0
            omega = lapply( modelParameters, slot, name = "omega" )
            indexOmegaNull = which( omega == 0 )

            # list for sigma slop and inter with responses
            latexSigma = list()

            for ( nameResponse in namesResponses )
            {
              if ( responses[[nameResponse]]@model_error@sigma_inter != 0)
              {
                latexSigma  =  append( latexSigma, paste0("${{\\sigma}_{inter}}_{",nameResponse,"}$") )
              }

              if ( responses[[nameResponse]]@model_error@sigma_slope != 0)
              {
                latexSigma  =  append( latexSigma, paste0("${{\\sigma}_{slope}}_{",nameResponse,"}$") )
              }
            }

            latexSigma = unlist( latexSigma )

            # get FIM
            populationFIM = getFim( object,1 )
            matrixFisherPopulationFIM = getMfisher( populationFIM )

            # remove parameters with omega = 0
            if ( length( indexOmegaNull ) != 0 )
            {
              latexOmega = latexOmega[-c(indexOmegaNull)]
            }

            # rename the rows and cols with Latex expression
            colnames( matrixFisherPopulationFIM ) = c( latexMu, latexOmega, latexSigma )
            rownames( matrixFisherPopulationFIM ) = c( latexMu, latexOmega, latexSigma )

            lengthFixedEffects = length( latexMu )
            dimMatrixFisherPopulationFIM = dim( matrixFisherPopulationFIM )[1]

            matrixFisherPopulationFIMFixedEffects  = matrixFisherPopulationFIM[ 1:lengthFixedEffects, 1:lengthFixedEffects ]
            matrixFisherPopulationFIMRandomEffects = matrixFisherPopulationFIM[ ( 1+lengthFixedEffects ):dimMatrixFisherPopulationFIM,
                                                                                ( 1+lengthFixedEffects ):dimMatrixFisherPopulationFIM ]

            # -------------------------------------------------------------
            # Determinant, Condition number, D-criteria
            # -------------------------------------------------------------

            for (iterDesign in 1:length( allDesignsObject )){

              design = allDesignsObject[[iterDesign]]
              nameDesign = getNameDesign(design)
              fimOfDesign  = getFimOfDesign(design)
              mfisher = getMfisher( fimOfDesign )

              Determinant = det( mfisher )
              Dcriteria = getDcriterion( fimOfDesign )
              Determinant = format( Determinant, scientific=T )

              conditionNumberFixedEffects = cond( matrixFisherPopulationFIMFixedEffects )
              conditionNumberRandomEffects = cond( matrixFisherPopulationFIMRandomEffects )

              detAndD = data.frame( Determinant = Determinant,
                                    conditionNumberFixedEffects = conditionNumberFixedEffects,
                                    conditionNumberRandomEffects = conditionNumberRandomEffects,
                                    Dcriteria = Dcriteria )

              colnames( detAndD ) = c("Determinant",
                                      "Fixed effects",
                                      "Random effects",
                                      "D-criteria")

              rownames( detAndD ) = NULL

              resultsRSE = EvaluateRSEforEachDesign( design, statisticalModel )
              resultsSE  = EvaluateSEforEachDesign( design, statisticalModel )

              results_SE_RSE = data.frame( resultsSE[[1]][,c(2)], resultsRSE[[1]][,c(2)] )
              rownames( results_SE_RSE ) = c( latexMu, latexOmega, latexSigma )
              colnames( results_SE_RSE ) = c( "SE","RSE" )

              # -------------------------------------------------------------
              # Plot the concentration, sensitivity index, SE, RSE
              # -------------------------------------------------------------

              plot_response <- plotResponse( object, units = c( "x unit","y unit" ) )
              plot_sensitivity   <- plotSensitivity( object ) #, units = c("x unit"))

              # -----------------------------------------------
              # Create rmarkdown report
              # -----------------------------------------------

              rmarkdown::render( input = "inst/rmarkdown/templates/pfim_report/skeleton/skeleton.rmd",
                                 output_file = paste0( "PFIMReport_Project_",object@name,".pdf" ),

                                 params = list( statisticalModel = "statisticalModel",
                                                projectPFIMName = "projectPFIMName",
                                                modelDescription = "modelDescription",

                                                modelEquations = "modelEquations",

                                                object = "object",
                                                detAndD = "detAndD",

                                                matrixParameters = "matrixParameters",

                                                conditionNumberFixedEffects = "conditionNumberFixedEffects",
                                                conditionNumberRandomEffects = "conditionNumberRandomEffects",

                                                matrixFisherPopulationFIMFixedEffects = "matrixFisherPopulationFIMFixedEffects",
                                                matrixFisherPopulationFIMRandomEffects = "matrixFisherPopulationFIMRandomEffects",

                                                plot_response = "plot_response",
                                                plot_sensitivity = "plot_sensitivity",
                                                results_SE_RSE = "results_SE_RSE" ) )
            } # end loop design
          })

#####################################################################################################
# END CODE
#####################################################################################################



