##################################################################################
##' Class "Constant"
##'
##' @description .................
##'
##' @name Constant-class
##' @aliases Constant
##' @docType class
##' @include Combined1.R
##' @exportClass Constant
##'
##' @section Objects from the Class: Constant objects
##' are typically created by calls to \code{{...}} and contain the following slots
##' that are heritated from the class Combined1:
##' \describe{
##' \item{c_error}{...}
##' \item{sigma_slope}{...}
##' }


Constant<-setClass(
  Class="Constant",
  contains = "Combined1",
  prototype = prototype(
    c_error = 1,
    sigma_slope = 0
  ),
  validity=function(object)
  {
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f="initialize",
  signature="Constant",
  definition= function (.Object, sigma_inter)
  {
    # Object validation
    validObject(.Object)
    .Object = callNextMethod( .Object, sigma_inter = sigma_inter, sigma_slope = 0 )
    return (.Object )
  }
)

#' getSigmaNames
#' @name getSigmaNames
#' @param object \code{Constant} object.
#' @return ...

setMethod("getSigmaNames",
          "Constant",
          function(object)
          {
            sigmaNames <- c( "\u03c3_inter" )
            return(sigmaNames)
          }
)

#' getSigmaValues
#' @name getSigmaValues
#' @param object \code{Constant} object.
#' @return ...

setMethod("getSigmaValues",
          "Constant",
          function(object)
          {
            return(object@sigma_inter)
          }

)

#' show
#' @name show
#' @param object \code{Constant} object.
#' @return ...


setMethod(f="show",
          signature=  "Constant",
          definition=function(object)
          {
            cat(" Error model constant (sigma_inter) = ",object@sigma_inter, "\n")
          }
)
