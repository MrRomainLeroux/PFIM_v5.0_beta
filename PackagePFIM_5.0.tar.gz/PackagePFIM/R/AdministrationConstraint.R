##########################################################################################################
#' Class "AdministrationConstraint"
#'
#' @description
#' The Class "AdministrationConstraint" represents the constraint of an input to the system.
#' The Class stores information concerning the constraints for the dosage regimen :
#' resonse of the model, type of administration, amount of dose.
#'
#' @name AdministrationConstraint-class
#' @aliases AdministrationConstraint
#' @docType class
#' @exportClass AdministrationConstraint
#'
#' @section Objects from the Class AdministrationConstraint:
#' Objects form the Class \code{AdministrationConstraint} can be created by calls of the form \code{AdministrationConstraint}.
#'
#'@section Slots for the \code{AdministrationConstraint} objects:
#' \describe{
#' \item{\code{response}:}{A character giving the response of the model.}
#' \item{\code{Optimisability}:}{A boolean giving if a dose is optimisable or not. If not the dose is fixed.}
#' \item{\code{fixedDoses}:}{A vector giving the fixed doses.}
#' \item{\code{AllowedDoses}:}{A vector giving the allowed amout of doses.}
#' }
#'


AdministrationConstraint<-setClass(
  Class = "AdministrationConstraint",
  slots = c(
    response = "character",
    Optimisability = "logical",
    fixedDoses = "vector",
    AllowedDoses = "vector"
  ),
  validity = function(object)
  {
    return(TRUE)
  }

)



setMethod(
  f="initialize",
  signature="AdministrationConstraint",
  definition= function (.Object, response, Optimisability, AllowedDoses, fixedDoses)
  {
    if(!missing(response))
      .Object@response<-response
    if(!missing(Optimisability))
      .Object@Optimisability<-Optimisability
    if(!missing(AllowedDoses))
      .Object@AllowedDoses<-AllowedDoses
    if(!missing(fixedDoses))
      .Object@fixedDoses<-fixedDoses
    validObject(.Object)
    return (.Object )
  }
)

# -------------------------------------------------------------------------------------------------------------------

#' Choose if the dose values are fixed or optimisable.
#'
#' @name doseIsOptimisable
#' @param object An \code{AdministrationConstraint} object.
#' @param IsOptimisable ...
#' @return A boolean equal to TRUE if the dose is optimisable, FALSE for a fixed dose.

setGeneric("doseIsOptimisable",
           function(object,IsOptimisable)
           {
             standardGeneric("doseIsOptimisable")
           }
)
setMethod("doseIsOptimisable",
          "AdministrationConstraint",
          function(object,IsOptimisable)
          {
            if(IsOptimisable)
              object@Optimisability <- TRUE
            if(!IsOptimisable)
              object@Optimisability <- FALSE
            return(object)
          }
)

# -------------------------------------------------------------------------------------------------------------------

#' Define the vector of allowed amount of dose.
#'
#' @name AllowedDoses
#' @param object An \code{AdministrationConstraint} object.
#' @param value A numeric.
#' @return The \code{AdministrationConstraint} object with the new allowed amount of dose.

setGeneric("AllowedDoses",
           function(object,value)
           {
             standardGeneric("AllowedDoses")
           }
)
setMethod("AllowedDoses",
          "AdministrationConstraint",
          function(object,value)
          {
            object@AllowedDoses <- value
            return(object)
          }
)

# -------------------------------------------------------------------------------------------------------------------

#' Set the value for the fixed doses in the administration constraints.
#'
#' @name fixedDoses
#' @param object An \code{AdministrationConstraint} object.
#' @param value A numeric giving the value of the fixed dose.
#' @return The \code{AdministrationConstraint} object with the new value of the fixed dose.


setGeneric("fixedDoses",
           function(object,value)
           {
             standardGeneric("fixedDoses")
           }
)
setMethod("fixedDoses",
          "AdministrationConstraint",
          function(object,value)
          {
            object@fixedDoses <- value
            return(object)
          }
)

# -------------------------------------------------------------------------------------------------------------------

#' Get the name of the response for the admnistration constraint.
#'
#' @name getResponseName
#' @param object An \code{AdministrationConstraint} object.
#' @return The character string \code{response} giving the name of the response for the administration constraint.

setGeneric("getResponseName",
           function(object)
           {
             standardGeneric("getResponseName")
           }
)
setMethod("getResponseName",
          "AdministrationConstraint",
          function(object)
          {
            return(object@response)
          }
)

# -------------------------------------------------------------------------------------------------------------------

#' Get the vector of allowed amount of dose.
#'
#' @name getAllowedDoses
#' @param object An \code{AdministrationConstraint} object.
#' @return A vector \code{AllowedDoses} giving the allowed amount of dose.

setGeneric("getAllowedDoses",
           function(object)
           {
             standardGeneric("getAllowedDoses")
           }
)
setMethod("getAllowedDoses",
          "AdministrationConstraint",
          function(object)
          {
            return(object@AllowedDoses)
          }
)

# -------------------------------------------------------------------------------------------------------------------

#' Get the boolean \code{Optimisability}.
#'
#' @name getDoseOptimisability
#' @param object An \code{AdministrationConstraint} object.
#' @return The boolean \code{Optimisability} giving FALSE for fixed dose, TRUE for an optimisable dose.


setGeneric("getDoseOptimisability",
           function(object)
           {
             standardGeneric("getDoseOptimisability")
           }
)
setMethod("getDoseOptimisability",
          "AdministrationConstraint",
          function(object)
          {
            return(object@Optimisability)
          }
)

# -------------------------------------------------------------------------------------------------------------------

#' Get the vector \code{AllowedDoses} of allowed amount of dose.
#'
#' @name getNumberOfDoses
#' @param object An \code{AdministrationConstraint} object.
#' @return The vector \code{AllowedDoses} of allowed amount of dose.


setGeneric("getNumberOfDoses",
           function(object)
           {
             standardGeneric("getNumberOfDoses")
           }
)
setMethod("getNumberOfDoses",
          "AdministrationConstraint",
          function(object)
          {
            return(length(object@AllowedDoses))
          }
)
##########################################################################################################
# END Class "AdministrationConstraint"
##########################################################################################################













