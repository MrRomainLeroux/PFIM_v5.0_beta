
##' Class "summaryPFIM"
##' @exportClass summaryPFIM

summaryPFIM <- setClass(
  Class = "summaryPFIM",
  slots = c(
    name = "character",
    designs = "list"
  )
)

#' Summary of a PFIM project.
#' @name show
#' @param object \code{summaryPFIM} object.
#' @return Name of project, Name of design, Number of individuals,
#' Determinant of FIM, D criterion of FIM,
#' Expected standard error of fixed effects, Expected standard error of error model


setMethod(f = "show",
          signature = "summaryPFIM",
          definition = function(object)
          {
print(' ------------------------------------------------ ')            
cat( " Name of project : " , object@name,"\n")            
print(' ------------------------------------------------ ')              
for(design in object@designs)
{
  cat("Name of design:  ", design$name, "\n")
  cat("Number of individuals:  ", design$numberOfIndividuals,"\n")
  cat(" \n")
  print(design$arms)
  cat(" \n")
  if(!is.nan(design$Determinant))
  {
    cat("Determinant of FIM:  ", design$Determinant,",   ")
    cat("D criterion of FIM:  ", design$Dcriterion,"\n\n")
    cat("Expected standard error of fixed effects:\n")
    print(design$SEfixedEffects)
    cat("\n")
    cat("Expected standard error of error model:\n")
    print(design$SEerrorModel)
    
  }
}
          }
)
