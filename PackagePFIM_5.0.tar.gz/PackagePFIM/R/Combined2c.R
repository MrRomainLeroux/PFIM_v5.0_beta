##################################################################################
##' Class "Combined2c"
##'
##' @name Combined2c-class
##' @aliases Combined2c
##' @docType class
##' @include ModelError.R
##' @exportClass Combined2c
##'
##' @section Objects from the Class: Combined2c objects
##' are typically created by calls to \code{{...}} and contain the following slots
##' that are heritated from the class ModelError:
##' \describe{
##' \item{....}{...}
##' }
##'
##' @section Methods:
##' \describe{
##' \item{g}{This methods will calculate the residual error variance according
##' to the formula g(sigma_inter, sigma_slope, c_error, f(x, theta)) = sigma_inter^2 + sigma_slope^2 * f(x, theta)^(2*c_error).
##' Please note that Combined2C is a general case. The particular case is:
##' 1. Combined2: When c_error = 1}
##' }

Combined2c<-setClass(
  Class="Combined2c",
  contains = "ModelError",
  validity=function(object)
  {
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f="initialize",
  signature="Combined2c",
  definition= function (.Object, sigma_inter, sigma_slope, c_error )
  {
    # Object validation
    validObject(.Object)
    .Object = callNextMethod(.Object, sigma_inter, sigma_slope, c_error, equation = expression( sigma_inter ^ 2 + sigma_slope ^ 2 * f_x_i_theta ^ ( 2 * c_error ) )  )
    return (.Object )
  }
)

#' getSigmaNames
#' @name getSigmaNames
#' @param object \code{Combined2c} object.
#' @return ...

setMethod("getSigmaNames",
          "Combined2c",
          function(object)
          {
            sigmaNames <- c( )
            if(object@sigma_inter != 0)
              sigmaNames <- c( sigmaNames, "\u03c3_inter")
            if(object@sigma_slope != 0)
              sigmaNames <- c( sigmaNames, "\u03c3_slope" )
            if(object@c_error != 0)
              sigmaNames <- c( sigmaNames, "c_error" )
            return(sigmaNames)
          }
)

#' getSigmaValues
#' @name getSigmaValues
#' @param object \code{Combined2c} object.
#' @return ...

setMethod("getSigmaValues",
          "Combined2c",
          function(object)
          {
            sigmaValues <- c( )
            if(object@sigma_inter != 0)
              sigmaValues <- c( sigmaValues, object@sigma_inter)
            if(object@sigma_slope != 0)
              sigmaValues <- c( sigmaValues, object@sigma_slope )
            if(object@c_error != 0)
              sigmaValues <- c( sigmaValues, object@c_error )
            return(sigmaValues)
          }

)

#' show
#' @name show
#' @param object \code{Combined2c} object.
#' @return ...

setMethod(f="show",
          signature=  "Combined2c",
          definition=function(object)
          {
            eq <- gsub("f_x_i_theta", "f", toString(object@equation))
            cat(" Error model combined 2c equation : ",eq, "\n")
            callNextMethod(object)
          }
)
