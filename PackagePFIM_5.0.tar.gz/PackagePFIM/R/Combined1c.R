##################################################################################
##' Class "Combined1c"
##'
##' @description .................
##'
##' @name Combined1c-class
##' @aliases Combined1c
##' @docType class
##' @include ModelError.R
##' @exportClass Combined1c
##'
##' @section Objects from the Class: Combined1c objects
##' are typically created by calls to \code{{Combined1c}} and contain the following slots
##' that are heritated from the class ModelError:
##'
##' \describe{
##' \item{.Object}{...}
##' \item{sigma_inter}{...}
##' \item{sigma_slope}{...}
##' \item{c_error}{...}
##' \item{equation}{...}
##' }
##'
Combined1c<-setClass(
  Class="Combined1c",
  contains = "ModelError",
  validity=function(object)
  {
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f="initialize",
  signature="Combined1c",
  definition= function (.Object, sigma_inter, sigma_slope, c_error )
  {
    # Object validation
    validObject(.Object)
    .Object = callNextMethod(.Object, sigma_inter = sigma_inter, sigma_slope = sigma_slope, c_error = 1, expression( sigma_inter + sigma_slope * f_x_i_theta ^ c_error ) )
    return (.Object )
  }
)

#' getSigmaNames
#' @name getSigmaNames
#' @param object \code{Combined1c} object.
#' @return ...
#'
setMethod("getSigmaNames",
          "Combined1c",
          function(object)
          {
            sigmaNames <- c( )
            if(object@sigma_inter != 0)
              sigmaNames <- c( sigmaNames, "\u03c3_inter")
            if(object@sigma_slope != 0)
              sigmaNames <- c( sigmaNames, "\u03c3_slope" )
            if(object@c_error != 0)
              sigmaNames <- c( sigmaNames, "c_error" )
            return(sigmaNames)
          }
)

#' getSigmaValues
#' @name getSigmaValues
#' @param object \code{Combined1c} object.
#' @return ...


setMethod("getSigmaValues",
          "Combined1c",
          function(object)
          {
            sigmaValues <- c( )
            if(object@sigma_inter != 0)
              sigmaValues <- c( sigmaValues, object@sigma_inter)
            if(object@sigma_slope != 0)
              sigmaValues <- c( sigmaValues, object@sigma_slope )
            if(object@c_error != 0)
              sigmaValues <- c( sigmaValues, object@c_error )
            return(sigmaValues)
          }

)


#' show
#' @name show
#' @param object \code{Combined1c} object.
#' @return ...

setMethod(f="show",
          signature=  "Combined1c",
          definition=function(object)
          {
            eq <- gsub("f_x_i_theta", "f", toString(object@equation))
            cat(" Error model combined 1c equation : ", eq, "\n")
            callNextMethod(object)
          }
)
