
#################################################################################
#' Class "StatisticalModel"
#' @description  Class "StatisticalModel" represents a statistical model
#'
#' @name StatisticalModel-class
#' @docType class
#' @include ModelEquations.R
#' @exportClass StatisticalModel
#'
#' @section Mathematical description of the statistical model:
#' \describe{
#' \item{}{\deqn{y = f(x, \theta) + g*\epsilon}, this part is considered in class Response}
#' \item{1.}{\deqn{f(x, \theta)}, this part is considered in class Response}
#' \item{2.}{\deqn{\theta = {\mu, \omega}}, this part is considered in class ModelParameter (!!! à voir pour Covariates)}
#' \item{3.}{\deqn{\epsilon}, this is a slot of type NormalDistribution with mean = 0 and covariate_matrix = I}
#' }
#'
#' @section Objects from the Class: StatisticalModel objects are typically created by calls to \code{StatisticalModel} and contain the following slots:
#'
#' @section Slots for StatisticalModel objects:
#' \describe{
#' \item{\code{modelEquations}:}{An object from the class \code{ModelEquations}}
#' \item{\code{responses}:}{A list of objects of type Responses -> f(x, theta)}
#' \item{\code{corelations}:}{A list giving all the covariables.}
#' \item{\code{model_parameters}:}{A list giving all the parameters of the models.}
#' }

StatisticalModel<-setClass(
  Class = "StatisticalModel",
  representation = representation(
    modelEquations = "ModelEquations",
    responses = "list", # list of object of type Response
    corelations = "list", # list of all covariables
    model_parameters = "list", # list of all parameters of the models
    computeFIM = "logical"
  ),
  prototype = prototype( computeFIM = TRUE ),
  validity = function(object)
  {
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f = "initialize",
  signature = "StatisticalModel",
  definition = function(.Object, responses )
  {
    if(!missing(responses))
      .Object@responses <- responses


    validObject(.Object)
    return(.Object)
  }
)

# -------------------------------------------------------------------------------------------------------------------
#' Add a response to a statistical model.
#'
#' @name addResponse
#' @param object \code{StatisticalModel} object.
#' @param value A character string giving the name of the  response to add.
#' @return The \code{StatisticalModel} object with the added response.

setGeneric("addResponse",
           function(object, value)
           {
             standardGeneric("addResponse")
           }
)
setMethod( f="addResponse",
           signature="StatisticalModel",
           definition = function(object, value)
           {
             #object@responses[[ getName( value ) ]] <- value
             object@responses[[ value@name ]] <- value
             validObject(object)
             return(object)
           }
)



# -------------------------------------------------------------------------------------------------------------------
#' defineCorelation
#' @name defineCorelation
#' @param objectStatisticalModel \code{StatisticalModel} object.
#' @param corelationlist ...
#' @return Return corelationlist
#
setGeneric("defineCorelation",
           function(objectStatisticalModel, corelationlist)
           {
             standardGeneric("defineCorelation")
           }
)

setMethod(f="defineCorelation",
          signature=  "StatisticalModel",
          definition=function(objectStatisticalModel, corelationlist )
          {
            objectStatisticalModel@corelations = corelationlist
            return(objectStatisticalModel)
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' This method calls the Method g (can be found in class ModelError)
#' @name CalculatedResidualVariance
#' @param objectStatisticalModel \code{StatisticalModel} object.
#' @param objectModelError \code{objectModelError} object.
#' @param x_i x_i
#' @return CalculatedResidualVariance

setGeneric("CalculatedResidualVariance",
           function(objectStatisticalModel, objectModelError, x_i ) #
           {
             standardGeneric("CalculatedResidualVariance")
           }
)
#
setMethod(f="CalculatedResidualVariance",
          signature=  "StatisticalModel",
          definition=function(objectStatisticalModel, objectModelError, x_i)
          {
            #f_x_i_theta = 5
            calculated_residual_variance = g(objectModelError, x_i)
            return(calculated_residual_variance)
          }
)

#' Evaluate an \code{StatisticalModel} object.
#'
#' @rdname Evaluate
#' @param object An \code{StatisticalModel} object.
#' @param administrations An \code{Administration} object.
#' @param sampling_times A \code{SamplingTimes} object.
#' @param cond_init A list for the initial conditions of the \code{StatisticalModel} object.
#' @param fim  \code{FIM} object.
#' @return A \code{fim} object giving the Fisher Information Matrix of the \code{StatisticalModel} object.

setGeneric("Evaluate",
           function(object, administrations, sampling_times, cond_init, fim )
           {
             standardGeneric("Evaluate")
           }
)

setMethod(f="Evaluate",
          signature=  "StatisticalModel",
          definition=function(object, administrations, sampling_times, cond_init, fim )
          {

            MF_var = NA
            df_total = NA
            V_total = NA
            # errorVariances = NA
            errorVariances=list()
            sigmaDerivatives = list()

            nTotalSamplingTimes = 0

            for( samplingTime in sampling_times )
            {
              nTotalSamplingTimes <- nTotalSamplingTimes + getNumberTime( samplingTime )

            }

            position = 1

            concentrationModel = list()
            sensitivityIndicesModel = list()
            samplingTimesWithTauAndTinfModel = list()

            for ( response in object@responses )
            {
              results = EvaluateFirstDerivatives(response, object@modelEquations, object@model_parameters, administrations, sampling_times, cond_init )
              # Concentration and Sensitivity index for evaluation
              df = results[[ 1 ]]
              fxitheta = results[[ 2 ]]
              samplingTimesWithTauAndTinf = results[[3]]

              # data for plot
              #nameResponse = getName( response )
              nameResponse = getNameResponse( response )

              concentrationModel[[ nameResponse ]] = fxitheta
              sensitivityIndicesModel[[ nameResponse ]] = df
              samplingTimesWithTauAndTinfModel[[ nameResponse ]] = samplingTimesWithTauAndTinf

              if ( is.matrix( df_total ))
              {
                df_total = rbind( df_total, df )
              }
              else
              {
                df_total = df
              }

              errorModelDerivatives = EvaluateErrorModelDerivatives(response, fxitheta)

              errorVariances = append( errorVariances, bdiag( errorModelDerivatives$errorVariance ) )
              errorVariances = bdiag( errorVariances)
              #
#               if ( is.matrix( errorVariances ))
#               {
#                 errorVariances = bdiag( errorVariances, errorModelDerivatives$errorVariance )
#               }
#               else
#               {
#                 errorVariances = errorModelDerivatives$errorVariance
#               }
#

              for( errorModelParameter in errorModelDerivatives$sigmaDerivatives )
              {

                nTime = 0
                #if(is.null( sampling_times[[ getName( response ) ]] ))
                if(is.null( sampling_times[[ getNameResponse( response ) ]] ))

                  nTotalSamplingTimes = length(administrations)
                else

                  #nTime = getNumberTime( sampling_times[[ getName( response ) ]] )
                  nTime = getNumberTime( sampling_times[[ getNameResponse( response ) ]] )


                emptysigmaDerivatives = matrix(0, ncol = nTotalSamplingTimes, nrow = nTotalSamplingTimes )
                range <- position:( position + nTime  - 1 )

                emptysigmaDerivatives[ range, range ] <- errorModelParameter

                ### Add the MF_beta matrix for the parameters for each response, add the MF_var in different blocks for each response
                sigmaDerivatives = c( sigmaDerivatives, list( emptysigmaDerivatives ) )


              }
              position <- position + nTime

            }


            FixedEffectNamesAndNumber <- getFixedEffectParameterNamesAndNumber(object)
            RandomEffectNamesAndIndex <- getNotZeroRandomEffectParameterNames(object)


            sigmaNames <- c()
            for (response in object@responses)
            {
              if ( is( fim, "PopulationFim" ) )
              {
                MF = PopulationFIMEvaluateVariance(response, object@modelEquations, object@model_parameters, administrations, sampling_times, df_total, errorVariances, sigmaDerivatives )
                parameterNames <- c( FixedEffectNamesAndNumber$muNames, RandomEffectNamesAndIndex$omegaNames )

              }
              else
                if ( is( fim, "IndividualFim" ) || is( fim, "BayesianFim" ) )
                {

                  MF = IndividualFIMEvaluateVariance(response, object@modelEquations, object@model_parameters, administrations, sampling_times, df_total, errorVariances, sigmaDerivatives )
                  parameterNames <- FixedEffectNamesAndNumber$muNames
                }
              ### Add the MF_beta matrix for the parameters for each response, add the MF_var in different blocks for each response
              if ( is.matrix( MF_var ))
              {
                MF_var = bdiag( MF_var, MF$MF_var )
                V_total = bdiag( V_total, MF$V )
              }
              else
              {
                ### Create the first matrix and the first block
                MF_var = bdiag( MF$MF_var )
                V_total = bdiag( MF$V )
              }

              sigmaNames <- c( sigmaNames, getSigmaNames(response) )
            }

            MF_beta =  t( df_total ) %*% solve( V_total ) %*% df_total
            #mat = eigenMapMatMult( t( df_total ), as.matrix( solve( V_total ) ) )
            #MF_beta = eigenMapMatMult( mat, df_total)

            if ( is( fim, "BayesianFim" ) )
            {
              # MF_response = NA
              # for (response in object@responses)
              # {
              #   MF = EvaluateBayesianFIM( response, MF_beta, object@model_parameters )
              #   if ( is.matrix( MF_response ) )
              #     MF_response<-bdiag( MF_response, MF )
              #   else
              #     MF_response = MF
              # }
              # MF_beta = MF_response

              mu = c()
              omega2 = c()
              nParameter = 0
              parameterNames = c()
              for (parameter in object@model_parameters)
              {
                if ( isFixed( parameter ) )
                  next
                nParameter = nParameter + 1

                parameterName = getNameModelParameter( parameter )
                #parameterName = parameter@name

                omegaValue = getOmega( parameter )
                omega2 = c( omega2, omegaValue^2 )

                ## TODO: gérer tout les type de distributions
                if ( class( getDistribution( parameter ) ) == "LogNormalDistribution" )
                {
                  muValue = getMu( parameter )
                  mu = c( mu, muValue )
                }
                else
                  if ( class( getDistribution( parameter ) ) == "NormalDistribution" )
                  {
                    mu = c( mu, 1 )
                  }
                else
                  print("That distribution type is not supported for bayesian FIM")
                parameterNames <- c( parameterNames, parameterName )
              }

              meanParametersMatrix = diag( mu )

              Omega<-diag( omega2 )
              fim<-setOmega( fim, Omega )
              fim<-setMu( fim, mu )
              identity = diag( rep( 1, nParameter ) )

              MF_beta = t( identity ) %*% MF_beta %*% identity + solve( meanParametersMatrix %*% Omega %*% meanParametersMatrix )


              colnames(MF_beta) <- c( parameterNames )
              rownames(MF_beta) <- c( parameterNames )
              fim <- `setMfisher<-`( fim, MF_beta )

              #return( fim )
              list(fim = fim,
                   concentrationModel = concentrationModel,
                   sensitivityIndicesModel = sensitivityIndicesModel )
            }

            MF_i_total = bdiag( MF_beta, MF_var )

            if(length(RandomEffectNamesAndIndex$zeroOmegaIndex) > 0)
              MF_i_total = MF_i_total[-c(FixedEffectNamesAndNumber$FixedEffectParameterNumber + RandomEffectNamesAndIndex$zeroOmegaIndex),
                                      -c(FixedEffectNamesAndNumber$FixedEffectParameterNumber + RandomEffectNamesAndIndex$zeroOmegaIndex)]

            colnames(MF_i_total) <- c( parameterNames, sigmaNames)
            rownames(MF_i_total) <- c( parameterNames, sigmaNames)

            fim <- `setMfisher<-`( fim, MF_i_total )

            return( list(fim = fim,
                         concentrationModel = concentrationModel,
                         sensitivityIndicesModel = sensitivityIndicesModel,
                         samplingTimesWithTauAndTinfModel = samplingTimesWithTauAndTinfModel) )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Define a parameter of a statistical model.
#'
#' @name defineParameter
#' @param object A \code{StatisticalModel} object.
#' @param parameter An expression giving a parameter of the \code{StatisticalModel} object.
#' @return Return \code{StatisticalModel} object with new parameters.

setGeneric("defineParameter",
           function(object, parameter)
           {
             standardGeneric("defineParameter")
           }
)
setMethod("defineParameter",
          "StatisticalModel",
          function(object, parameter )
          {
            parameterName = getNameModelParameter( parameter )
            #parameterName = parameter@name
            object@model_parameters[[ parameterName ]] = parameter
            return( object )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Define the equations of a statistical model.
#'
#' @name defineModelEquations
#' @param object A \code{StatisticalModel} object.
#' @param equations An exoression giving the equations of the model.
#' @return The \code{StatisticalModel} object wth the equations.

setGeneric("defineModelEquations",
           function(object, equations)
           {
             standardGeneric("defineModelEquations")
           }
)
setMethod("defineModelEquations",
          "StatisticalModel",
          function(object, equations )
          {
            object@modelEquations = equations
            return( object )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' show
#' @name show
#' @param object \code{StatisticalModel} object.
#' @return Diplay the responses name of the model equations,
#' the ordinary derivatives of the model equations (for an ODE model), the parameters of the model.


setMethod("show",
          signature = "StatisticalModel",
          definition = function(object)
          {
            cat("*********************** Statistical model ******************************\n")

            # ------------------------------------------------------------------------
            # ModelEquations
            # ------------------------------------------------------------------------

            if( class(object@modelEquations ) == "ModelEquations" ){

              cat( "\n **** Model equation:","\n\n" )

              for( response in object@responses )
              {
                nameResponse = getNameResponse( response )
                equation = getEquation( object@modelEquations, nameResponse )
                #name = getName(response)
                cat( paste0(nameResponse ," = ", equation,"\n\n" ) )

              }

              cat( " **** Model error:","\n\n" )

              for( response in object@responses )
              {

              nameResponse = getNameResponse( response )

              cat( " Model error",nameResponse, "\n" )

              modelError = getModelError( response )

              show( modelError )

              cat( "\n" )
              }

            }  # end if

            # ------------------------------------------------------------------------
            # ModelODEquations
            # ------------------------------------------------------------------------

            else if(class(object@modelEquations) == "ModelODEquations")
            {
              derivativeEqs <- getDerivatives( object@modelEquations )
              cat("\n")
              cat("**** Model responses:","\n\n" )

              for( response in object@responses)
              {
                nameResponse = getNameResponse( response )

                equation = getEquation( object@modelEquations, nameResponse )
                #name = getName(response)

                #cat( "\n **** Response name: ", nameResponse , "\n " )
                cat( paste0( nameResponse ," = ", equation,"\n" ) )

              }
              cat("\n")
              cat("**** Model error:","\n\n" )

              for( response in object@responses )
              {

                nameResponse = getNameResponse( response )

                cat("Model error",nameResponse, "\n" )

                modelError = getModelError( response )

                show( modelError )
                cat("\n")
              }

              cat("**** Ordinary derivatives of model equation:\n\n")

              for(i in 1:length(derivativeEqs))
              {
                cat( names(derivativeEqs)[i]," = ")
                print(derivativeEqs[[i]][[1]])
              }
              cat( "\n" )
            }

            # ------------------------------------------------------------------------
            # parameters
            # ------------------------------------------------------------------------

            nameCol <- c()
            muCol <- c()
            omegaCol <- c()
            distributionCol <- c()
            for(parameter in object@model_parameters)
            {
              nameCol <- c( nameCol, getNameModelParameter(parameter))

              muCol <- c(muCol, getMu(parameter))
              omegaCol <- c(omegaCol, getOmega(parameter))
              distributionCol <- c(distributionCol, class(getDistribution(parameter))[1])
            }

            parameterFrame <- matrix(c( as.character(muCol),
                                        as.character(omegaCol),
                                        distributionCol),ncol=3)

            colnames(parameterFrame) <- c("\u03bc", "\u03c9", "Distribution" )
            rownames(parameterFrame) <- nameCol
            cat("**** Model parameters: \n")
            print(parameterFrame)


          })

# -------------------------------------------------------------------------------------------------------------------
#' getModelParameters
#' @name getModelParameters
#' @param object \code{getModelParameters} object.
#' @return getModelParameters

setGeneric("getModelParameters",
           function(object)
           {
             standardGeneric("getModelParameters")
           }
)
setMethod("getModelParameters",
          "StatisticalModel",
          function(object)
          {
            return(object@model_parameters)
          }

)

# -------------------------------------------------------------------------------------------------------------------
#' Get the responses of a statistical model.
#'
#' @name getResponsesStatisticalModel
#' @param object A \code{getResponsesStatisticalModel} object.
#' @return A list giving the responses of a statistical model.


setGeneric("getResponsesStatisticalModel",
           function(object)
           {
             standardGeneric("getResponsesStatisticalModel")
           }
)
setMethod("getResponsesStatisticalModel",
          "StatisticalModel",
          function(object)
          {
            return(object@responses)
          }

)

# -------------------------------------------------------------------------------------------------------------------
#' Get the equations of a statistical model.
#'
#' @name getEquationsStatisticalModel
#' @param object A \code{StatisticalModel} object.
#' @return A \code{ModelEquationsg} object giving the equations of the \code{StatisticalModel} object.


setGeneric(
  "getEquationsStatisticalModel",
  function(object) {
    standardGeneric("getEquationsStatisticalModel")
  })

setMethod("getEquationsStatisticalModel",
          signature("StatisticalModel"),
          function(object)
          {
            return( object@modelEquations)
          })


# -------------------------------------------------------------------------------------------------------------------
#' Get the parameters of a statistical model.
#'
#' @name getStatisticalModelParameters
#' @param object A \code{StatisticalModel} object.
#' @return A list giving the equations of the \code{StatisticalModel} object.


setGeneric(
  "getStatisticalModelParameters",
  function(object) {
    standardGeneric("getStatisticalModelParameters")
  })

setMethod("getStatisticalModelParameters",
          signature("StatisticalModel"),
          function(object)
          {
            return( object@model_parameters)
          })


# -------------------------------------------------------------------------------------------------------------------
#' Get the fixed effect parameter names and number.
#'
#' @name getFixedEffectParameterNamesAndNumber
#' @param object A \code{StatisticalModel} object.
#' @return A list giving the parameter names and number for the fixed effects.

setGeneric("getFixedEffectParameterNamesAndNumber",
           function(object)
           {
             standardGeneric("getFixedEffectParameterNamesAndNumber")
           }
)
setMethod("getFixedEffectParameterNamesAndNumber",
          "StatisticalModel",
          function(object)
          {
            muNames <- c()
            i = 0
            for(parameter in object@model_parameters)
            {
              if ( isFixed( parameter ) )
                next
              i = i + 1
              muNames <- c(muNames, paste0("\u03bc_",getNameModelParameter(parameter)))

            }
            return(list(muNames = muNames, FixedEffectParameterNumber = i))
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' getNotZeroRandomEffectParameterNames
#' @name getNotZeroRandomEffectParameterNames
#' @param object \code{getNotZeroRandomEffectParameterNames} object.
#' @return getNotZeroRandomEffectParameterNames

setGeneric("getNotZeroRandomEffectParameterNames",
           function(object)
           {
             standardGeneric("getNotZeroRandomEffectParameterNames")
           }
)
setMethod("getNotZeroRandomEffectParameterNames",
          "StatisticalModel",
          function(object)
          {
            omegaNames <- c()
            zeroOmegaIndex <- c()
            i = 0
            for(parameter in object@model_parameters)
            {
              if ( isFixed( parameter ) )
                next
              i = i + 1
              if(getOmega(parameter) != 0)

                omegaNames <- c(omegaNames, paste0("\u03c9\u00B2_",getNameModelParameter(parameter)))

              else
                zeroOmegaIndex <- c( zeroOmegaIndex, i )
            }
            return(list(omegaNames = omegaNames, zeroOmegaIndex = zeroOmegaIndex))
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' getErrorModelStandardErrors
#' @name getErrorModelStandardErrors
#' @param object \code{getErrorModelStandardErrors} object.
#' @param fim ...
#' @return getErrorModelStandardErrors


setGeneric("getErrorModelStandardErrors",
           function(object, fim)
           {
             standardGeneric("getErrorModelStandardErrors")
           }
)
setMethod("getErrorModelStandardErrors",
          "StatisticalModel",
          function(object, fim)
          {
            se <- getSE(fim)
            sigmaCol <- c()
            rseCol <- c()
            for(response in object@responses)
            {
              modelError <- getModelError(response)
              sigmaCol <- c( sigmaCol, getSigmaValues(modelError))
            }


            ## modif ##
            # sort function ?
            # se et sigmaCol peuvent ?tre de taille diff?rente
            if (length(se) != length(sigmaCol)){
              se <- se[-c(1:(length(se)-length(sigmaCol)))]
            }else{
              se <- (sort(se))
            }

            rseCol <- c(rseCol,  se/sigmaCol*100 )

            ## modif : ajout de row.names= NULL


            parameterFrame <- data.frame( value = sigmaCol, se = se, "rse(%)"= rseCol, row.names=NULL, check.names=FALSE)


            return(parameterFrame)
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' showErrorModelStandardErrors
#' @name showErrorModelStandardErrors
#' @param object \code{showErrorModelStandardErrors} object.
#' @param fim ...
#' @return showErrorModelStandardErrors

setGeneric("showErrorModelStandardErrors",
           function(object, fim)
           {
             standardGeneric("showErrorModelStandardErrors")
           }
)
setMethod("showErrorModelStandardErrors",
          "StatisticalModel",
          function(object, fim)
          {
            if ( class( fim ) != "BayesianFim" )
            {
              cat("\n**** error model\n")
              parameterFrame <- getErrorModelStandardErrors(object, fim)
              print(parameterFrame)
            }
          }
)


