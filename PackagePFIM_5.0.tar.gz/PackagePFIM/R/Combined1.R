##################################################################################
##' Class "Combined1"
##'
##' @description .................
##'
##' @name Combined1-class
##' @aliases Combined1
##' @docType class
##' @include ModelError.R
##' @exportClass Combined1
##'
##' @section Objects from the Class: Combined1 objects
##' are typically created by calls to \code{{...}} and contain the following slots
##' that are heritated from the class Combined1c:
##'
##' \describe{
##' \item{.Object}{...}
##' \item{sigma_inter}{...}
##' \item{sigma_slope}{...}
##' \item{c_error}{...}
##' \item{equation}{...}
##' }
##'

Combined1<-setClass(
  Class="Combined1",
  contains = "ModelError",
  prototype = prototype(
    c_error = 1
  ),
  validity=function(object)
  {
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f="initialize",
  signature="Combined1",
  definition= function (.Object, sigma_inter, sigma_slope )
  {
    # Object validation
    validObject(.Object)
    .Object = callNextMethod(.Object, sigma_inter = sigma_inter, sigma_slope = sigma_slope, c_error = 1, expression( sigma_inter + sigma_slope * f_x_i_theta ) )
    return (.Object )
  }


)

# -------------------------------------------------------------------------------------------------------------------

#' Get the variances \deqn{\sigma_{inter}} and \deqn{\sigma_{slope}}
#' @name getSigmaNames
#' @param object A \code{Combined1} object.
#' @return The variances \deqn{\sigma_{inter}} and \deqn{\sigma_{slope}}

setMethod("getSigmaNames",
          "Combined1",
          function(object)
          {
            sigmaNames <- c( )
            if(object@sigma_inter != 0)
              sigmaNames <- c( sigmaNames, "\u03c3_inter")
            if(object@sigma_slope != 0)
              sigmaNames <- c( sigmaNames, "\u03c3_slope" )
            return(sigmaNames)
          }
)

# -------------------------------------------------------------------------------------------------------------------

#' Get the values of the variances \deqn{\sigma_{inter}} and \deqn{\sigma_{slope}}
#' @name getSigmaValues
#' @param object A \code{Combined1} object.
#' @return A vector giving the values of the variances \deqn{\sigma_{inter}} and \deqn{\sigma_{slope}}

setMethod("getSigmaValues",
          "Combined1",
          function(object)
          {
            sigmaValues <- c( )
            if(object@sigma_inter != 0)
              sigmaValues <- c( sigmaValues, object@sigma_inter)
            if(object@sigma_slope != 0)
              sigmaValues <- c( sigmaValues, object@sigma_slope )
            return(sigmaValues)
          }

)

# -------------------------------------------------------------------------------------------------------------------

#' Show the model errors.
#' @name show
#' @param object \code{Combined1} object.
#' @return The model errors.


setMethod(f="show",
          signature=  "Combined1",
          definition=function(object)
          {
            eq <- gsub("f_x_i_theta", "f", toString(object@equation))
            cat(" Error model combined 1 equation : ", eq, "\n")
            callNextMethod(object)

          }
)
