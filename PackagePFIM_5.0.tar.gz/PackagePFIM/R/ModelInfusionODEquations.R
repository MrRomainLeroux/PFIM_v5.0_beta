
##################################################################################
##' Class "ModelInfusionODEquations" representing a model with infusion equations in ODE
##'
##' @description
##' A class giving information on the infusion equations regarding the equations of the model.
##'
##' @name ModelInfusionODEquations-class
##' @aliases ModelInfusionODEquations
##' @include ModelODEquations.R
##' @docType class
##' @exportClass ModelInfusionODEquations
##'
##' @section Objects from the Class: ModelInfusionODEquations objects are typically created by calls to \code{{ModelInfusionODEquations}} and contain the following slots:
##'
##' \describe{
##' \item{\code{object}:}{An object from the class \code{ModelEquations}}
##' }

ModelInfusionODEquations <- setClass(
  Class = "ModelInfusionODEquations",
  contains = "ModelODEquations",
  representation = representation(
    duringInfusionResponsesEquations = "list",
    afterInfusionResponsesEquations = "list",
    duringInfusionDerivatives = "list",
    afterInfusionDerivatives = "list" ,
    derivatives = "list"),
  validity = function(object)
  {
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f = "initialize",
  signature = "ModelInfusionODEquations",
  definition = function(.Object, duringInfusionResponsesEquations, afterInfusionResponsesEquations,  duringInfusionDerivatives, afterInfusionDerivatives, derivatives )
  {

    .Object@duringInfusionResponsesEquations = duringInfusionResponsesEquations
    .Object@afterInfusionResponsesEquations = afterInfusionResponsesEquations
    .Object@duringInfusionDerivatives = duringInfusionDerivatives
    .Object@afterInfusionDerivatives = afterInfusionDerivatives
    .Object@derivatives = c(duringInfusionDerivatives,afterInfusionDerivatives)

    return(.Object)
  }
)

setMethod("getResponseIndice",
          "ModelInfusionODEquations",
          function(object, equationName)
          {
            responseNames <- names( unlist( object@duringInfusionResponsesEquations ) )

            i = 1

            for ( responseName in responseNames )
            {

              if( substring( responseName, nchar( responseName ) - nchar( equationName ) + 1 )  == equationName )
              {
                return( i )
              }

              i = i + 1
            }

            return( integer(0) )
          }
)


#' Evaluate the derivatives of a \code{ModelInfusionODEquations} object.
#' @rdname EvaluateDerivativesOLD
#' @param .Object A \code{ModelInfusionODEquations} object.
#' @param times A vector of the times.
#' @param cond_init A list of the initial condition.
#' @param model_parameters A vector of character string of the model parameters.
#' @param compute_C_trough  ...
#' @param c_trough ...
#' @param responseIndice ...
#' @param doseIndice ...
#' @param equation ...
#' @param administrations ...
#' @return A list of expression giving the derivatives of a \code{ModelInfusionODEquations} object.



setMethod(f = "EvaluateDerivativesOLD",
          signature="ModelInfusionODEquations",
          definition= function (.Object, times, cond_init, model_parameters, compute_C_trough, c_trough, responseIndice, doseIndice, equation, administrations )
          {

            # --------------------------------------------------------------------------------------------------------------------------------                      # lsoda template
            # --------------------------------------------------------------------------------------------------------------------------------
            dynamicFunction="{ "
            hessianDynamicFunction="{ "
            derivBody = ""
            eqBody = ""
            params = "c( "

            # --------------------------------------------------------------------------------------------------------------------------------                      # lsoda : paste dynamicFunction, hessianDynamicFunction, parameterName
            # --------------------------------------------------------------------------------------------------------------------------------
            i = 1

            for (parameter in model_parameters)
            {
              parameterName = getNameModelParameter( parameter )
              dynamicFunction = paste0( dynamicFunction, parameterName, "=p[", i, "] ; " )
              hessianDynamicFunction = paste0( hessianDynamicFunction, parameterName, "=p[", i, "] ; " )
              params = paste0( params, parameterName )
              if ( i < length( model_parameters ) )
              {
                params = paste0( params, ", " )
              }
              i = i + 1
            }

            params = paste0( params, " )" )

            for(administration in administrations)
            {

              # get parameters from the administration
              outcome = getNameAdministration( administration )

              dose_resp = paste0( "dose_", outcome)
              doses = getAmountDose( administration )
              dose = doses[doseIndice]

              Tinfs = getTinf( administration )
              Tinf_resp = paste0( "Tinf_", outcome)
              Tinf = Tinfs[doseIndice]

              # dose_resp, dose, Tinf_resp, Tinf

              hessianDynamicFunction = paste0( hessianDynamicFunction, dose_resp ," = ", dose, " ; " )
              dynamicFunction = paste0( dynamicFunction, dose_resp, "=", dose, " ; " )

              hessianDynamicFunction = paste0( hessianDynamicFunction, Tinf_resp ," = ", Tinf, " ; " )
              dynamicFunction = paste0( dynamicFunction, Tinf_resp, "=", Tinf, " ; " )

            } # end loop administration

            hessianDynamicFunction = unique(hessianDynamicFunction)
            dynamicFunction = unique(dynamicFunction)

            # sampling times
            numberOfResponses = length( cond_init )

            hessianDynamicFunction = paste( hessianDynamicFunction, "samplingTimes=c( ",
                                            paste( c( times[1], ',' , times[2]), collapse="") ," ) ; Ctrough = tail(p, ", numberOfResponses, " ) ; initialConditions=c( " , collapse="")

            # cond_initial and its index
            if ( length( cond_init ) == 0 )
              cat(" Warning : the initial conditions are not specified.")

            i = 1

            for( cond_initial in cond_init )
            {

              if ( i > 1 )
                hessianDynamicFunction = paste0( hessianDynamicFunction, "," )
              dynamicFunction = paste0( dynamicFunction, paste0("C", i) , "=y[", i , "] ; ")

              hessianDynamicFunction = paste0( hessianDynamicFunction, cond_initial, " + Ctrough[ ", i, " ] " )

              i = i + 1
            }

            # params and responseIndice
            hessianDynamicFunction = paste0(
              hessianDynamicFunction, " ) ;
               ls = lsoda( y=initialConditions, times=samplingTimes, ODEFunction, ", params, " ) ;
               return( ls[2 , ", 1 + length( cond_init ) + responseIndice," ] ) }" )

            # if infusion : equations & derivatives : during or after
            if ( equation == "During" )
            {

              derivatives = .Object@duringInfusionDerivatives
              equations = .Object@duringInfusionResponsesEquations

            }else{

              derivatives = .Object@afterInfusionDerivatives
              equations = .Object@afterInfusionResponsesEquations

            }

            #  deriv, derivBody
            i=1

            for( deriv in derivatives )
            {

             dynamicFunction = paste0( dynamicFunction, "dy", i, "=eval(expression(", deparse1(deriv[[1]]), ")) ; " )

              if ( i > 1 )
                derivBody = paste0( derivBody, "," )

              derivBody = paste0( derivBody, "dy", i )
              i = i + 1
            }

            i = 1

            for( eq in equations )
            {
              dynamicFunction = paste0( dynamicFunction, "Resp", i, "=eval(expression(", deparse1(eq[[1]]), ")) ; " )

              if ( i > 1 )
                eqBody = paste0( eqBody, "," )
              eqBody = paste0( eqBody, "Resp", i )
              i = i + 1
            }

            dynamicFunction = paste0( dynamicFunction, "return( list( c(", derivBody, "), c(", eqBody ,") ) ) ; " )
            dynamicFunction = paste0( dynamicFunction, "} " )

            body( ODETemplateFunction ) = parse( text = dynamicFunction )
            .Object@ODEFunction = ODETemplateFunction

            body( ODEHessianTemplateFunction ) = parse( text = hessianDynamicFunction )
            .Object@ODEHessianFunction = ODEHessianTemplateFunction





            return ( .Object )

          })


