##################################################################################
##' Class "Arm"
##'
##' A class combining the treatment (Administration class) and the sampling schedule (Sampling class)
##'
##' @name Arm-class
##' @aliases Arm-class
##' [,Arm-method [<-,Arm-method
##' @docType class
##' @section Objects from the Class: Arm objects are typically created by calls to \code{{arm}} and contain the following slots:
##'
##' \describe{
##' \item{arm_size}{integer the number of subjects in the arm. Defaults to 1}
##' \item{intervention_sequence}{a list of Administration objects}
##' \item{samplings}{a list of Sampling objects}
##' \item{constraints}{a list of SamplingConstraint objects}
##' \item{occasion_sequence}{if absent, the arm is assumed to have 1 occasion}
##' }
##' @seealso \code{{pfim}}
##' @keywords classes
##'
##' @exportClass Arm

Arm <- setClass(
  Class = "Arm",
  representation = representation(
    name = "character",
    arm_size = "numeric",
    administrations  = "list", # List of objects from Administration class
    cond_init = "list",# Initial conditions for ode models
    samplings = "list", # List of objects from Sampling class
    sampling_constraints = "list" # List of objects from SamplingConstraint class
  ),
  prototype = prototype(
    samplings = list()
  )
  # ,
  #   validity = function(object) {
  #     if (length(object@administrations)==0 | length(object@samplings)==0) {
  #       stop ("[ Arm : validation ] An arm object must have at least one administration object and sampling object.")
  #     }
  #     if(any(lapply(object@administrations, class)!="Administration"))
  #       stop("All elements of the slot administrations have to be of type Administration")
  #     if(any(lapply(object@samplings, class)!="Sampling"))
  #       stop("All elements of the slot samplings have to be of type Sampling")
  #     return(TRUE)
  #   }
  )

setMethod(
  f="initialize",
  signature="Arm",
  definition= function (.Object, name, arm_size, administrations, samplings, cond_init, sampling_constraints )
  {
    if(!missing(name))
      .Object@name<-name
    if(!missing(arm_size))
      .Object@arm_size<-arm_size
    if(!missing(administrations))
      .Object@administrations<-administrations
    if(!missing(samplings))
      .Object@samplings<-samplings
    if(!missing(sampling_constraints))
      .Object@sampling_constraints<-sampling_constraints
    if(!missing(cond_init))
      .Object@cond_init<-cond_init
    validObject(.Object)
    return (.Object )
  }
)

##########################################################################################################

#' Get the response name given the indice of the response.
#'
#' @name getResponseNameByIndice
#' @param object An \code{Arm} object.
#' @param outcomeIndice A numeric giving the indice of the response in the \code{Arm} object.
#' @return A character string giving the name of the response.

setGeneric("getResponseNameByIndice",
           function(object, outcomeIndice)
           {
             standardGeneric("getResponseNameByIndice")
           }
)


setMethod("getResponseNameByIndice",
          "Arm",
          function(object, outcomeIndice)
          {
          return(getNameSampleTime(object@samplings[[outcomeIndice]]))
          }
)

##########################################################################################################

#' Add sampling constraints to an arm.
#'
#' @name addSamplingConstraints
#' @param object An \code{Arm} object.
#' @param sampling_constraints A \code{SamplingConstraint} object giving the sampling constraints added to the \code{Arm} object.
#' @return The \code{Arm} object with the new sampling constraints.

setGeneric("addSamplingConstraints",
           function(object, sampling_constraints)
           {
             standardGeneric("addSamplingConstraints")
           }
)


setMethod("addSamplingConstraints",
          "Arm",
          function(object, sampling_constraints)
          {
            object@sampling_constraints <- append(object@sampling_constraints,sampling_constraints)
            return(object)
          }
)

##########################################################################################################

#' Get the sampling constraints of an arm.
#'
#' @name getSamplingConstraintsInArm
#' @param object An \code{Arm} object.
#' @param responseName A character string givinf the name of the response.
#' @return The \code{SamplingConstraint} object giving the sampling constraints of the \code{Arm} object.

setGeneric("getSamplingConstraintsInArm",
           function(object, responseName)
           {
             standardGeneric("getSamplingConstraintsInArm")
           }
)


setMethod (f="getSamplingConstraintsInArm",
           signature="Arm",
           definition = function(object, responseName)
           {
            constraintsOfTheResponse <- list()
             for (i in object@sampling_constraints){
                 constraintsOfTheResponse <- append( constraintsOfTheResponse,getSamplingConstraints(i,responseName) )
             }
             return(constraintsOfTheResponse)
           }
)

##########################################################################################################

#' Modify the sampling times of an arm.
#'
#' @name modifySamplingTimes
#' @param object An \code{Arm} object.
#' @param outcome A character string giving the name of the outcome i.e. the name of the response.
#' @param samplingTimes A vector of numeric giving the new sampling times.
#' @return The \code{SamplingConstraint} object with the new sampling times of the \code{Arm} object.

setGeneric("modifySamplingTimes",
           function(object, outcome, samplingTimes)
           {
             standardGeneric("modifySamplingTimes")
           }
)


setMethod("modifySamplingTimes",
          "Arm",
          function(object, outcome, samplingTimes)
          {

            if ( outcome %in% names( object@samplings ) )
            {
              object@samplings[[ outcome ]] <- SamplingTimes( outcome = outcome, samplingTimes )
            }
            return(object)
          }
)

##########################################################################################################

#' Get the name of the arm.
#'
#' @name getNameArm
#' @param object \code{Arm} object.
#' @return A character string giving the name of the arm.

setGeneric("getNameArm",
            function(object)
            {
              standardGeneric("getNameArm")
            }
 )

setMethod("getNameArm",
          "Arm",
          function(object)
          {
            return(object@name)
          }
)

##########################################################################################################

#' Get the size of an arm.
#'
#' @name getArmSize
#' @param object An \linkS4class{Arm} object.
#' @return A numeric giving the size of the arm.

setGeneric("getArmSize",
           function(object)
           {
             standardGeneric("getArmSize")
           }
)
setMethod("getArmSize",
          "Arm",
          function(object)
          {
            return(object@arm_size)
          }
)

##########################################################################################################

#' Set the size of an arm.
#'
#' @name setArmSize
#' @param object An \code{Arm} object.
#' @param value A numeric.
#' @return The \code{Arm} object with the new value for the size of the arm.

setGeneric("setArmSize",
           function(object, value)
           {
             standardGeneric("setArmSize")
           }
)
setMethod( f="setArmSize",
           signature="Arm",
           definition = function(object, value)
           {
             object@arm_size <- value
             validObject(object)
             return(object)
           }
)

##########################################################################################################

#' Get the vectors of sampling times for an arm.
#'
#' @name getSamplings
#' @param object An \code{Arm} object.
#' @return A list giving the objects from the class \linkS4class{SamplingTimes}.

setGeneric("getSamplings",
           function(object)
           {
             standardGeneric("getSamplings")
           }
)
setMethod("getSamplings",
          "Arm",
          function(object)
          {
            return(object@samplings)
          }
)

##########################################################################################################

#' Get the number of sampling times in a arm.
#'
#' @name getNumberOfSamplings
#' @param object An \code{Arm} object.
#' @return A numeric giving the number of sampling times in the \code{Arm} object.


setGeneric("getNumberOfSamplings",
           function(object)
           {
             standardGeneric("getNumberOfSamplings")
           }
)
setMethod("getNumberOfSamplings",
          "Arm",
          function(object)
          {
            return(length(object@samplings))
          }
)

##########################################################################################################

#' Get the initial conditions in a arm for an ODE model.
#'
#' @name getCondInit
#' @param object \code{Arm} object.
#' @return A list giving the initial conditions in a arm for ODE model.

setGeneric("getCondInit",
           function(object)
           {
             standardGeneric("getCondInit")
           }
)
setMethod("getCondInit",
          "Arm",
          function(object)
          {
            return(object@cond_init)
          }
)


##########################################################################################################

#' Set the sampling times for an arm.
#'
#' @name setSamplings
#' @param object \code{Arm} object.
#' @param value The sampling times given by the objects from the class \linkS4class{SamplingTimes}.
#' @return The \code{Arm} with the new sampling times.

setGeneric("setSamplings<-",
           function(object, value)
           {
             standardGeneric("setSamplings<-")
           }
)
setReplaceMethod( f="setSamplings",
                  signature="Arm",
                  definition = function(object, value)
                  {
                    object@samplings <- value
                    validObject(object)
                    return(object)
                  }
)


##########################################################################################################

#' Set the initial conditions of an Arm for an ODE model.
#'
#' @name setInitialConditions
#' @param object \code{Arm} object.
#' @param values A list of numeric giving the values of the initial conditions.
#' @return The \code{Arm} object with the new initial conditions for an ODE model.

setGeneric("setInitialConditions",
           function(object, values)
           {
             standardGeneric("setInitialConditions")
           }
)

setMethod( f="setInitialConditions",
                  signature="Arm",
                  definition = function(object, values)
                  {
                    object@cond_init <- values
                    validObject(object)
                    return(object)
                  }
)

##########################################################################################################

#' Add sampling times for an arm and for a response.
#'
#' @name addSampling
#' @param object \code{Arm} object.
#' @param value The objects from the class \linkS4class{SamplingTimes}.
#' @return The \code{Arm} with the new sampling times for an arm and for a response.


setGeneric("addSampling",
           function(object, value)
           {
             standardGeneric("addSampling")
           }
)

setMethod( f="addSampling",
            signature = "Arm",
            definition = function(object, value)
            {
              name = ( value@outcome )

              if(length(object@samplings[[ name ]]) == 0)
                object@samplings[[ name ]] <- value
              else
                cat("You have already used this name for a sampling.\n")
              validObject(object)
              return( object )
            }
)

##########################################################################################################

#' Get the parameters of the administration for an arm.
#'
#' @name getAdministration
#' @param object \code{Arm} object.
#' @return A list of objects from the class \linkS4class{Administration} class giving the parameters of the administration for an arm.


setGeneric("getAdministration",
           function(object)
           {
             standardGeneric("getAdministration")
           }
)
setMethod(f = "getAdministration",
          signature = "Arm",
          definition = function(object)
          {
            return(object@administrations)
          }
)


##########################################################################################################

#' Get the parameters of the administration for an arm given the response of the model.
#'
#' @name getAdministrationByOutcome
#' @param object An \code{Arm} object.
#' @param outcome A character string giving the the name of the response of the model.
#' @return A list of objects from \linkS4class{Administration} class giving the parameters of the administration for the \code{Arm} object.

setGeneric("getAdministrationByOutcome",
           function(object, outcome)
           {
             standardGeneric("getAdministrationByOutcome")
           }
)
setMethod(f = "getAdministrationByOutcome",
          signature = "Arm",
          definition = function(object, outcome)
          {
            for( adm in object@administrations )
              if ( getNameAdministration( adm ) == outcome )
                return( adm )
            print( paste( "Cannot find the outcome ", outcome ) )
            return( NA )
          }
)

##########################################################################################################

#' Add an administration for an arm and for a response.
#'
#' @name addAdministration
#' @param object An \code{Arm} object.
#' @param value ...
#' @return A list of objects from \linkS4class{Administration} class class giving the news values for parameters of the administration for the \code{Arm} object.


setGeneric("addAdministration",
           function(object, value)
           {
             standardGeneric("addAdministration")
           }
)

setMethod( f="addAdministration",
           signature = "Arm",
           definition = function(object, value)
           {

             name = ( value@outcome )
             if(length(object@administrations[[ name ]]) == 0)
               object@administrations[[ name ]] <- value
             else
               cat("You have already used this name for an administration.\n")

             validObject(object)
             return( object )
           }
)


##########################################################################################################

#' Evaluate a statistical model for all the administrations and all the sampling times of the model.
#'
#' @name EvaluateStatisticalModel
#' @param object ....
#' @param statistical_model An object from the class \linkS4class{StatisticalModel} or \linkS4class{ODEStatisticalModel}.
#' @param fim Character string giving the type of the Fisher Information Matrix : "PopulationFim" or "IndividualFim".
#' @return A list giving the evaluated Fisher Information Matrices (individual or population).

setGeneric("EvaluateStatisticalModel",
           function(object, statistical_model, fim )
           {
             standardGeneric("EvaluateStatisticalModel")
           }
)

setMethod(f="EvaluateStatisticalModel",
          signature=  "Arm",
          definition=function(object, statistical_model, fim)
          {

 
            result <- Evaluate( statistical_model, object@administrations, object@samplings, object@cond_init, fim )

            resultFim <- FinalizeFIMForOneElementaryDesign( result$fim, object )

            concentrationModel <- result$concentrationModel
            sensitivityIndicesModel <- result$sensitivityIndicesModel
            samplingTimesWithTauAndTinfModel <- result$samplingTimesWithTauAndTinfModel
            samplingTinfTauForPlot <- result$samplingTinfTauForPlot

            return( list( resultFim = resultFim,
                          concentrationModel = concentrationModel,
                          sensitivityIndicesModel = sensitivityIndicesModel,
                          samplingTimesWithTauAndTinfModel = samplingTimesWithTauAndTinfModel,
                          samplingTinfTauForPlot = samplingTinfTauForPlot
            ) )
            })

##########################################################################################################
# END Class "Arm"
##########################################################################################################















