##################################################################################
##' Class "Combined2"
##'
##' @description .................
##'
##' @name Combined2-class
##' @aliases Combined2
##' @docType class
##' @include Combined2c.R
##' @exportClass Combined2
##'
##' @section Objects from the Class: Combined2 objects are typically created by calls to \code{{...}}
##' and contain the following slots that are heritated from the class Combined2c:
##' \describe{
##' \item{.Object}{...}
##' \item{sigma_inter}{...}
##' \item{sigma_slope}{...}
##' \item{c_error}{...}
##' \item{equation}{...}
##' }
Combined2<-setClass(
  Class="Combined2",
  contains = "Combined2c",
  validity=function(object)
  {
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f="initialize",
  signature="Combined2",
  definition= function (.Object, sigma_inter, sigma_slope)
  {
    c_error = 1
    # Object validation
    validObject(.Object)
    .Object = callNextMethod(.Object, sigma_inter, sigma_slope, c_error, equation = expression( sigma_inter ^ 2 + sigma_slope ^ 2 * f_x_i_theta ) )
    return (.Object )
  }
)

#' getSigmaNames
#' @name getSigmaNames
#' @param object \code{Combined2} object.
#' @return ...


setMethod("getSigmaNames",
          "Combined2",
          function(object)
          {
            sigmaNames <- c( )
            if(object@sigma_inter != 0)
              sigmaNames <- c( sigmaNames, "\u03c3_inter")
            if(object@sigma_slope != 0)
              sigmaNames <- c( sigmaNames, "\u03c3_slope" )
            return(sigmaNames)
          }
)

#' getSigmaValues
#' @name getSigmaValues
#' @param object \code{Combined2} object.
#' @return ...
#'
setMethod("getSigmaValues",
          "Combined2",
          function(object)
          {
            sigmaValues <- c( )
            if(object@sigma_inter != 0)
              sigmaValues <- c( sigmaValues, object@sigma_inter)
            if(object@sigma_slope != 0)
              sigmaValues <- c( sigmaValues, object@sigma_slope )
            return(sigmaValues)
          }

)

#' show
#' @name show
#' @param object \code{Combined2} object.
#' @return ...

setMethod(f="show",
          signature=  "Combined2",
          definition=function(object)
          {
            eq <- gsub("f_x_i_theta", "f", toString(object@equation))
            cat(" Error model combined 2c equation : ",eq, "\n")
            callNextMethod(object)
          }
)

