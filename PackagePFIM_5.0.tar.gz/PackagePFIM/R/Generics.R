### List of all generics functions

setGeneric("getName",
           function(object)
           {
             standardGeneric("getName")
           }
)


