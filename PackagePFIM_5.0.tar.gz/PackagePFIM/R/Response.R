##########################################################################################################
#' Class "Response"
#'
#' @description Class "Response" represents a structural model.
#'
#' @name Response-class
#' @aliases Response
#' @docType class
#' @include ModelError.R
#' @exportClass Response
#'
#' @section Objects from the Class:
#' \code{Response} objects are typically created by calls to \code{Response} and contain the following slots
#' model_error = g(sigma_inter, sigma_slope , f(x, theta)), this part is considered in class \linkS4class{ModelError}.
#' There are different possibilities to calculate g.
#'
#' @section Slots for \code{Response} objects:
#'\describe{
#'\item{\code{name}:}{A character string giving the name for model error.}
#'\item{\code{model_error}:}{An object \code{model_error} from the Class \linkS4class{ModelError}}
#'}


Response <- setClass(Class = "Response",
                     representation = representation
                     (
                       name = "character",
                       model_error = "ModelError"

                     ),
                     prototype = prototype(
                       name = paste("Response_", ceiling( runif(1) * 100000 ), sep="" )
                     )
)

setMethod(
  f="initialize",
  signature="Response",
  definition= function (.Object, name, model_error)
  {
    if(!missing(name))
      .Object@name <- name

    if(!missing(model_error))
      .Object@model_error <- model_error

    validObject(.Object)
    return (.Object )
  }
)


##########################################################################################################

#' Get the name of the response of the model.
#' @name getNameResponse
#' @param object A \code{Response} object.
#' @return A character string \code{name} giving the name of the response of the model.

setGeneric("getNameResponse",
           function(object)
           {
             standardGeneric("getNameResponse")
           }
)

setMethod("getNameResponse",
          "Response",
          function(object)
          {
            return(object@name)
          }
)


##########################################################################################################
#' Get the model error.
#' @name getModelError
#' @param object A \code{Response} object.
#' @return The object

setGeneric("getModelError",
           function(object)
           {
             standardGeneric("getModelError")
           }
)
setMethod("getModelError",
          "Response",
          function(object)
          {
            return(object@model_error)
          }
)

##########################################################################################################
#' Set the model error.
#' @name setModelError
#' @param object A \code{Response} object.
#' @param value ...
#' @return The \code{Response} object with the new value for the model error.

setGeneric("setModelError<-",
           function(object, value)
           {
             standardGeneric("setModelError<-")
           }
)
setReplaceMethod( f="setModelError",
                  signature="Response",
                  definition = function(object, value)
                  {
                    object@model_error <- value
                    validObject(object)
                    return(object)
                  }
)


##########################################################################################################
#' Evaluate the Error Model Derivatives
#' @name EvaluateErrorModelDerivatives
#' @param object A \code{Response} object.
#' @param f_x_i_theta  The nonlinear structural model \code{f_x_i_theta}
#' @return A list giving the error variance \code{V_sig} and sigma derivatives \code{sigmaDerivatives} of the model error.

setGeneric("EvaluateErrorModelDerivatives",
           function(object, f_x_i_theta ) #
           {
             standardGeneric("EvaluateErrorModelDerivatives")
           }
)

setMethod(f="EvaluateErrorModelDerivatives",
          signature=  "Response",
          definition=function(object, f_x_i_theta )
          {

            I = diag( length( f_x_i_theta ) )

            V_sig = ( g( object@model_error, f_x_i_theta = f_x_i_theta ) ^ 2 ) * I
            ### Build the matrix of sigmas

            sigmaDerivatives  = getSig( object@model_error, f_x_i_theta )

            return( list( errorVariance = V_sig, sigmaDerivatives = sigmaDerivatives ) )
          }
)

##########################################################################################################
#' Evaluate the ODE Error Model Derivatives
#' @name EvaluateODEErrorModelDerivatives
#' @param object \code{Response} object.
#' @param f_x_i_theta  The nonlinear structural model \code{f_x_i_theta}
#' @return A list giving the error variance \code{V_sig} and sigma derivatives \code{sigmaDerivatives} of the model error in ODE.


setGeneric("EvaluateODEErrorModelDerivatives",
           function( object, f_x_i_theta )
           {
             standardGeneric("EvaluateODEErrorModelDerivatives")
           }
)

setMethod(f="EvaluateODEErrorModelDerivatives",
          signature=  "Response",
          definition=function(object, f_x_i_theta )
          {
            I = diag( length( f_x_i_theta ) )
            V_sig = ( g( object@model_error, f_x_i_theta = f_x_i_theta ) ^ 2 ) * I
            sigmaDerivatives  = getSig( object@model_error, f_x_i_theta )
            return( list( errorVariance = V_sig, sigmaDerivatives = sigmaDerivatives ) )
          }
)

#######################################################################################

setGeneric("computeODEInfusion",
           function( object, equations, model_parameters, administrations, sampling_times, cond_init )
           {
             standardGeneric("computeODEInfusion")
           }
)

setGeneric("computeODE",
           function( object, equations, model_parameters, administrations, sampling_times, cond_init )
           {
             standardGeneric("computeODE")
           }
)

setGeneric("computeAnalytic",
           function( object, equations, model_parameters, administrations, sampling_times, cond_init, isInfusion )
           {
             standardGeneric("computeAnalytic")
           }
)

#############################################################################################################################################

setMethod(f="computeODE",
          signature=  "Response",
          definition=function(  object, equations, model_parameters, administrations, sampling_times, cond_init )
          {

            infusion = FALSE

            dataForLsoda = list()

            numberOfResponse = length( cond_init )

            # Number of parameter of the model
            nbParameters = length( model_parameters )

            # Response name
            responseName = object@name

            # Get the indice of the response in the equations model list
            responseIndice = getResponseIndice( equations, responseName )

            # List for the derivatives of the equations
            derivates = list()

            # List of equations to compute fxi_theta
            respEquations = list()

            # Put the dose regimen of the response into dose

            administrationTimes = c()

            # no scaling for the concentration
            namesInputVariables  =  names( cond_init )

            modelEquations = equations
            equationsScaled = modelEquations@equations


            for( iter in 1:length( namesInputVariables ) )
            {
              equations@equations[[ iter ]] = parse( text = namesInputVariables[ iter ] )
            }


            for( adm in administrations )
            {
              assign( paste0( "dose_", getNameAdministration( adm ) ), getAmountDose( adm ) )
              administrationTimes = c( administrationTimes, getTimeDose( adm ) )

              #assign( paste0( "dose_DuringInfusion_", getNameAdministration( adm ) ), getAmountDose( adm ) )
              #assign( paste0( "dose_AfterInfusion_", getNameAdministration( adm ) ), getAmountDose( adm ) )

            }


            for( iter in 1:numberOfResponse)

            {

              administration = administrations[[ 1 ]]

              hp<-NA

              # case : ModelODEquations

              administrationTimes = c()

              if ( any( isS4( administration ) ) )
                administrationTimes = getTimeDose( administration )

              predictedResponses = c()
              mu = c()
              parameters = c()
              for (parameter in model_parameters)
              {
                parameterName = getNameModelParameter( parameter )

                parameters = c(parameters,parameterName)
                # Set the mean value
                muValue = getMu( parameter )
                mu = c( mu, muValue )
              }

              if(is.null(sampling_times[[ iter ]] ))
                assign( "t", 0)
              else
                assign( "t", getSampleTime( sampling_times[[ iter ]] ) )

              # Compute the relative sampling times
              # case for no administration
              if( is.na( administration ) )
              {
                tau = 0
                Tinf = 0
                timeDoses = 0
              }else{
                tau = getTau( administration )
                Tinf = getTinf( administration )
              }

              samplingTimes = sampling_times[[ iter ]]

              # Repeated doses
              if (length(tau)==0)
              {
                tau = 0
                timeDoses = 0
              }


              if (tau !=0 )
              {
                if ( length( administrationTimes ) == 1 )
                  n = max( t )%/% tau
                else
                  n = length( administrationTimes )

                timeDoses = c(0:n)*tau
              }

              # Compute Tinf
              Tinfs = Tinf + timeDoses

              # augmented sampling times
              t = sort( unique( c(t,Tinfs,timeDoses ) ) )

              samplingTinfTauForPlot = c( Tinfs,timeDoses )

              # get the data used for lsoda
              dataForEvaluation = dataForLsoda( samplingTimes, administrationTimes, Tinf, tau, infusion, iter )
              dataForLsoda[[iter]] =  dataForEvaluation$dataForEvaluation
              dataForLsoda[[iter]] = cbind( dataForLsoda[[iter]], responseIndice = rep( iter,length( samplingTimes ) ) )

            }

            dataForLsoda = do.call("rbind", dataForLsoda)
            dataForLsoda = dataForLsoda[order(dataForLsoda$samplingTimes ), ]
            rownames(dataForLsoda) <- 1:dim(dataForLsoda)[1]

            # ---------------------------------------------------------
            # add inial time for sampling time Lsoda
            # ---------------------------------------------------------

            dataForLsoda$samplingTimesForLsodaInit = rep( 0, length( dataForLsoda$samplingTimes ) )

            dataForLsoda = dataForLsoda[, c("samplingTimes","indicesDosesInSamplingTimes",
                                            "samplingTimesForLsodaInit",  "samplingTimesForLsoda",
                                            "equations", "computeCtrough", "computeGradient", "responseIndice") ]

            rownames(dataForLsoda) <- 1:dim(dataForLsoda)[1]
            samplingTimesForPlot = dataForLsoda$samplingTimes


            # residual for the ode
            # ---------------------------------------------------------------------
            # c_trough_current : c_trough computed for the current sampling time
            # c_trough : c_trough used only in lsoda for the current sampling time
            # ---------------------------------------------------------------------

            # residual for the ode
            c_trough = rep( 0, numberOfResponse )
            c_trough_current = rep( 0, numberOfResponse )
            previousTime = 0
            i = 1

            timeForLsoda = dataForLsoda$samplingTimesForLsoda

            #useInitialValue = TRUE
            samplingTimeAtFirstComputeCtrough = 10e6

            for( time in timeForLsoda )
            {

              if ( dataForLsoda$samplingTimes[i] > previousTime  )
              {
                previousTime = dataForLsoda$samplingTimes[i]
                c_trough = c_trough_current
              }


              time_init = dataForLsoda$samplingTimesForLsodaInit[i]
              doseIndice = dataForLsoda$indicesDosesInSamplingTimes[i]
              equation = dataForLsoda$equations[i]
              compute_C_trough = dataForLsoda$computeCtrough[i]
              computeGradient = dataForLsoda$computeGradient[i]
              responseIndice = dataForLsoda$responseIndice[i]

              i = i + 1

              # sampling times for lsoda
              times = c( time_init, time )

              # Test for cond_init


              if ( time > samplingTimeAtFirstComputeCtrough )
              {
                cond_init = rep( 0.0, numberOfResponse )

              }

              equations = EvaluateDerivativesOLD( equations, times, cond_init,
                                                  model_parameters, compute_C_trough, c_trough,
                                                  responseIndice, doseIndice, equation, administrations )

              ODEFunction <<- equations@ODEFunction

              hess = fdHess( c( mu, c_trough ), equations@ODEHessianFunction )

              if ( compute_C_trough == TRUE){
                c_trough_current[responseIndice] = hess$mean
                if(  samplingTimeAtFirstComputeCtrough == 10e6 )
                  samplingTimeAtFirstComputeCtrough = time
              }

              if ( computeGradient == TRUE )
              {
                predictedResponses = c( predictedResponses, hess$mean )

                gradient = hess$gradient[ 1:nbParameters ]

                if ( is.double( hp ) == F )
                  hp<-cbind( gradient )
                else
                  hp<-cbind( hp, gradient )
              }
            }

            listPredictedResponses = list()
            listHp = list()
            listSamplingTimes = list()

            dataForLsoda = dataForLsoda[dataForLsoda$computeGradient == TRUE, ]

            for( i in 1:numberOfResponse)
            {

              listPredictedResponses[[i]] = predictedResponses[ dataForLsoda$responseIndice==i ]
              listHp[[i]] = hp[ , dataForLsoda$responseIndice==i ]
              listSamplingTimes[[i]] = dataForLsoda$samplingTimes[ dataForLsoda$responseIndice==i ]
            }

            nameLists = names( unlist( sampling_times ) )
            names( listHp ) = nameLists
            names( listPredictedResponses ) = nameLists
            names( listSamplingTimes ) = nameLists

            numberSamplingTimesForEachResponse = as.list( tabulate( dataForLsoda$responseIndice ) )
            names( numberSamplingTimesForEachResponse ) = nameLists

            # ------------------------------------------------------------------------------
            # scaling the concentration
            # ------------------------------------------------------------------------------

            concentrationModel = list()

            # assign values to model parameters and ModelVariable
            for ( name in names( model_parameters ) )
            {
              assign( name , getMu( model_parameters[[ name ]] ) )
            }

            for( iter in 1:numberOfResponse)
            {

              assign( namesInputVariables[ iter ] , listPredictedResponses[[ iter ]]  )

            }

            for( iter in 1:numberOfResponse)
            {

              concentrationModel[[ iter ]] =  eval( equationsScaled[[ iter ]] )

            }

            names( concentrationModel ) = nameLists

            # ------------------------------------------------------------------------------

            return( list( listHp, listPredictedResponses, listSamplingTimes,
                          numberSamplingTimesForEachResponse, samplingTinfTauForPlot, concentrationModel ) )


          })

#############################################################################################################################################

setMethod(f="computeAnalytic",
          signature=  "Response",
          definition=function(  object, equations, model_parameters, administrations, sampling_times, cond_init, isInfusion )
          {

            # Number of parameter of the model
            nbParameters = length( model_parameters )

            # Response name
            responseName = object@name

            # Get the indice of the response in the equations model list
            responseIndice = getResponseIndice( equations, responseName )

            # List for the derivatives of the equations
            derivates = list()

            # List of equations to compute fxi_theta
            respEquations = list()

            # Put the dose regimen of the response into dose

            administrationTimes = c()

            for( adm in administrations )
            {
              assign( paste0( "dose_", getNameAdministration( adm ) ), getAmountDose( adm ) )
              administrationTimes = c( administrationTimes, getTimeDose( adm ) )

              if ( isInfusion == TRUE )
              {
                assign( paste0( "dose_DuringInfusion_", getNameAdministration( adm ) ), getAmountDose( adm ) )
                assign( paste0( "dose_AfterInfusion_", getNameAdministration( adm ) ), getAmountDose( adm ) )
              }
            }

            # Administration for the response, NA if no dose

            if ( exists( responseName, administrations ) )
              administration = administrations[[ responseName ]]
            else
              administration = NA

            hp<-NA

            firstParameter = T
            for (parameter in model_parameters)
            {

              parameterName = getNameModelParameter( parameter )
              ### Set the mean value
              muValue = getMu( parameter )
              assign( parameterName, muValue )

              if ( isNotFixed( parameter ) )
              {
                if ( isInfusion == TRUE )
                {
                  ### Store the "during infusion" equation derivative
                  equationName = paste0( "DuringInfusion_",responseName )
                  equation = getEquation( equations, equationName )
                  ### Compute the Dericative for parameter 'parameterName'
                  derivates[[ paste0( equationName, parameterName ) ]] = D(equation, parameterName )
                  ### Equation used for the fxi_theta calculation during infusion
                  respEquations[[ equationName ]] = equation
                  ### Store the "after infusion" equation derivative
                  equationName = paste0( "AfterInfusion_",responseName )
                  equation = getEquation( equations, equationName )
                  ### Compute the Derivative for parameter 'parameterName'
                  derivates[[ paste0( equationName, parameterName ) ]] = D(equation, parameterName )
                  ### Equation used for the fxi_theta calculation after infusion
                  respEquations[[ equationName ]] = equation
                }
                else
                {

                  equation = getEquation( equations, responseName )

                  ### Compute the Derivative for parameter 'parameterName'
                  derivates[[ parameterName ]] = D(equation, parameterName )

                  ### Equation used for the fxi_theta calculation
                  equationName = responseName

                  respEquations[[ responseName ]] = equation

                }
              }

            }

            fxiTheta = c()

            for (parameter in model_parameters)
            {
              parameterName = getNameModelParameter( parameter )

              if ( isFixed( parameter ) )
                next
              ### Find the time dose (Administration) vector relatives to the dose response
              vars = all.vars( respEquations[[ equationName ]] )
              nVarDose = sum( substr(vars,1,5)=="dose_" )


              if ( nVarDose > 0 )
              {
                w_ = which(substr(vars,1,5)=="dose_")
                outcome = substr( vars[ w_ ], 6, nchar( vars[ w_ ] ) )

                #modif# Select "Resp"from outcome
                outcome = sub("^[^_]*_", "", outcome)

                ### Administration for the response

                if (!is.null( administrations[[ outcome ]]))

                {

                  administration = administrations[[ outcome ]]
                  time_dose = getTimeDose( administration )
                  if(any(is.na(time_dose))){

                    time_dose=c(0)
                  }

                  tau = getTau( administration )
                }

              }
              else
              {
                administration = NA
                time_dose = c(0)

              }

              samplingTimes = getSampleTime( sampling_times[[ responseName ]] )

              if ( isS4( administration )  & any( is.na( time_dose[ 1 ] ) ) )

              {

                tau = getTau( administration )
                len = tail( samplingTimes, 1 ) %/% tau
                time_dose = tau * ( 0:len )

              }

              {

                ev = c()
                for( st in samplingTimes )
                {
                  ind = 1
                  partialEv = 0
                  partialFxiTheta = 0

                  for( tdose in time_dose )
                  {
                    if ( st < tdose )
                      break
                    t = st - tdose
                    ### For infusion model (InfusionEquations)
                    if ( isInfusion == TRUE )
                    {
                      Tinf = getTinf( administration )

                      if ( length( Tinf ) > 1 )
                        Tinf = Tinf[ ind ]
                      else
                        Tinf = Tinf[ 1 ]

                      if ( t < Tinf )
                      {
                        equationName = paste0( "DuringInfusion_",responseName )
                      }
                      else
                        equationName = paste0( "AfterInfusion_",responseName )

                      derivativeName = paste0( equationName, parameterName )
                    }
                    else# For non-infusion, multi doses, use the derivate of the equation for the parameter "parameterName"
                      derivativeName = parameterName

                    ### evaluate the Derivative for parameter 'parameterName' and equation equationName
                    derivative = derivates[[ derivativeName ]]

                    if ( derivative != 0 )
                    {
                      fxi = eval(derivative )

                      if ( length( fxi ) == 1 )## Same repeated dose amount
                        partialEv<- partialEv + fxi
                      else
                        partialEv<- partialEv + fxi[ ind ]## Different repeated dose amount
                    }

                    if ( firstParameter )
                    {
                      fxiEvaluation = eval( respEquations[[ equationName ]])

                      if ( length( fxiEvaluation ) == 1 )## Same repeated dose amount
                        partialFxiTheta <- partialFxiTheta + fxiEvaluation
                      else
                        partialFxiTheta <- partialFxiTheta + fxiEvaluation[ ind ]
                    }
                    ind = ind + 1
                  }

                  ev <- c( ev, partialEv )


                  if ( firstParameter )
                  {
                    fxiTheta <- c( fxiTheta, partialFxiTheta )
                  }
                }
                firstParameter = F
              }

              if ( is.double( hp ) == F )
              { hp<-cbind( ev ) }
              else
              { hp<-cbind( hp, ev ) }

            } # end parameter

            return( list( hp, fxiTheta, samplingTimes ) )

          })

#############################################################################################################################################

setMethod(f="computeODEInfusion",
          signature=  "Response",
          definition=function(  object, equations, model_parameters, administrations, sampling_times, cond_init )
          {


            infusion = TRUE

            dataForLsoda = list()

            numberOfResponse = length( cond_init )

            # Number of parameter of the model
            nbParameters = length( model_parameters )

            # Response name
            responseName = object@name

            # Get the indice of the response in the equations model list
            responseIndice = getResponseIndice( equations, responseName )

            # List for the derivatives of the equations
            derivates = list()

            # List of equations to compute fxi_theta
            respEquations = list()

            # Put the dose regimen of the response into dose

            administrationTimes = c()

            listTinfs = list()

            # no scaling for the concentration
            namesInputVariables  = names( cond_init )

            modelEquations = equations
            equationsScaled = modelEquations@duringInfusionResponsesEquations

            for( iter in 1:length( namesInputVariables ) )
            {
              equations@duringInfusionResponsesEquations[[ iter ]] = parse( text = namesInputVariables[ iter ] )
              equations@afterInfusionResponsesEquations[[ iter ]] = parse( text = namesInputVariables[ iter ] )

            }


            # assign administrations
            for( adm in administrations )
            {
              assign( paste0( "dose_", getNameAdministration( adm ) ), getAmountDose( adm ) )
              administrationTimes = c( administrationTimes, getTimeDose( adm ) )

              assign( paste0( "dose_DuringInfusion_", getNameAdministration( adm ) ), getAmountDose( adm ) )
              assign( paste0( "dose_AfterInfusion_", getNameAdministration( adm ) ), getAmountDose( adm ) )

              listTinfs = append( listTinfs, getTinf( adm ) )

            }

            # --------------------------------------------------------------------------------------------
            # dataframe : indiceResponse & indiceAdministration  for the pk pd equations
            # --------------------------------------------------------------------------------------------

            numberOfResponsePK = length( administrations)
            numberOfResponsePD = numberOfResponse - numberOfResponsePK
            indicesRespPK = 1:length( administrations)
            indicesRespPD = (length( administrations)+1):numberOfResponse

            listTinfs = unlist( listTinfs )

            # --------------------------------------------------------------------------------------------
            # for pkpkpd model : to keep predicted value for samplingtimeRespPD
            # --------------------------------------------------------------------------------------------
            samplingtimeRespPD = list()

            # --------------------------------------------------------------------------------------------
            # select administration : pkpd and pkpkpd models
            # --------------------------------------------------------------------------------------------

            if (numberOfResponsePK == 1 )
            {
              indiceResponse = seq(1,numberOfResponsePK+numberOfResponsePD)
              indiceAdministration = rep(1,numberOfResponsePK+numberOfResponsePD)

            }else if (numberOfResponsePK > 1 )
            {
              indiceResponse = seq(1,numberOfResponsePK+numberOfResponsePD)

              indexMaxTinfs = which.max( listTinfs )

              vecForRespPD = rep( indiceResponse[indexMaxTinfs],numberOfResponsePD )

              indiceAdministration = c(seq(1,numberOfResponsePK),vecForRespPD)


            }

            dataIndiceResponseAndAdministration = data.frame( indiceResponse = indiceResponse,
                                                              indiceAdministration = indiceAdministration )

            for ( i in 1:numberOfResponse )
            {

              indiceAdministration = dataIndiceResponseAndAdministration$indiceAdministration[i]
              indiceResponse  = dataIndiceResponseAndAdministration$indiceResponse[i]

              administration = administrations[[ indiceAdministration ]]

              hp<-NA

              administrationTimes = c()

              if ( any( isS4( administration ) ) )
                administrationTimes = getTimeDose( administration )

              predictedResponses = c()
              mu = c()

              for (parameter in model_parameters)
              {
                parameterName = getNameModelParameter( parameter )

                # Set the mean value
                muValue = getMu( parameter )
                mu = c( mu, muValue )
              }

              if(is.null(sampling_times[[ indiceResponse ]] ))
                assign( "t", 0)
              else
                assign( "t", getSampleTime( sampling_times[[ indiceResponse ]] ) )

              # Compute the relative sampling times
              # case for no administration
              if( is.na( administration ) )
              {
                tau = 0
                Tinf = 0
                timeDoses = 0
              }else{
                tau = getTau( administration )
                Tinf = getTinf( administration )
              }

              # ------------------------------------------------------------------------------------
              # for pkpkpd model : sampling time for respPD
              # ------------------------------------------------------------------------------------

              if ( numberOfResponsePK > 1)
              {
                if ( i > numberOfResponsePK )
                {
                  samplingtimeRespPD[[i]] = getSampleTime( sampling_times[[ i ]] )
                  samplingtimeRespPK = getSampleTime( sampling_times[[ indiceAdministration ]] )
                  newSamplingTimes = sort( unique( c( unlist( samplingtimeRespPD[[i]] ) ,  samplingtimeRespPK ) ) )
                  sampling_times[[ i ]]@sample_time = newSamplingTimes
                }
              }

              # remove NULL element in samplingtimeRespPD
              samplingtimeRespPD = Filter( Negate( is.null ), samplingtimeRespPD )

              # samplingTimes used for dataForLsoda
              samplingTimes = sampling_times[[ indiceResponse ]]

              # ------------------------------------------------------------------------------------
              # Repeated doses
              # ------------------------------------------------------------------------------------

              if (length(tau)==0)
              {
                tau = 0
                timeDoses = 0
              }

              if (tau !=0 )
              {
                if ( length( administrationTimes ) == 1 )
                  n = max( t )%/% tau
                else
                  n = length( administrationTimes )

                timeDoses = c(0:n)*tau
              }

              # Compute Tinfs
              Tinfs = Tinf + timeDoses

              # augmented sampling times
              t = sort( unique( c( t,Tinfs,timeDoses ) ) )

              # vector for plot
              samplingTinfTauForPlot = c( Tinfs,timeDoses )

              # ------------------------------------------------------------------------------------
              # get the data used for lsoda
              # ------------------------------------------------------------------------------------

              dataForEvaluation = dataForLsoda( samplingTimes, administrationTimes, Tinf, tau, infusion, i )
              dataForLsoda[[i]] = dataForEvaluation$dataForEvaluation
              dataForLsoda[[i]] = cbind( dataForLsoda[[i]], responseIndice = rep( indiceResponse, length( samplingTimes ) ) )

            }

            dataForLsoda = do.call("rbind", dataForLsoda)
            dataForLsoda = dataForLsoda[order(dataForLsoda$samplingTimes ), ]
            rownames(dataForLsoda) <- 1:dim(dataForLsoda)[1]

            dataForLsoda$samplingTimesForLsodaInit = rep( 0, length( dataForLsoda$samplingTimes ) )

            dataForLsoda = dataForLsoda[, c("samplingTimes","indicesDosesInSamplingTimes",
                                            "samplingTimesForLsodaInit",  "samplingTimesForLsoda",
                                            "equations", "computeCtrough", "computeGradient", "responseIndice") ]

            rownames( dataForLsoda ) <- 1:dim( dataForLsoda )[1]


            # -----------------------------------------------------------------
            # for PKPKPD
            # substract Tinfs for the sampling times of the Responses PD
            # -----------------------------------------------------------------

            if ( numberOfResponsePK > 1 )
            {
              for ( i in 1:numberOfResponsePD )
              {
                indiceResponsePD = numberOfResponsePK + i

                # sampling time pd response
                x = dataForLsoda$samplingTimes[ dataForLsoda$responseIndice == indiceResponsePD ]

                # sampling time split
                interval.vector = sort( c( listTinfs, max( x ) ) )
                x.cut = cut( x, breaks = interval.vector, include.lowest = FALSE )
                samplingTimesSplit = data.frame( x, x.cut, group = as.numeric( x.cut ) )
                samplingTimesSplit$Tinf = interval.vector[ samplingTimesSplit$group ]
                samplingTimesSplit$Tinf[ is.na( samplingTimesSplit$Tinf ) ] = 0
                x =  samplingTimesSplit$x -samplingTimesSplit$Tinf

                dataForLsoda$samplingTimesForLsoda[ dataForLsoda$responseIndice == indiceResponsePD ] = x
              }

              # ---------------------------------------------------------------------
              # for model pkpkd
              # computeCtrough = TRUE for all respPD at Tinf Responses PK
              # ---------------------------------------------------------------------

              dataForLsoda$computeCtrough[dataForLsoda$samplingTimes  %in% listTinfs & dataForLsoda$responseIndice  > numberOfResponsePK ] = TRUE

            } # end condition numberOfResponsePK > 1 ie pkpkd model

            # ---------------------------------------------------------------------
            # c_trough_current : c_trough computed for the current sampling time
            # c_trough : c_trough used only in lsoda for the current sampling time
            # ---------------------------------------------------------------------

            # residual for the ode
            c_trough = rep( 0, numberOfResponse )
            c_trough_current = rep( 0, numberOfResponse )
            i = 1

            timeForLsoda = dataForLsoda$samplingTimesForLsoda
            previousTime = 0

            # ---------------------------------------------------------------------------------------------------
            # useInitialValue_current : set to TRUE when the first is computed
            # useInitialValue : if TRUE use initialConditions else use vector of 0 for initial conditions
            # ---------------------------------------------------------------------------------------------------

            #useInitialValue = TRUE
            samplingTimeAtFirstComputeCtrough = 10e6

            for( time in timeForLsoda )
            {
              if ( dataForLsoda$samplingTimes[i] > previousTime  )
              {
                previousTime = dataForLsoda$samplingTimes[i]
                c_trough = c_trough_current
              }

              time_init = dataForLsoda$samplingTimesForLsodaInit[i]
              doseIndice = dataForLsoda$indicesDosesInSamplingTimes[i]
              equation = dataForLsoda$equations[i]
              compute_C_trough = dataForLsoda$computeCtrough[i]
              computeGradient = dataForLsoda$computeGradient[i]
              responseIndice = dataForLsoda$responseIndice[i]

              #---------------------------------------------------------------------
              # Set cond_init = 0 when samplingTimes > Tinfs
              # ---------------------------------------------------------------------

              if ( dataForLsoda$samplingTimes[i]  > min( listTinfs ) )
              {
                cond_init[ numberOfResponsePK : length( cond_init ) ] = 0.0
              }

              i = i + 1

              # sampling times for lsoda
              times = c( time_init, time )

              # Test for cond_init
              if ( time > samplingTimeAtFirstComputeCtrough )
                cond_init = rep( 0.0, numberOfResponse )

              equations = EvaluateDerivativesOLD( equations, times, cond_init,
                                                  model_parameters, compute_C_trough,c_trough, responseIndice,
                                                  doseIndice, equation, administrations )

              ODEFunction <<- equations@ODEFunction

              hess = fdHess( c( mu, c_trough ), equations@ODEHessianFunction )

              if ( compute_C_trough == TRUE){
                c_trough_current[responseIndice] = hess$mean
                if(  samplingTimeAtFirstComputeCtrough == 10e6 )
                  samplingTimeAtFirstComputeCtrough = time
              }

              if ( computeGradient == TRUE )
              {
                predictedResponses = c( predictedResponses, hess$mean )

                gradient = hess$gradient[ 1:nbParameters ]

                if ( is.double( hp ) == F )
                  hp<-cbind( gradient )
                else
                  hp<-cbind( hp, gradient )
              }
            }

            listPredictedResponses = list()
            listHp = list()
            listSamplingTimes = list()

            # keep only values for computeGradient = TRUE for the FIM
            dataForLsoda = dataForLsoda[dataForLsoda$computeGradient == TRUE, ]

            # ----------------------------------------------------------------------------
            # lists for the FIM and plot
            # ----------------------------------------------------------------------------

            for( i in 1:numberOfResponse)
            {
              listPredictedResponses[[i]] = predictedResponses[ dataForLsoda$responseIndice==i ]
              listHp[[i]] = hp[ , dataForLsoda$responseIndice==i ]
              listSamplingTimes[[i]] = dataForLsoda$samplingTimes[ dataForLsoda$responseIndice==i ]
            }

            nameLists = names( unlist( sampling_times ) )
            names( listHp ) = nameLists
            names( listPredictedResponses ) = nameLists
            names( listSamplingTimes ) = nameLists

            # ----------------------------------------------------------------------------
            # select value for the pkpkpd model
            # ----------------------------------------------------------------------------

            if ( numberOfResponsePK > 1 )
            {
              for ( i in 1:numberOfResponsePD)
              {
                indiceResponsePD = numberOfResponsePK + i
                indiceRepPDForFIM = which( unlist( listSamplingTimes[ indiceResponsePD ] ) %in%  samplingtimeRespPD[[ i ]] )
                listPredictedResponses[[ indiceResponsePD ]] = unlist( listPredictedResponses[[ indiceResponsePD ]] )[ indiceRepPDForFIM ]
                listSamplingTimes[[ indiceResponsePD ]] = unlist(  listSamplingTimes[[ indiceResponsePD ]] )[ indiceRepPDForFIM ]
                listHp[[ indiceResponsePD ]] = listHp[[ indiceResponsePD ]][, indiceRepPDForFIM ]
              }
            }

            numberSamplingTimesForEachResponse = rapply( listPredictedResponses, length, how="list" )

            concentrationModel = list()
            concentrationModel = listPredictedResponses
            names( concentrationModel ) = nameLists

            # ------------------------------------------------------------------------------
            # scaling the concentration
            # ------------------------------------------------------------------------------

            concentrationModel = list()

            # assign values to model parameters and ModelVariable
            for ( name in names( model_parameters ) )
            {
              assign( name , getMu( model_parameters[[ name ]] ) )
            }

            for( iter in 1:numberOfResponse)
            {
              assign( namesInputVariables[ iter ] , listPredictedResponses[[ iter ]]  )
            }

            for( iter in 1:numberOfResponse)
            {
              concentrationModel[[ iter ]] = eval( equationsScaled[[ iter ]] )
            }

            names( concentrationModel ) = nameLists

            return( list( listHp, listPredictedResponses, listSamplingTimes,
                          numberSamplingTimesForEachResponse, samplingTinfTauForPlot, concentrationModel ) )


            return( list( listHp, listPredictedResponses, listSamplingTimes ) )

          })

#######################################################################################

#' dataForLsoda
#'
#' @name dataForLsoda
#' @param object ...
#' @param timeDoses ...
#' @param Tinf ...
#' @param tau ...
#' @param infusion ...
#' @param responseIndice ...
#' @return ....

## à mettre dans classe sampling times

setGeneric("dataForLsoda",
           function( object, timeDoses, Tinf, tau, infusion, responseIndice )
           {
             standardGeneric("dataForLsoda")
           }
)

setMethod(f="dataForLsoda",
          signature=  "SamplingTimes",
          definition=function( object, timeDoses, Tinf, tau, infusion, responseIndice )
          {


            originalSamplingTimes = getSampleTime( object )

            samplingTimes = originalSamplingTimes

            nDoses = length( timeDoses )

            # Repeated doses
            if (length(tau)==0)
            {
              timeDoses = 0
              tau=0
            }

            if (tau !=0 )
            {
              if ( nDoses == 1 )
                n = max( samplingTimes )%/% tau
              else
                n = nDoses

              timeDoses = c(0:n)*tau
            }

            # Compute Tinf
            Tinf = Tinf + timeDoses

            # augmented sampling times

            samplingTimes = sort(unique(c(samplingTimes,Tinf,timeDoses)))

            # ---------------------------------------------------------
            # Indices for the doses in sampling times
            # ---------------------------------------------------------

            indicesDosesInSamplingTimes = c()
            indicesDosesInSamplingTimes[1] = 1

            vec = c(timeDoses,max(sort(unique(c(samplingTimes,Tinf)))))



            if ( nDoses <= 1)
              indicesDosesInSamplingTimes = rep( 1, length( samplingTimes ) )
            else
              for (k in 1:length(vec))
              {
                indicesDosesInSamplingTimes[vec[k]<samplingTimes & samplingTimes <=vec[k+1]] = k
              }

            # ---------------------------------------------------------
            # sampling times for lsoda
            # ---------------------------------------------------------

            tinfAndTimeDose = sort(unique(c(Tinf,timeDoses,max(samplingTimes))))

            interval = 0.0*c(1:length(samplingTimes))
            indexMatch = match(c(tinfAndTimeDose),samplingTimes)
            interval[indexMatch] = samplingTimes[indexMatch]
            interval = c(0,interval[1:(length(interval)-1)])

            samplingTimesForLsoda = matrix(0.0,length(interval),2)

            for (i in 1:length(interval))
            {
              samplingTimesForLsoda[i,1:2] = c(0,samplingTimes[i]-max(interval[1:i]))
            }

            # ---------------------------------------------------------
            # During and After or ModelEquations
            # ---------------------------------------------------------

            duringAnfAfter = rep("After",length(samplingTimes))

            for (k in 1:length(timeDoses))
            {
              duringAnfAfter[timeDoses[k]<samplingTimes & samplingTimes <= Tinf[k]] = "During"
            }

            if (infusion==T)
            {
              equations = duringAnfAfter
            } else {
              equations = rep("ModelEquations",length(samplingTimes))}

            # ---------------------------------------------------------
            # Compute ctrough
            # ---------------------------------------------------------

            tinfAndTimeDose = sort(unique(c(Tinf,timeDoses)))
            computeCtrough = rep(FALSE, length(samplingTimes))
            index = match(tinfAndTimeDose,samplingTimes)
            computeCtrough[index] = TRUE
            computeCtrough[1] = ""

            # ---------------------------------------------------------
            # computeGradient
            # ---------------------------------------------------------

            computeGradient = !is.na( match( samplingTimes, originalSamplingTimes ) )

            # ---------------------------------------------------------
            # dataframe for data
            # ---------------------------------------------------------

            dataForEvaluation = data.frame( samplingTimes = samplingTimes,
                                            indicesDosesInSamplingTimes = indicesDosesInSamplingTimes,
                                            samplingTimesForLsoda = samplingTimesForLsoda[,2],
                                            equations = equations,
                                            computeCtrough = computeCtrough,
                                            computeGradient = computeGradient)

            return( list( dataForEvaluation = dataForEvaluation, tinfAndTimeDose = tinfAndTimeDose ) )

          })

##########################################################################################################
#' Evaluate the First Derivatives of a model.
#' @name EvaluateFirstDerivatives
#' @param object ...
#' @param equations An object of class \code{Response} containing the name of the reponse and the equation of the model error.
#' @param model_parameters An object of class \code{ModelParameters} containing the values and the distributions of the model parameters.
#' @param administrations An object of class \code{Administration} containing the parametrization for the administration of the model.
#' @param sampling_times An object of class \code{SamplingTimes} containing the parametrization for the sampling times of the model.
#' @param cond_init An object of class \code{Arm} containing the initial conditions.
#' @return A list giving  \code{hp} the approximation of the gradient and \code{predictedResponses} the predicted response for the models belonging to the Class \code{ModelODEquations}
#' otherwise a list giving \code{hp} and \code{fxiTheta} the evaluation of the parameter derivatives.

setGeneric("EvaluateFirstDerivatives",
           function(object, equations, model_parameters, administrations, sampling_times, cond_init ) #
           {
             standardGeneric("EvaluateFirstDerivatives")
           }
)

setMethod(f="EvaluateFirstDerivatives",
          signature = "Response",
          definition = function(object, equations, model_parameters, administrations, sampling_times, cond_init )
          {


            isInfusion = FALSE

            if ( is( equations,"InfusionEquations" ) )
              isInfusion = TRUE

            if ( is( equations,"ModelInfusionODEquations" ) )
            {
              resultsODEInfusion = computeODEInfusion( object, equations, model_parameters, administrations, sampling_times, cond_init )

              return( resultsODEInfusion )
            }
            else if ( is( equations, "ModelODEquations" ) )
            {
              resultsODE = computeODE( object, equations, model_parameters, administrations, sampling_times, cond_init )

              return ( resultsODE )
            }
            else
            {
              resultsAnalytic = computeAnalytic( object, equations, model_parameters, administrations, sampling_times, cond_init, isInfusion )
              return( resultsAnalytic )
            }
          }
)

##########################################################################################################
#' Evaluate the Variance of a Population FIM
#' @name PopulationFIMEvaluateVariance
#' @param object A \code{Response} object.
#' @param equations An object of class \code{Response} containing the name of the reponse and the equation of the model error.
#' @param model_parameters An object of class \code{ModelParameters} containing the values and the distributions of the model parameters.
#' @param administrations An object of class \code{Administration} containing the parametrization for the administration of the model.
#' @param sampling_times An object of class \code{SamplingTimes} containing the parametrization for the sampling times of the model.
#' @param df_total df_total
#' @param errorVariances errorVariances
#' @param sigmaDerivatives sigmaDerivatives
#' @return A list giving  \code{VDist} and \code{MF_var}

setGeneric("PopulationFIMEvaluateVariance",
           function(object, equations, model_parameters, administrations, sampling_times, df_total, errorVariances, sigmaDerivatives ) #
           {
             standardGeneric("PopulationFIMEvaluateVariance")
           }
)

setGeneric("IndividualFIMEvaluateVariance",
           function(object, equations, model_parameters, administrations, sampling_times, df_total, errorVariances, sigmaDerivatives ) #
           {
             standardGeneric("IndividualFIMEvaluateVariance")
           }
)
setMethod(f="PopulationFIMEvaluateVariance",
          signature=  "Response",
          definition=function(object, equations, model_parameters, administrations, sampling_times, df_total, errorVariances, sigmaDerivatives )
          {

            ### Number of parameter of the model
            nbParameters = 0
            ### Response name
            responseName = object@name
            ### Ask the statistical model for the coresponding response's equation
            equation = getEquation( equations, responseName )
            ### Derivate the equations
            derivate = list()
            ### Omega vector
            omega2 = c()


            for (parameter in model_parameters)
            {
              parameterName = getNameModelParameter( parameter )
              if ( isFixed( parameter ) )
                next
              ### Set the mean value
              omegaValue = getOmega( parameter )
              assign( paste0("w", parameterName ), omegaValue )
              omega2 = c( omega2, omegaValue^2 )
            }

            Omega<-diag( omega2 )


            df_total_dist = df_total
            i = 1
            for (parameter in model_parameters)
            {
              if ( isFixed( parameter ) )
                next
              df_total_dist[ , i ] = getDerivatesAdjustedByDistribution( parameter, df_total[ ,i ]  )

              i = i + 1
              nbParameters = nbParameters + 1
            }




            VDist = ( df_total_dist ) %*% Omega %*% t( df_total_dist ) + errorVariances
            VDist = as.matrix( VDist )
            ### B Block
            dV_dOmega<-list()
            i <- 1
            for ( parameter in model_parameters )
            {
              if ( isFixed( parameter ) )
                next
              parameterName = getNameModelParameter( parameter )
              dOmega = matrix(0,ncol=nbParameters,nrow=nbParameters)
              dOmega[ i, i ] <- 1

              dV_dOmega[[ parameterName ]] <- ( df_total_dist )  %*% dOmega %*% t( df_total_dist  )

              i<-i+1
            }
            dV_dLambda = c( dV_dOmega, sigmaDerivatives )
            V_mat <- c()

            for ( varParam1 in dV_dLambda )
            {

              for ( varParam2 in dV_dLambda )
              {

                V_mat <- c( V_mat, 1/2 * ( sum( diag( solve( VDist ) %*% varParam1 %*% solve( VDist ) %*% varParam2 ) ) ) )

              }

            }

            MF_var = matrix( V_mat, nrow = length( dV_dLambda ), ncol = length( dV_dLambda ) )


            return( list( V = VDist, MF_var = MF_var ) )
          }
)

##########################################################################################################
#' Individual FIM Evaluate Variance
#' @param object A \code{Response} object.
#' @param equations An object of class \code{Response} containing the name of the reponse and the equation of the model error.
#' @param model_parameters An object of class \code{ModelParameters} containing the values and the distributions of the model parameters.
#' @param administrations An object of class \code{Administration} containing the parametrization for the administration of the model.
#' @param sampling_times An object of class \code{SamplingTimes} containing the parametrization for the sampling times of the model.
#' @param df_total df_total
#' @param errorVariances errorVariances
#' @param sigmaDerivatives sigmaDerivatives
#' @return A list giving  \code{VDist} and \code{MF_var}

setMethod(f="IndividualFIMEvaluateVariance",
          signature=  "Response",
          definition=function(object, equations, model_parameters, administrations, sampling_times, df_total, errorVariances, sigmaDerivatives )
          {
            ### Number of parameter of the model
            nbParameters = length( model_parameters )
            ### Response name
            responseName = object@name
            ### Ask the statistical model for the coresponding response's equation
            equation = getEquation( equations, responseName )
            ### Derivate the equations
            derivate = list()

            for (parameter in model_parameters)
            {
              if ( isFixed( parameter ) )
                next
              parameterName = getNameModelParameter( parameter )
              ### Compute the Derivative for parameter 'parameterName'
              derivate[[ parameterName ]] = D(equation, parameterName )
            }

            VDist = errorVariances

            ### B Block

            dV_dLambda = c( sigmaDerivatives )
            V_mat <- c()

            invVDist =  ( solve( VDist ) )

            for ( varParam1 in dV_dLambda )
            {

              #mat1 = eigenMapMatMult( invVDist, varParam1 )
              # mat2 = eigenMapMatMult( mat1, invVDist )

              for ( varParam2 in dV_dLambda )
              {

                #mat3 = eigenMapMatMult( mat2, varParam2 )

                V_mat <- c( V_mat, 1/2 * ( sum( diag( solve( VDist ) %*% varParam1 %*% solve( VDist ) %*% varParam2 ) ) ) )
                #V_mat <- c( V_mat, 1/2 * ( sum( diag( mat3 ) ) ) )
              }
            }
            MF_var = matrix( V_mat, nrow = length( dV_dLambda ), ncol = length( dV_dLambda ) )

            return( list( V = VDist, MF_var = MF_var ) )
          }
)

##########################################################################################################
#' get the Sigma Names
#' @name getSigmaNames
#' @param object A \code{Response} object.
#' @return A character string \code{sigmaNames} giving the namesof the sigma.

setMethod("getSigmaNames",
          "Response",
          function(object)
          {
            sigmaNames <- getSigmaNames(object@model_error)
            sigmaNames <- paste0(sigmaNames,"_", object@name)
            return(sigmaNames)
          }
)

#####################################################################################################





