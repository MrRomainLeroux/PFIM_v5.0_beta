##################################################################################
##' Class "Covariance"
##'
##' @description ....
##'
##' @name Covariance-class
##' @aliases Covariance
##' @docType class
##' @exportClass Covariance
##'
##' @section Objects from the Class: Covariance objects are typically created by calls to \code{{covariance}} and contain the following slots:
##'
##' \describe{
##' \item{variables:}{ A vector for parameterA and parameterB.}
##' \item{covariance:}{A numeric for the covariance.}
##' }

Covariance <- setClass(
  Class = "Covariance",
  representation = representation(
    variables = "vector", # the 2 variables
    covariance = "numeric"
  ),
  prototype = prototype(
    variables = c()
  )
)

# Initialize method
setMethod(
  f = "initialize",
  signature = "Covariance",
  definition = function (.Object, parameterA, parameterB, covariance )
  {
    if ( !missing( parameterA ) && !missing( parameterB ) && !missing( covariance ) )
    {
      .Object@variables<-c( parameterA, parameterB )
      .Object@covariance = covariance
    }
    #validObject(.Object)
    return (.Object )
  }
)
