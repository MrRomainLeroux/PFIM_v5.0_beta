##################################################################################
##' Class "ProportionalC"
##'
##' @description ...
##'
##' @name ProportionalC-class
##' @aliases ProportionalC
##' @docType class
##' @section Objects from the Class: ProportionalC objects
##' are typically created by calls to \code{{...}} and contain the following slots
##' that are heritated from the class Combined1c.R:
##'
#'@section Slots for the \code{ProportionalC} objects:
#' \describe{
#' \item{\code{sigma_inter}:}{}
#' \item{\code{sigma_slope}:}{}
#' \item{\code{c_error}:}{}
#' }
##'
##' @include Combined1c.R
##' @exportClass ProportionalC
##'
ProportionalC<-setClass(
  Class="ProportionalC",
  contains = "Combined1c",
  validity=function(object)
  {
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f="initialize",
  signature="ProportionalC",
  definition= function (.Object, sigma_slope, c_error)
  {
    sigma_inter = 0
    # Object validation
    validObject(.Object)
    .Object = callNextMethod(.Object, sigma_inter, sigma_slope, c_error)
    return (.Object )
  }
)


