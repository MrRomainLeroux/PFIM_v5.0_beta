##################################################################################
##' Class "Covariate"
##'
##' @description
##' A class storing information concerning the covariate model
##'
##' @name Covariate-class
##' @aliases Covariate
##' @docType class
##' @section Objects from the Class: Covariate objects are typically created by calls to \code{\link{covariate}} and contain the following slots:
##'
##' \describe{
##' \item{distribution}{Distribution}
##' }
##' @section Methods:
##' \describe{
##'   \item{simulate(covariate):}{Simulate covariates}
##' }
##'
##' @exportClass Covariate

