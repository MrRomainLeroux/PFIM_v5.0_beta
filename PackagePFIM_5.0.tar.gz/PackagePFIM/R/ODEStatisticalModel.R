##################################################################################
#' Class "ODEStatisticalModel"
#'
#' @description
#' Class "ODEStatisticalModel" represents an StatisticalModel in ODE form.
#'
#' @name ODEStatisticalModel-class
#' @aliases ODEStatisticalModel
#' @docType class
#' @include StatisticalModel.R
#' @exportClass ODEStatisticalModel
#'
#' @section Objects from the Class ODEStatisticalModel:
#' Objects form the Class \code{ODEStatisticalModel} can be created by calls of the form \code{ODEStatisticalModel(...)} where
#' (...) are the parameters for the \code{ODEStatisticalModel} objects.
#'
#'@section Slots for ODEStatisticalModel objects:
#'  \describe{
#'    \item{\code{variables}:}{List giving the variable of the ODEStatisticalModel.}
#'  }


ODEStatisticalModel<-setClass(
  Class = "ODEStatisticalModel",
  contains = "StatisticalModel",
  representation = representation(
    variables="list"
  ),
  validity = function(object)
  {
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f = "initialize",
  signature = "ODEStatisticalModel",
  definition = function(.Object, responses )
  {
    .Object = callNextMethod(.Object, responses = responses )
    return(.Object)
  }
)

# -------------------------------------------------------------------------------------------------------------------
#' Evaluate an \code{ODEStatisticalModel} object.
#'
#' @rdname Evaluate
#' @param object An \code{ODEStatisticalModel} object.
#' @param administrations An \code{Administration} object.
#' @param sampling_times A \code{SamplingTimes} object.
#' @param cond_init A list for the initial conditions of the \code{ODEStatisticalModel} object.
#' @param fim  \code{FIM} object.
#' @return A \code{fim} object giving the Fisher Information Matrix of the \code{ODEStatisticalModel} object.

setMethod(f="Evaluate",
          signature=  "ODEStatisticalModel",
          definition=function(object, administrations, sampling_times, cond_init, fim )
          {



            MF_var = NA
            df_total = NA
            V_total = NA
            # errorVariances = NA
            errorVariances=list()
            sigmaDerivatives = list()
            listErrorModelParameter = list()

            nTotalSamplingTimes = 0
            position = 1

            for( samplingTime in sampling_times )
            {
              nTotalSamplingTimes <- nTotalSamplingTimes + getNumberTime( samplingTime )
            }


            #  ---------------------------------------------------------------------
            # Concentration and Sensitivity indices for plot
            #  ---------------------------------------------------------------------

            concentrationModel = list()
            sensitivityIndicesModel = list()
            samplingTimesWithTauAndTinfModel = list()
            samplingTinfTauForPlot = list()

            #  ---------------------------------------------------------------------
            # for class PFIM : plot concentration
            #  ---------------------------------------------------------------------

            if ( object@computeFIM == FALSE )
            {

              for ( response in object@responses )
              {
                nameResponse = getNameResponse( response )

                efd = EvaluateFirstDerivatives(response, object@modelEquations, object@model_parameters, administrations, sampling_times, cond_init )


                #  ---------------------------------------------------------------------------------------------
                # sensitivity indices, concentration and sampling times completed if infusion with tau and Tinf
                #  ---------------------------------------------------------------------------------------------

                numberSamplingTimesForEachResponse = efd[[4]]
                nTotalSamplingTimes = sum( unlist( numberSamplingTimesForEachResponse ) )
                #concentrationModel[[ nameResponse ]] = efd[[ 2 ]][[ nameResponse ]]

                sensitivityIndicesModel[[ nameResponse ]] = t( efd[[ 1 ]][[nameResponse]] )
                samplingTimesWithTauAndTinfModel[[ nameResponse ]] = efd[[3]][[nameResponse]]
                samplingTinfTauForPlot[[ nameResponse ]] = efd[[5]]

                concentrationModel[[ nameResponse ]] = efd[[6]][[nameResponse]]

              }

              return( list(fim = fim,
                           concentrationModel = concentrationModel,
                           sensitivityIndicesModel = sensitivityIndicesModel,
                           samplingTimesWithTauAndTinfModel = samplingTimesWithTauAndTinfModel,
                           samplingTinfTauForPlot = samplingTinfTauForPlot) )

            }else{


              # ---------------------------------------------------------------------
              # for the computation of the FIM
              # ---------------------------------------------------------------------


              for ( response in object@responses )
              {

                efd = EvaluateFirstDerivatives(response, object@modelEquations, object@model_parameters,
                                               administrations, sampling_times, cond_init )


                nameResponse = getNameResponse( response )

                #  ---------------------------------------------------------------------------------------------
                # sensitivity indices, concentration and sampling times completed if infusion with tau and Tinf
                #  ---------------------------------------------------------------------------------------------

                df = t( efd[[ 1 ]][[nameResponse]] )
                predictedResponses = efd[[ 2 ]][[nameResponse]]
                samplingTimesWithTauAndTinf = efd[[3]][[nameResponse]]
                numberSamplingTimesForEachResponse = efd[[4]]
                nTotalSamplingTimes = sum( unlist( numberSamplingTimesForEachResponse ) )
                concentrationModel[[ nameResponse ]] = efd[[6]][[nameResponse]]

                sensitivityIndicesModel[[ nameResponse ]] = df

                samplingTimesWithTauAndTinfModel[[ nameResponse ]] = samplingTimesWithTauAndTinf


                if ( is.matrix( df_total ))
                {
                  df_total = rbind( df_total, df )
                }
                else
                {
                  df_total = df
                }

                errorModelDerivatives = EvaluateErrorModelDerivatives( response, predictedResponses )
                errorVariances = append( errorVariances, bdiag( errorModelDerivatives$errorVariance ) )
                errorVariances = bdiag( errorVariances)

                for( errorModelParameter in errorModelDerivatives$sigmaDerivatives )
                {
                  emptysigmaDerivatives = matrix(0, ncol = nTotalSamplingTimes, nrow = nTotalSamplingTimes )
                  nTime = numberSamplingTimesForEachResponse[[ nameResponse ]]
                  range <- position:( position + nTime - 1 )
                  emptysigmaDerivatives[ range, range ] <- errorModelParameter

                  #  ----------------------------------------------------------------------------------------------------------------
                  # Add the MF_beta matrix for the parameters for each response, add the MF_var in different blocks for each response
                  #  ----------------------------------------------------------------------------------------------------------------

                  sigmaDerivatives = c( sigmaDerivatives, list( emptysigmaDerivatives ) )
                }
                position <- position + nTime
              }

              FixedEffectNamesAndNumber <- getFixedEffectParameterNamesAndNumber( object )
              RandomEffectNamesAndIndex <- getNotZeroRandomEffectParameterNames( object )
              sigmaNames <- c()


              for (response in object@responses)
              {
                if ( is( fim, "PopulationFim" ) )
                {
                  MF = PopulationFIMEvaluateVariance(response,
                                                     object@modelEquations,
                                                     object@model_parameters,
                                                     administrations,
                                                     sampling_times, df_total, errorVariances, sigmaDerivatives )

                  parameterNames <- c( FixedEffectNamesAndNumber$muNames, RandomEffectNamesAndIndex$omegaNames )

                }

                else
                  if ( is( fim, "IndividualFim" ) )
                  {
                    MF = IndividualFIMEvaluateVariance(response, object@modelEquations, object@model_parameters,
                                                       administrations, sampling_times, df_total, errorVariances, sigmaDerivatives )

                    parameterNames <- FixedEffectNamesAndNumber$muNames
                  }

                ### Add the MF_beta matrix for the parameters for each response, add the MF_var in different blocks for each response
                if ( is.matrix( MF_var ))
                {
                  MF_var = bdiag( MF_var, MF$MF_var )
                  V_total = bdiag( V_total, MF$V )
                }
                else
                {
                  ### Create the first matrix and the first block
                  MF_var = bdiag( MF$MF_var )
                  V_total = bdiag( MF$V )
                }
                sigmaNames <- c( sigmaNames, getSigmaNames(response) )

              }

              V_total = as.matrix( V_total )

              MF_beta =  t( df_total ) %*% solve( V_total ) %*% df_total

              MF_i_total = bdiag( MF_beta, MF_var )

              if(length(RandomEffectNamesAndIndex$zeroOmegaIndex) > 0)
                MF_i_total = MF_i_total[-c(FixedEffectNamesAndNumber$FixedEffectParameterNumber + RandomEffectNamesAndIndex$zeroOmegaIndex),
                                        -c(FixedEffectNamesAndNumber$FixedEffectParameterNumber + RandomEffectNamesAndIndex$zeroOmegaIndex)]

              colnames(MF_i_total) <- c( parameterNames, sigmaNames)
              rownames(MF_i_total) <- c( parameterNames, sigmaNames)

              fim <- `setMfisher<-`( fim, MF_i_total )

              return( list(fim = fim,
                           concentrationModel = concentrationModel,
                           sensitivityIndicesModel = sensitivityIndicesModel,
                           samplingTimesWithTauAndTinfModel = samplingTimesWithTauAndTinfModel) )
            }
          })

# -------------------------------------------------------------------------------------------------------------------
#' Define a variable in a ODE statistical model.
#' @name defineVariable
#' @param .Object A \code{ODEStatisticalModel} object.
#' @param variable A character string giving the variable to be defined.
#' @return The \code{ODEStatisticalModel} object with the new variable.

setGeneric("defineVariable",
           function(.Object, variable ) #
           {
             standardGeneric("defineVariable")
           }
)

setMethod(f="defineVariable",
          signature=  "ODEStatisticalModel",
          definition=function(.Object, variable)
          {
            #variableName = getName( variable )
            variableName = variable@name
            .Object@variables[[ variableName ]] = variable
            return(.Object)
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Define outputVariable variable in a ODE statistical model.
#' @name outputVariable
#' @param .Object A \code{ODEStatisticalModel} object.
#' @param variable A character string giving the variables to be defined.
#' @return The \code{ODEStatisticalModel} object with the new output variables.

setGeneric("outputVariable",
           function(.Object, variable ) #
           {
             standardGeneric("outputVariable")
           }
)

setMethod(f="outputVariable",
          signature=  "ODEStatisticalModel",
          definition=function(.Object, variable)
          {

            modelVariable <- ModelVariable( variable )
            variableName = modelVariable@name
            .Object@outputVariables[[ variableName ]] = modelVariable

            return(.Object)
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' getNamesOutputVariable
#' @name getNamesOutputVariable
#' @param object A \code{ODEStatisticalModel} object.
#' @return A vector with the names of the output variables.

setGeneric("getNamesOutputVariable",
           function(object)
           {
             standardGeneric("getNamesOutputVariable")
           }
)

setMethod(f="getNamesOutputVariable",
          signature=  "ODEStatisticalModel",
          definition=function(object)
          {
            return( names( object@outputVariables ) )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' getNamesInputVariable
#' @name getNamesInputVariable
#' @param object A \code{ODEStatisticalModel} object.
#' @return A vector with the names of the input variables.

setGeneric("getNamesInputVariable",
           function(object)
           {
             standardGeneric("getNamesInputVariable")
           }
)

setMethod(f="getNamesInputVariable",
          signature=  "ODEStatisticalModel",
          definition=function(object)
          {
            return(names(object@variables))
          }
)
