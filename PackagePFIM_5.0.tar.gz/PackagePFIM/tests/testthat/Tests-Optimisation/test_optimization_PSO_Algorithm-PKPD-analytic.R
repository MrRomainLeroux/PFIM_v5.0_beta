options(warn=-1)
library(nlme)
library(Deriv)
library(Matrix)
library(ggplot2)
library(deSolve)
library(Rcpp)
library(gtable)
library(grid)
library(pracma)
library(PackagePFIM)

########################################################################################

# Optimisation

# PSO ( Particle Swarm Optimization )

########################################################################################

# -------------------------------------------------
# 1.0 Create PFIM project
# -------------------------------------------------

MyProject<-PFIM(name = "Test PFIM")

# -------------------------------------------------
# 2.0 Create the statistical model
# -------------------------------------------------

MyStatisticalModel<-StatisticalModel()

# -------------------------------------------------------------
# 3.0 Create model
# -------------------------------------------------------------

MyModelEquations = ModelEquations( list( "Resp1" = expression( dose / V * ka/(ka - (Cl/V)) * (exp(-(Cl/V) * t) - exp(-ka * t)) ),
                                         "Resp2" = expression(  S0 * ( 1 - 0.73 * Resp1 / ( Resp1 + S0 ) ) ) ) )

MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations )

# ------------------------------------------------------------------
# 4. specification of the model parameters values and distributions
# ------------------------------------------------------------------

pV = ModelParameter( "V", mu = 8,
                     omega = sqrt( 0.020 ),
                     distribution = NormalDistribution() )

pCl = ModelParameter( "Cl", mu = 0.13,
                      omega = sqrt( 0.06 ),
                      distribution = NormalDistribution() )

pka = ModelParameter( "ka", mu = 1.6,
                      omega = sqrt( 0.7 ),
                      distribution = NormalDistribution() )

pS0 = ModelParameter( "S0", mu = 100,
                      omega = sqrt( 0.1 ),
                      distribution = NormalDistribution() )

# Assign the parameters to the statistical model
MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )
MyStatisticalModel = defineParameter( MyStatisticalModel, pS0 )

# -------------------------------------------------------------
# 5. Create and add the responses to the statistical model
# -------------------------------------------------------------

MyStatisticalModel = addResponse( MyStatisticalModel, Response( "Resp1", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )
MyStatisticalModel = addResponse( MyStatisticalModel, Response( "Resp2",  Constant( sigma_inter = 8 ) ) )

MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

# -------------------------------------------------------------
# 6. Create a design
# -------------------------------------------------------------

MyDesign<- Design( name = "MyDesign")

# --------------------------------------------------------------------
# 7. For each arm create and add the sampling times for each response
# --------------------------------------------------------------------

## Arm "Bras test"

brasTest <- Arm( name="Bras test", arm_size = 200 )
brasTest <- addAdministration( brasTest, Administration( outcome = "Resp1", time_dose = c(0), amount_dose = c(100) ) )

# Create a sampling constraint for response

brasTest <- addSampling( brasTest, SamplingTimes( outcome = "Resp1", sample_time = c(0.5, 8, 20, 115 ) ) )
samplingBoundsConstraintResp1 <- SamplingConstraint( response = "Resp1", continuousSamplingTimes = list( c( 0,40),c(60, 120 ) ) )
samplingMinimalDelayConstraintResp1 <- SamplingConstraint( response = "Resp1", min_delay = 5 )

brasTest <- addSampling( brasTest, SamplingTimes( outcome = "Resp2", sample_time = c(2, 12, 30, 118 ) ) )
samplingBoundsConstraintResp2 <- SamplingConstraint( response = "Resp2", continuousSamplingTimes = list( c( 0,40),c(60, 120 ) ) )
samplingMinimalDelayConstraintResp2 <- SamplingConstraint( response = "Resp2", min_delay = 5 )

# Create the Design constraint

Constr1 <- DesignConstraint( )
Constr1 <- addSamplingConstraint( Constr1, samplingBoundsConstraintResp1 )
Constr1 <- addSamplingConstraint( Constr1, samplingMinimalDelayConstraintResp1 )
Constr1 <- addSamplingConstraint( Constr1, samplingBoundsConstraintResp2 )
Constr1 <- addSamplingConstraint( Constr1, samplingMinimalDelayConstraintResp2 )
brasTest<- addSamplingConstraints(brasTest,Constr1)

## Arm "Bras ctrl"

brasctrl <- Arm( name="Bras ctrl", arm_size = 200 )
brasctrl <- addAdministration( brasctrl, Administration( outcome = "Resp1", time_dose = c(0), amount_dose = c(100) ) )
brasctrl <- addSampling( brasctrl, SamplingTimes( outcome = "Resp1", sample_time = c(0.5, 8, 20, 115 ) ) )

# Create a sampling constraint for response
# the sampling constraint are :
# min_delay the minimal time interval between two sampling times
# in continuousSamplingTimes, for this example, the sampling times are bounded between 0,40 and 60,120

samplingBoundsConstraintResp1 <- SamplingConstraint( response = "Resp1", continuousSamplingTimes = list( c( 0,40),c(60, 120 ) ) )
samplingMinimalDelayConstraintResp1 <- SamplingConstraint( response = "Resp1", min_delay = 5 )

brasctrl <- addSampling( brasctrl, SamplingTimes( outcome = "Resp2", sample_time = c(2, 12, 30, 118 ) ) )
samplingBoundsConstraintResp2 <- SamplingConstraint( response = "Resp2", continuousSamplingTimes = list( c( 0,40),c(60, 120 ) ) )
samplingMinimalDelayConstraintResp2 <- SamplingConstraint( response = "Resp2", min_delay = 5 )

# Create the Design constraint

Constr2 <- DesignConstraint( )
Constr2 <- addSamplingConstraint( Constr2, samplingBoundsConstraintResp1 )
Constr2 <- addSamplingConstraint( Constr2, samplingMinimalDelayConstraintResp1 )
Constr2 <- addSamplingConstraint( Constr2, samplingBoundsConstraintResp2 )
Constr2 <- addSamplingConstraint( Constr2, samplingMinimalDelayConstraintResp2 )
brasctrl<- addSamplingConstraints(brasctrl,Constr2)

# Add the arms to the design
MyDesign <- addArm( MyDesign, brasTest )
MyDesign <- addArm( MyDesign, brasctrl )

# Add the design to the project
MyProject <- addDesign( MyProject, MyDesign )

# --------------------------------------------------------------------
# Run the optimization
# --------------------------------------------------------------------

psoOptimizer <- PSOAlgorithm( maxIteration = 100,
                              populationSize = 100,
                              personalLearningCoefficient = 2.05,
                              globalLearningCoefficient = 2.05,
                              showProcess = TRUE )

optimizer1 <- OptimizeDesign( MyProject, psoOptimizer, PopulationFim() )

# show results
show( optimizer1 )

# convergence graph
plotCriteria( optimizer1 )

########################################################################################
# END CODE
########################################################################################


