options(warn=-1)
library(testthat)
library(Matrix)
library(gtable)
library(grid)
library(Deriv)
library(nlme)
library(deSolve)
library(ggplot2)
library(PackagePFIM)

########################################################################################

# Optimisation

# Nelder-Mead method ( downhill simplex method, amoeba method, or polytope method )

########################################################################################

# -------------------------------------------------
# 1.0 Create PFIM project
# -------------------------------------------------

MyProject<-PFIM(name = "Test PFIM")

# -------------------------------------------------
# 2.0 Create the statistical model
# -------------------------------------------------

MyStatisticalModel<-StatisticalModel()

# -------------------------------------------------------------
# 3.0 Create model
# -------------------------------------------------------------

MyModelEquations = ModelEquations( list( "Resp1" = expression( dose / V * ka/(ka - (k)) * (exp(-(k) * t) - exp(-ka * t)) )  ) )

# Assign the equations to the statistical model
MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations )

# ------------------------------------------------------------------
# 4. specification of the model parameters values and distributions
# ------------------------------------------------------------------

pV = ModelParameter( "V", mu = 15,
                     omega = sqrt( 0.1 ),
                     distribution = LogNormalDistribution() )

pk = ModelParameter( "k", mu = 0.25,
                     omega = sqrt( 0.25 ),
                     distribution = LogNormalDistribution() )

pka = ModelParameter( "ka", mu = 2.0,
                      omega = sqrt( 1.0 ),
                      distribution = LogNormalDistribution() )

# Assign the parameters to the statistical model
MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
MyStatisticalModel = defineParameter( MyStatisticalModel, pk )

# -------------------------------------------------------------
# 5. Create and add the responses to the statistical model
# -------------------------------------------------------------

MyStatisticalModel = addResponse( MyStatisticalModel, Response( "Resp1", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

# Finally assign the statistical model to the project
MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

# -------------------------------------------------------------
# 6. Create a design
# -------------------------------------------------------------

MyDesign<- Design()

# --------------------------------------------------------------------
# 7. For each arm create and add the sampling times for each response
# --------------------------------------------------------------------

brasTest <- Arm( name="Bras test", arm_size = 200 )

brasTest <- addSampling( brasTest, SamplingTimes( outcome = "Resp1", sample_time = c(0.5, 3, 8, 12 ) ) )
brasTest <- addAdministration( brasTest, Administration( outcome = "Resp1", time_dose = c(0), amount_dose = c(100) ) )

# --------------------------------------------------------------------
# Create a sampling constraint for response
# --------------------------------------------------------------------

samplingBoundsConstraint <- SamplingConstraint( response = "Resp1", continuousSamplingTimes = list( c( 0,4), c(5,12 ) ) )
samplingMinimalDelayConstraint <- SamplingConstraint( response = "Resp1", min_delay = 1.5 )

# --------------------------------------------------------------------
# Create the Design constraint
# --------------------------------------------------------------------

Constr1 <- DesignConstraint( )
Constr1 <- addSamplingConstraint( Constr1, samplingBoundsConstraint )
Constr1 <- addSamplingConstraint( Constr1, samplingMinimalDelayConstraint )

# --------------------------------------------------------------------
# Add the arm constraint to the design
# --------------------------------------------------------------------

MyProject <- setConstraint(MyProject,Constr1)

# --------------------------------------------------------------------
# Add the arm to the design
# Add the design to the project
# --------------------------------------------------------------------

MyDesign <- addArm( MyDesign, brasTest )
MyProject <- addDesign( MyProject, MyDesign )

# --------------------------------------------------------------------
# Run the optimization
# --------------------------------------------------------------------

simplexOptimizer <- SimplexAlgorithm( pct_initial_simplex_building = 20,
                                      max_iteration = 5000,
                                      tolerance = 1e-6 )

optimization <- OptimizeDesign( MyProject, simplexOptimizer, PopulationFim() )

show( optimization )

########################################################################################
# END CODE
########################################################################################

