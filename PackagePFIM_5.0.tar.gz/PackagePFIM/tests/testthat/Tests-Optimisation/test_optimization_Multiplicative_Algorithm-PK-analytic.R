options(warn=-1)
library(nlme)
library(Deriv)
library(Matrix)
library(ggplot2)
library(deSolve)
library(Rcpp)
library(gtable)
library(grid)
library(pracma)
library(PackagePFIM)

########################################################################################

# Optimisation

# Multiplicative algorithm

########################################################################################

# -------------------------------------------------
# 1.0 Create PFIM project
# -------------------------------------------------

MyProject<-PFIM(name = "Test OPT 1 Response")

# -------------------------------------------------
# 2.0 Create the statistical model
# -------------------------------------------------

MyStatisticalModel<-StatisticalModel()

# -------------------------------------------------------------
# 3.0 Create model
# -------------------------------------------------------------

MyModelEquations = ModelEquations( list( "RespPK" = expression( dose / V * ka/(ka - (Cl/V)) * (exp(-(Cl/V) * t) - exp(-ka * t)) )))

MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations )

# ------------------------------------------------------------------
# 4. specification of the model parameters values and distributions
# ------------------------------------------------------------------

pV = ModelParameter( "V", mu = 8,
                     omega = sqrt( 0.020 ),
                     distribution = LogNormalDistribution() )

pCl = ModelParameter( "Cl", mu = 0.13,
                      omega = sqrt( 0.06 ),
                      distribution = LogNormalDistribution() )

pka = ModelParameter( "ka", mu = 1.6,
                      omega = sqrt( 0.7 ),
                      distribution = LogNormalDistribution() )

# Assign the parameters to the statistical model
MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

# -------------------------------------------------------------
# 5. Create and add the responses to the statistical model
# -------------------------------------------------------------

MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

# Assign the statistical model to the project
MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

# -------------------------------------------------------------
# 6. Create a design
# -------------------------------------------------------------

MyDesign<- Design()

# --------------------------------------------------------------------
# 7. For each arm create and add the sampling times for each response
# --------------------------------------------------------------------

brasTest <- Arm( name="Bras test", arm_size = 32 )
brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120 ) ) )
brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c( 0 ), amount_dose = c( 100 ) ) )

# Add the arm to the design
MyDesign <- addArm( MyDesign, brasTest )

# Add the design to the project
MyProject <- addDesign( MyProject, MyDesign )

# --------------------------------------------------------------------
# 8. Create a sampling constraint for response
# --------------------------------------------------------------------

samplingResp <- SamplingConstraint( response = "RespPK" )

# Define the vector of allowed sampling times
samplingResp <- allowedDiscretSamplingTimes( samplingResp, list(c(0.5, 1, 2, 6, 96 ,9, 12, 24, 36, 48, 72)) )

# Population case
samplingResp <- numberOfSamplingTimesIsOptimisable( samplingResp, F, c(5) )

# Fix certain time values
samplingResp <- FixTimeValues( samplingResp, c( 0.5, 96, 72 ) )

# Create an administration for response
administrationResp <- AdministrationConstraint( response = "RespPK" )

# Define the vector of allowed amount of doses
administrationResp <- AllowedDoses( administrationResp, c( 50,100,200 ) )

# Choose if dose values are fixed or optimisable
administrationResp <- doseIsOptimisable( administrationResp, F )

# Create the Design constraint
Constr1 <- DesignConstraint(  )
Constr1 <- addSamplingConstraint( Constr1, samplingResp )
Constr1 <- addAdministrationConstraint( Constr1, administrationResp )

# Define the total number of individuals to be considered
Constr1 <- setTotalNumberOfIndividuals( Constr1, 30 )

# Add the design to the project
MyProject <- setConstraint( MyProject, Constr1 )

optimizer <- MultiplicativeAlgorithm( lambda = 0.99, iter = 1000, delta = 1e-04, showProcess = T )

optimization <- OptimizeDesign( MyProject , optimizer, PopulationFim() )

# Show and plot the results
show( optimization )

# threshold for the optimal weights
threshold = 0.001

# plot for the optimal weights with treshold
plotWeightOptimisation( MyProject,threshold )

########################################################################################
# END CODE
########################################################################################

