options(warn=-1)
library(nlme)
library(Deriv)
library(Matrix)
library(ggplot2)
library(deSolve)
library(Rcpp)
library(gtable)
library(grid)
library(testthat)
library(pracma)
library(PackagePFIM)

###########################################################################################

# Models PK ODE Infusion

###########################################################################################

#### Test 01

### Create PFIM project
MyProject<-PFIM(name = "Test PFIM")

### Create the ODE model
MyStatisticalModel <- ODEStatisticalModel()

### Create a list of model equations
MyModelEquations <- ModelInfusionODEquations( list("DuringInfusion_RespPK" = expression( C1 ) ) ,

                                              list( "AfterInfusion_RespPK"  = expression( C1 ) ),

                                              list("Deriv_DuringInfusion_C1" = expression( dose_RespPK / ( V * Tinf_RespPK ) - k * C1 ) ),

                                              list("Deriv_AfterInfusion_C1" = expression( -k * C1 ) ) )

### Assign the equations to the model
MyStatisticalModel <- defineModelEquations( MyStatisticalModel, MyModelEquations )

### Define the variables of the ode model
vC1 <- ModelVariable( "C1" )
MyStatisticalModel <- defineVariable( MyStatisticalModel, vC1 )

### Set mu and omega for each parameter
pV = ModelParameter( "V", mu = 3.5,
                     omega = sqrt( 0.09 ),
                     distribution = LogNormalDistribution() )

pk = ModelParameter( "k", mu = 0.6,
                     omega = sqrt( 0.09 ),
                     distribution = LogNormalDistribution() )

### Assign the parameters to the statistical model
MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
MyStatisticalModel = defineParameter( MyStatisticalModel, pk )

### Create and add the responses to the statistical model
MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

### Finaly assign the statistical model to the project
MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

### Create a design
MyDesign<- Design()

### For each arm create and add the sampling times for each response

brasTest <- Arm( name="Bras test", arm_size = 40 )
brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 4, 8) ) )

# The parameters for infusion are : Tinf, time_dose and tau
# Three examples are listed below
# 1.0 # Tinf and time_dose with
# 2.0 # Tinf and tau
# 3.0 # Tinf and time_dose as a vectors

brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2), time_dose = c(0) , amount_dose = c(30) ) )
# brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2), tau = 3 , amount_dose = c(30) ) )
# brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2,3), time_dose = c(0,5) , amount_dose = c(30,50) ) )

### Initial conditions
brasTest <- setInitialConditions( brasTest, list( "C1" = 0 ) )

### Add arm to the design
MyDesign <- addArm( MyDesign, brasTest )

### Add the design to the project
MyProject <- addDesign( MyProject, MyDesign )

### Evaluate the Fisher Information Matrix for the PopulationFIM
MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
populationFIM = getFim(MyEvaluationPop,1)
matrixFisherPopulationFIM = getMfisher(populationFIM)
detPopulationFim = det(matrixFisherPopulationFIM)
print( detPopulationFim )

# Values to be found for detPopulationFim

# 1.0 #
# For Tinf=c(2), time_dose = c(0) , amount_dose = c(30)
# valueDetPopulationFim = 1.85905e+18

# 2.0 #
# For Tinf=c(2), tau = 3 , amount_dose = c(30)
# valueDetPopulationFim = 3.120734e+16

# 3.0 #
# For  Tinf=c(2,3), time_dose = c(0,5) , amount_dose = c(30,50)
# valueDetPopulationFim = 1.341784e+17

### outputs
# concentration and sensitivity indices
plot_response <- plotResponse( MyEvaluationPop )
plot_response

plot_sensitivity_indices <- plotSensitivity( MyEvaluationPop )
plot_sensitivity_indices

# SE and RSE
RSE <- plotRSE( MyEvaluationPop )
SE <- plotSE( MyEvaluationPop )

###  summary for the results of project PFIM
# The pdf file is saved in the folder inst/markdown/templates/pfim_report/skeleton

modelDescription = "Model PK ODE Infusion"
summaryProjectPFIM( MyEvaluationPop, modelDescription )

#################################################################################################################

#### Test 02

### Create PFIM project
MyProject<-PFIM(name = "Test_PFIM")
MyStatisticalModel <- ODEStatisticalModel()

### Create a list of model equations
MyModelEquations <- ModelInfusionODEquations( list("DuringInfusion_RespPK" = expression( C1 ) ) ,

                                              list( "AfterInfusion_RespPK"  = expression( C1 ) ),

                                              list("Deriv_DuringInfusion_C1" = expression( dose_RespPK / ( V * Tinf_RespPK ) - (Cl/V) * C1 ) ),

                                              list("Deriv_AfterInfusion_C1" = expression( -(Cl/V)* C1 ) ) )

### Assign the equations to the model
MyStatisticalModel <- defineModelEquations( MyStatisticalModel, MyModelEquations )

### Define the variables of the ode model
vC1 <- ModelVariable( "C1" )
MyStatisticalModel <- defineVariable( MyStatisticalModel, vC1 )

#### Set mu and omega for each parameter
pV = ModelParameter( "V", mu = 3.5,
                     omega = sqrt( 0.09 ),
                     distribution = LogNormalDistribution() )

pCl = ModelParameter( "Cl", mu = 2,
                      omega = sqrt( 0.09 ),
                      distribution = LogNormalDistribution() )

### Assign the parameters to the statistical model
MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

### Create and add the responses to the statistical model
MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

### Finaly assign the statistical model to the project
MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

### Create a design
MyDesign<- Design("MyDesign")

### For each arm create and add the sampling times for each response

brasTest <- Arm( name="Bras test", arm_size = 40 )
brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0, 1,   5, 7, 8, 10, 12) ) )
brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2), time_dose = c(0) , amount_dose = c(30) ) )

brasTest <- setInitialConditions( brasTest, list( "C1" = 0 ) )
MyDesign <- addArm( MyDesign, brasTest )

### Add the design to the project
MyProject <- addDesign( MyProject, MyDesign )

### Evaluate the Fisher Information Matrix for the PopulationFIM
MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
populationFIM = getFim(MyEvaluationPop,1)
matrixFisherPopulationFIM = getMfisher(populationFIM)
detPopulationFim = det(matrixFisherPopulationFIM)
print(detPopulationFim)

# value to be found for detPopulationFim
# valueDetPopulationFim = 2.802805e+17

###  summary for the results of project PFIM
# The pdf file is saved in the folder inst/markdown/templates/pfim_report/skeleton

modelDescription = "Model PK ODE Infusion"
summaryProjectPFIM( MyEvaluationPop, modelDescription )

###########################################################################################
# END CODE
###########################################################################################





