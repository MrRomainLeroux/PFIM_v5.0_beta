options(warn=-1)
library(nlme)
library(Deriv)
library(Matrix)
library(ggplot2)
library(deSolve)
library(Rcpp)
library(gtable)
library(grid)
library(testthat)
library(pracma)
library(PackagePFIM)

#########################################################################

# Evaluation of PK models
# The PK models are from the library of model PFIMLibraryOfModels

#########################################################################

context(" Model PK 1cpt : Linear1BolusSingleDose_k")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  ### Create PFIM project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1BolusSingleDose_k")

  ### Get equations of the PKPD model
  EquationsPKModel = getEquations(PKModel)

  MyModelEquations = ModelEquations(EquationsPKModel)

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 15,
                       omega = sqrt( 0.1 ),
                       distribution = LogNormalDistribution())

  pk = ModelParameter( "k", mu = 0.25,
                       omega = sqrt( 0.25 ),
                       distribution = LogNormalDistribution())

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk )
  MyStatisticalModel
  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 200 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.33, 1.5, 5, 12) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  plot_response <- plotResponse(MyEvaluationPop)

  populationFIM = getFim(MyEvaluationPop,1)

  matrixFisherPopulationFIM = getMfisher(populationFIM)

  detPopulationFim = det(matrixFisherPopulationFIM)

  valueDetPopulationFim = 1.456485e+18

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})


############################################################################################################################


context(" Model PK 1cpt : Linear1BolusSingleDose_ClV")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1BolusSingleDose_ClV")

  ### Get equations of the PKPD model
  EquationsPKModel = getEquations(PKModel)

  MyModelEquations = ModelEquations(EquationsPKModel)

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 15,
                       omega = sqrt( 0.10 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 3.75,
                        omega = sqrt( 0.25),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 200 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.33, 1.5, 5, 12) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  populationFIM = getFim(MyEvaluationPop,1)

  matrixFisherPopulationFIM = getMfisher(populationFIM)

  detPopulationFim = det(matrixFisherPopulationFIM)

  valueDetPopulationFim = 7.292816e+15

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})


############################################################################################################################


context(" Model PK 1cpt : Linear1InfusionSingleDose_Vk")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1InfusionSingleDose_Vk")

  ### Get equations of the PKPD model
  EquationsPKModel = getEquations(PKModel)
  MyInfusion = InfusionEquations(EquationsPKModel)
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyInfusion)

  #### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  pk = ModelParameter( "k", mu = 0.6,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )


  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 40 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 4, 8) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2), time_dose = c(0) , amount_dose = c(30) ) )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  populationFIM = getFim(MyEvaluationPop,1)
  matrixFisherPopulationFIM = getMfisher(populationFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 1.976729e+18
  tol = 1e-6
  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})


############################################################################################################################


context(" Model PK 1cpt : Linear1InfusionSingleDose_VCl")

test_that("", {
  ### Create PFIM project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1InfusionSingleDose_VCl")

  ### Get equations of the PKPD model
  EquationsPKModel = getEquations(PKModel)
  MyInfusion = InfusionEquations(EquationsPKModel)

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyInfusion)

  #### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 2.0,
                        omega = sqrt( 0.09 ),
                        distribution = LogNormalDistribution() )


  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 40 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 4, 8) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2), time_dose = c(0) , amount_dose = c(30) ) )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  populationFIM = getFim(MyEvaluationPop,1)
  matrixFisherPopulationFIM = getMfisher(populationFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 1.558579e+17
  tol = 1e-6
  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})


############################################################################################################################


context(" Model PK 1cpt : Linear1FirstOrderSingleDose_kVCl")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kVCl")

  ### Get equations of the PKPD model
  EquationsPKModel = getEquations(PKModel)

  MyModelEquations = ModelEquations(EquationsPKModel)

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations)

  #### Set mu and omega for each parameter
  pka = ModelParameter( "ka", mu = 2,
                        omega = sqrt( 1 ),
                        distribution = LogNormalDistribution() )

  pk = ModelParameter( "k", mu = 0.25,
                       omega = sqrt( 0.25 ),
                       distribution = LogNormalDistribution() )

  pV = ModelParameter( "V", mu = 15,
                       omega = sqrt( 0.1 ),
                       distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 200 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.33, 1.5, 5, 12) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0) , amount_dose = c(100) ) )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  populationFIM = getFim(MyEvaluationPop,1)
  matrixFisherPopulationFIM = getMfisher(populationFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 2.930397e+20
  tol = 1e-6
  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})


############################################################################################################################


context(" Model PK 1cpt : Linear1FirstOrderSingleDose_kaVCl")

test_that("", {

  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model

  MyStatisticalModel<-StatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl" )
  equation_PKmodel = getEquations(PKmodel)

  ### Defineequations of the model
  MyModelEquations = ModelEquations(equation_PKmodel)

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 8,
                       omega = sqrt( 0.020 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.13,
                        omega = sqrt( 0.06 ),
                        distribution = LogNormalDistribution() )

  pka = ModelParameter( "ka", mu = 1.6,
                        omega = sqrt( 0.7 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )


  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 32 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120 ) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  individualFIM = getFim(MyEvaluationInd,1)
  populationFIM = getFim(MyEvaluationPop,1)

  matrixFisherIndividualFIM = getMfisher(individualFIM)
  matrixFisherPopulationFIM = getMfisher(populationFIM)

  detIndividualFim = det(matrixFisherIndividualFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)

  valueDetIndividualFim = 1532105538
  valueDetPopulationFim = 7.503881e+22

  tol = 1e-6

  expect_equal(detIndividualFim,valueDetIndividualFim, tol)
  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

############################################################################################################################

context(" Model PK 1cpt : Linear1FirstOrderSingleDose_kaVCl (BayesianFIM instead of PopulationFIM)")

test_that("", {

  ### Create a project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model

  MyStatisticalModel<-StatisticalModel()

  ### Defineequations of the model
  # Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl" )
  equation_PKmodel = getEquations(PKmodel)
  MyModelEquations = ModelEquations(equation_PKmodel)
  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 8,
                       omega = sqrt( 0.020 ),
                       distribution = NormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.13,
                        omega = sqrt( 0.06 ),
                        distribution = NormalDistribution() )

  pka = ModelParameter( "ka", mu = 1.6,
                        omega = sqrt( 0.7 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )


  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 1 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120 ) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the IndividualFIM
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationBayes <- EvaluateBayesianFIM( MyProject )

  individualFIM = getFim(MyEvaluationInd,1)
  bayesianFIM = getFim(MyEvaluationBayes,1)

  matrixFisherIndividualFIM = getMfisher(individualFIM)
  matrixFisherBayesianFIM = getMfisher(bayesianFIM)

  detIndividualFim = det(matrixFisherIndividualFIM)
  detBayesianFim = det(matrixFisherBayesianFIM[1:3,1:3])

  valueDetIndividualFim = 1532105538
  valueDetBayesianFim = 4428901

  tol = 1e-6

  expect_equal(detIndividualFim,valueDetIndividualFim, tol)
  expect_equal(valueDetBayesianFim,detBayesianFim, tol)

})


###################################################################################################################################


context("Model PK 1cpt : Linear1InfusionSingleDose_kVCl ")

test_that("", {

  ### Create a project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Assign the equations to the statistical model
  Linear1InfusionSingleDose_kVCl <- getModel( PFIMLibraryOfModels, "Linear1InfusionSingleDose_kVCl" )

  EquationsPKModel = getEquations(Linear1InfusionSingleDose_kVCl)
  MyInfusion = InfusionEquations(EquationsPKModel)
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyInfusion)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 2,
                        omega = sqrt( 0.09 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model

  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )

  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model

  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project

  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )


  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 40 )

  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0, 1,2,5,7,8, 10,12,14, 15, 16, 20, 21, 30) ) )

  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2), tau=c(12) , amount_dose = c(30,50,30,50) ) )     #brasTest <- addAdministration( brasTest, Administration( outcome = "Resp1", tinf=c(2,2,3,3), amount_dose = [100][c(30,30,50,50)] )

  ### Add the arm to the design

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project

  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM

  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  populationFIM = getFim(MyEvaluationPop,1)
  matrixFisherPopulationFIM = getMfisher(populationFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 6.873542e+18

  tol = 1e-6
  expect_equal(valueDetPopulationFim,detPopulationFim, tol)

})


###################################################################################################################################


context("Model PK 1cpt : Linear1InfusionSingleDose_kVCl")

test_that("", {

  ### Create a project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Assign the equations to the statistical model
  MyPKPDModel <- getModel( PFIMLibraryOfModels, "Linear1InfusionSingleDose_kVCl" )

  EquationsPKModel = getEquations(Linear1InfusionSingleDose_kVCl)
  MyInfusion = InfusionEquations(EquationsPKModel)
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyInfusion)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 2,
                        omega = sqrt( 0.09 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model

  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )

  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model

  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project

  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )


  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 40 )

  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0, 1,2,5,7,8, 10,12,14, 15, 16, 20, 21, 27, 30) ) )

  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2,4,4,2), time_dose=c(0,12,28,40) , amount_dose = c(30,50,30,50) ) )     #brasTest <- addAdministration( brasTest, Administration( outcome = "Resp1", tinf=c(2,2,3,3), amount_dose = [100][c(30,30,50,50)] )

  ### Add the arm to the design

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project

  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM

  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )


  populationFIM = getFim(MyEvaluationPop,1)
  matrixFisherPopulationFIM = getMfisher(populationFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim =  2.408105e+19
  tol = 1e-6
  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})


###################################################################################################################################

context("Model PK 1cpt : Linear1FirstOrderSingleDose_kaVCl")

test_that("", {

  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl" )
  equation_PKmodel = getEquations(PKmodel)
  MyModelEquations = ModelEquations(equation_PKmodel)
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 8,
                       omega = sqrt( 0.020 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.13,
                        omega = sqrt( 0.06 ),
                        distribution = LogNormalDistribution() )

  pka = ModelParameter( "ka", mu = 1.6,
                        omega = sqrt( 0.7 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )


  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 32 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120 ) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  #showFims(MyEvaluationPop)
  #showDesigns(MyEvaluationPop)
  #show(MyEvaluationPop)

  ### Evaluate the Fisher Information Matrix for the IndividualFIM
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )
  #showFims(MyEvaluationInd)
  #showDesigns(MyEvaluationInd)
  #show(MyEvaluationInd)
  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  individualFIM = getFim(MyEvaluationInd,1)
  populationFIM = getFim(MyEvaluationPop,1)

  matrixFisherIndividualFIM = getMfisher(individualFIM)
  matrixFisherPopulationFIM = getMfisher(populationFIM)

  detIndividualFim = det(matrixFisherIndividualFIM)
  #detPopulationFim = det(matrixFisherPopulationFIM)

  valueDetIndividualFim = 1532105538
  #valueDetPopulationFim = 2.408105e+19

  tol = 1e-6

  expect_equal(detIndividualFim,valueDetIndividualFim, tol)
  #expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})


###################################################################################################################################


context("Model PK 1cpt : Linear1FirstOrderSingleDose_kaVCl")

test_that("", {

  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model

  MyStatisticalModel<-StatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl" )
  equation_PKmodel = getEquations(PKmodel)
  MyModelEquations = ModelEquations(equation_PKmodel)
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 8,
                       omega = sqrt( 0.020 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.13,
                        omega = sqrt( 0.06 ),
                        distribution = LogNormalDistribution() )

  pka = ModelParameter( "ka", mu = 1.6,
                        omega = sqrt( 0.7 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )

  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )

  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model

  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

  ### Finaly assign the statistical model to the project

  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )


  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 32 )

  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.5, 1, 2, 6, 12, 48, 72, 120, 165, 220 ) ) )

  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0, 80, 160), amount_dose = c(100,100,100) ) )

  ### Add the arm to the design

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project

  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the IndividualFIM
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  individualFIM = getFim(MyEvaluationInd,1)
  populationFIM = getFim(MyEvaluationPop,1)

  matrixFisherIndividualFIM = getMfisher(individualFIM)
  matrixFisherPopulationFIM = getMfisher(populationFIM)

  detIndividualFim = det(matrixFisherIndividualFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)

  valueDetIndividualFim = 618022401
  valueDetPopulationFim = 2.304835e+22

  tol = 1e-6
  expect_equal(detIndividualFim,valueDetIndividualFim, tol)
  expect_equal(detPopulationFim,valueDetPopulationFim, tol)


})


###################################################################################################################################


context(" Model PK 2cpts : Linear2BolusSingleDose_ClQV1V2")

test_that("", {

  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model

  MyStatisticalModel<-StatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear2BolusSingleDose_ClQV1V2" )
  equation_PKmodel = getEquations(PKmodel)

  MyModelEquations = ModelEquations(equation_PKmodel)

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations )

  ### Set mu and omega for each parameter
  pCl = ModelParameter( "Cl", mu = 0.4,
                        omega = sqrt( 0.2 ),
                        distribution = LogNormalDistribution() )

  pV1 = ModelParameter( "V1", mu = 10,
                        omega = sqrt( 0.1 ),
                        distribution = LogNormalDistribution() )

  pQ = ModelParameter( "Q", mu = 2,
                       omega = sqrt( 0.05 ),
                       distribution = LogNormalDistribution() )

  pV2 = ModelParameter( "V2", mu = 50,
                        omega = sqrt( 0.4 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV1 )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pQ )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV2 )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 32 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120)  ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  populationFIM = getFim(MyEvaluationPop,1)
  matrixFisherPopulationFIM = getMfisher(populationFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 3.587146e+18

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###################################################################################################################################

context(" Model PK 2cpts : Linear2BolusSingleDose_ClVkk12k21")

test_that("", {


  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model

  MyStatisticalModel<-StatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear2BolusSingleDose_ClVkk12k21" )
  equation_PKmodel = getEquations(PKmodel)

  MyModelEquations = ModelEquations(equation_PKmodel)

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations )

  ### Set mu and omega for each parameter
  pk = ModelParameter( "k", mu = 0.25,
                       omega = sqrt( 0.25 ),
                       distribution = LogNormalDistribution() )

  pV = ModelParameter( "V", mu = 15.00,
                       omega = sqrt( 0.10 ),
                       distribution = LogNormalDistribution() )

  pk12 = ModelParameter( "k12", mu = 1.00,
                         omega = sqrt( 0.4 ),
                         distribution = LogNormalDistribution() )

  pk21 = ModelParameter( "k21", mu = 0.80,
                         omega = sqrt( 0.3 ),
                         distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk12 )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk21 )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 200 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.33, 1.5, 3, 5, 8, 12)  ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  populationFIM = getFim(MyEvaluationPop,1)
  matrixFisherPopulationFIM = getMfisher(populationFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 2.137813e+24

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)


})

###################################################################################################################################

  context(" Model PK 1cpt : MichaelisMentenFirstOrderSingleDose_VmKmC")

  test_that("", {

    MyProject<-PFIM(name = "Test PFIM")

    ### Create the statistical model

    MyStatisticalModel<-ODEStatisticalModel()

    ###  Get Equations models
    PKmodel <- getModel( PFIMLibraryOfModels, "MichaelisMentenFirstOrderSingleDose_VmKmC")

    MyModelEquations = getEquations(PKmodel)

    MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations )

    ### Define the variables of the ode model
    vC1 <- ModelVariable( "C1" )
    MyModel = defineVariable( MyStatisticalModel, vC1 )

    ### Set fixed effects (mu), standard deviation of random effects (omega) and distribution of each parameter
    pka <- ModelParameter( "ka", mu = 1.00,
                           omega = sqrt( 0.20 ),
                           distribution = LogNormalDistribution() )

    pV <- ModelParameter( "V", mu = 15.00,
                          omega = sqrt( 0.25 ),
                          distribution = LogNormalDistribution() )

    pVm <- ModelParameter( "Vm", mu = 0.08,
                           omega = sqrt( 0.10 ),
                           distribution = LogNormalDistribution() )

    pKm <- ModelParameter( "Km", mu = 0.40,
                           omega = sqrt( 0.30 ),
                           distribution = LogNormalDistribution() )

    ### Assign the parameters to the statistical model
    MyStatisticalModel <- defineParameter( MyStatisticalModel, pka )
    MyStatisticalModel <- defineParameter( MyStatisticalModel, pV )
    MyStatisticalModel <- defineParameter( MyStatisticalModel, pVm )
    MyStatisticalModel <- defineParameter( MyStatisticalModel, pKm )

    ### Error model (standard deviations)
    MyModel <- addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

    ### Assign the model to the project
    MyProject <- defineStatisticalModel( MyProject, MyModel )

    ### Create a design
    MyDesign<- Design()

    ### For each arm create and add the sampling times for each response
    brasTest <- Arm( name="Bras test", arm_size = 200, cond_init=list( "C1"=0 ))
    brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

    brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK",
                                                      sample_time = c(0, 0.33, 1.5, 3, 5, 8, 11, 12),
                                                      initialTime = 0 ) )

    brasTest <- setInitialConditions( brasTest, list( "C1"=0.0) )

    ### Add the arm to the design
    MyDesign <- addArm( MyDesign, brasTest )

    ### Add the design to the project
    MyProject <- addDesign( MyProject, MyDesign )

    ### Evaluate the PopulationFIM
    MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

    populationFIM = getFim(MyEvaluationPop,1)
    matrixFisherPopulationFIM = getMfisher(populationFIM)
    detPopulationFim = det(matrixFisherPopulationFIM)
    valueDetPopulationFim = 587443408536

    tol = 1e-6

    expect_equal(detPopulationFim,valueDetPopulationFim, tol)

  })

###################################################################################################################################

  context(" Model PK 1cpt : MichaelisMentenBolusSingleDose_VmKmC")

  test_that("", {

    MyProject<-PFIM(name = "Test PFIM")

    ### Create the statistical model

    MyStatisticalModel<-ODEStatisticalModel()

    ###  Get Equations models
    PKmodel <- getModel( PFIMLibraryOfModels, "MichaelisMentenBolusSingleDose_VmKmC")
    MyModelEquations = getEquations(PKmodel)
    MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations )

    ### Define the variables of the ode model
    vC1 <- ModelVariable( "C1" )
    MyModel = defineVariable( MyStatisticalModel, vC1 )

    ### Set fixed effects (mu), standard deviation of random effects (omega) and distribution of each parameter
    pV <- ModelParameter( "V", mu = 15.00,
                          omega = sqrt( 0.25 ),
                          distribution = LogNormalDistribution() )

    pVm <- ModelParameter( "Vm", mu = 0.08,
                           omega = sqrt( 0.10 ),
                           distribution = LogNormalDistribution() )

    pKm <- ModelParameter( "Km", mu = 0.40,
                           omega = sqrt( 0.30 ),
                           distribution = LogNormalDistribution() )

    ### Assign the parameters to the statistical model
    MyStatisticalModel <- defineParameter( MyStatisticalModel, pV )
    MyStatisticalModel <- defineParameter( MyStatisticalModel, pVm )
    MyStatisticalModel <- defineParameter( MyStatisticalModel, pKm )

    ### Error model (standard deviations)
    MyModel <- addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

    ### Assign the model to the project
    MyProject <- defineStatisticalModel( MyProject, MyModel )

    ### Create a design
    MyDesign<- Design()

    ### For each arm create and add the sampling times for each response
    brasTest <- Arm( name="Bras test", arm_size = 200, cond_init=list( "C1"= expression( 100/V)))

    brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK",
                                                      sample_time = c(0, 0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120),
                                                      initialTime = 0 ) )
    brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

    brasTest <- setInitialConditions( brasTest, list( "C1"= expression( 100/V) ) )

    ### Add the arm to the design
    MyDesign <- addArm( MyDesign, brasTest )

    ### Add the design to the project
    MyProject <- addDesign( MyProject, MyDesign )

    ### Evaluate the PopulationFIM
    MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
    populationFIM = getFim(MyEvaluationPop,1)
    matrixFisherPopulationFIM = getMfisher(populationFIM)
    detPopulationFim = det(matrixFisherPopulationFIM)
    valueDetPopulationFim = 5.511678e+23

    tol = 1e-6

    expect_equal(detPopulationFim,valueDetPopulationFim, tol)

  })

###################################################################################################################################

context(" Model PK 1cpt : Linear1FirstOrderSingleDose_kaVCl")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl")

  ### Get equations of the PKPD model
  EquationsPKModel = getEquations(PKModel)

  MyModelEquations = ModelEquations(EquationsPKModel)

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations)


  #### Set mu and omega for each parameter
  pka = ModelParameter( "ka", mu = 1.050,
                        omega = sqrt( 0.1 ),
                        distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.513,
                        omega = 0,
                        distribution = LogNormalDistribution() )

  pV = ModelParameter( "V", mu = 63.000,
                       omega = 0,
                       distribution = LogNormalDistribution() )

  ## !!!!
  ## erreurs + modifs pour definition des distributions ; parametres fixés ou non

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl  )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0, sigma_slope = 0.0676 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 25 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.01, 1, 3, 5, 7, 10, 13, 17, 24) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0) , amount_dose = c(5500) ) )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the IndividualFIM
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  #show(MyEvaluationPop)
  #showFims(MyEvaluationPop)
  #showDesigns(MyEvaluationPop)

  populationFIM = getFim(MyEvaluationPop,1)
  matrixFisherPopulationFIM = getMfisher(populationFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 8.835413e+13

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###################################################################################################################################

context(" Model PK 1cpt : Linear1FirstOrderSingleDose_kaVCl")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl")

  ### Get equations of the PKPD model
  EquationsPKModel = getEquations(PKModel)

  MyModelEquations = ModelEquations(EquationsPKModel)

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations)


  #### Set mu and omega for each parameter
  pka = ModelParameter( "ka", mu = 1.0,
                        omega = sqrt( 0.09 ),
                        distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 2.0,
                        omega = sqrt( 0.09 ),
                        distribution = LogNormalDistribution() )

  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl  )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 40 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 4, 8, 12.5, 13, 16, 20, 24.5, 25, 28, 32, 36.5, 37, 40, 44, 48.5, 49, 52, 56) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0,12,24,36,48) , amount_dose = c(30) ) )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the IndividualFIM
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  populationFIM = getFim(MyEvaluationPop,1)
  matrixFisherPopulationFIM = getMfisher(populationFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 2.835909e+24

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###################################################################################################################################

context(" Model PK 1cpt : Linear1FirstOrderSteadyState_kaVCltau")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIM(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1FirstOrderSteadyState_kaVCltau")

  ### Get equations of the PKPD model
  EquationsPKModel = getEquations(PKModel)

  MyModelEquations = ModelEquations(EquationsPKModel)

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations)

  ### Set mu and omega for each parameter
  pka = ModelParameter( "ka", mu = 1.050,
                        omega = sqrt( 0.1 ),
                        distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.513,
                        omega = 0,
                        distribution = LogNormalDistribution() )

  pV = ModelParameter( "V", mu = 63.000,
                       omega = 0,
                       distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl  )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.0, sigma_slope = 0.0676 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 25 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.01, 1, 3, 5, 7, 10, 13, 17, 24) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK",
                                                           tau = c(24),
                                                           amount_dose = c(5500 ) )   )

  # post it
  # comment ça fonctionne avec multiple dose en steady state
  # redecoupage, equation ?
  # dose repetee  mais avec valeurs differentes
  # regarder multidose code

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the IndividualFIM
  ##MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  populationFIM = getFim(MyEvaluationPop,1)
  matrixFisherPopulationFIM = getMfisher(populationFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 119307107189

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###########################################################################################
# END CODE
###########################################################################################




