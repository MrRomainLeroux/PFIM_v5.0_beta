##########################################################################################################
##' Class "Constant"
##'
#' @description The Class "Constant" defines the the residual error variance according
#' to the formula g(sigma_inter, sigma_slope, c_error, f(x, theta)) = sigma_inter.
#'
#' @name Constant-class
#' @aliases Constant
#' @docType class
#' @include Combined1.R
#' @exportClass Constant
#'
#' @section Objects from the Class:
#' Objects from the Class: \linkS4class{Constant} are typically created by calls to \code{Constant} and contain the following slots
#' that are heritated from the class \linkS4class{Combined1}:
#' \describe{
#' \item{.Object}{An object of Class \linkS4class{Combined1}}
#' \item{sigma_inter}{A numeric value giving the sigma inter of the error model.}
#' }
#'
##########################################################################################################

Constant<-setClass(
  Class="Constant",
  contains = "Combined1",
  prototype = prototype(
    c_error = 1,
    sigma_slope = 0
  ),
  validity=function(object)
  {
    return(TRUE)
  }
)

# Initialize method
setMethod(
  f="initialize",
  signature="Constant",
  definition= function (.Object, sigma_inter)
  {
    # Object validation
    validObject(.Object)
    .Object = callNextMethod( .Object, sigma_inter = sigma_inter, sigma_slope = 0 )
    return (.Object )
  }
)

##########################################################################################################

#' Get the names of the variances
#'
#' @rdname getSigmaNames
#' @param object An object \code{Combined1}
#' @return The character string \code{sigmaNames} giving the names of the variances


setMethod("getSigmaNames",
          "Constant",
          function(object)
          {
            sigmaNames <- c( "\u03c3_inter" )
            return(sigmaNames)
          }
)

##########################################################################################################

#' Get the values of the variances \deqn{\sigma_{inter}}
#'
#' @rdname getSigmaValues
#' @param object A \code{Constant} object.
#' @return A vector giving the values of the variances \deqn{\sigma_{inter}}

setMethod("getSigmaValues",
          "Constant",
          function(object)
          {
            return(object@sigma_inter)
          }

)

##########################################################################################################

#' Show the model errors
#'
#' @rdname show
#' @param object An object \code{Combined1} from the class \linkS4class{Combined1}
#' @return Display the model errors

setMethod(f="show",
          signature=  "Constant",
          definition=function(object)
          {
            cat(" Error model constant (sigma_inter) = ",object@sigma_inter, "\n")
          }
)


###########################################################################
# End Class Constant
###########################################################################
