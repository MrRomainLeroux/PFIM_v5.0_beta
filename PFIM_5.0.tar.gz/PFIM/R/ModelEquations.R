##################################################################################
#' Class "ModelEquations" representing a ModelEquations
#'
#' @description
#' A class storing information concerning the model equations of the models in the \linkS4class{LibraryOfModels}.
#'
#' @name ModelEquations-class
#' @aliases ModelEquations
#' @docType class
#' @exportClass ModelEquations
#'
#' @section Objects from the Class \linkS4class{ModelEquations}:
#' Objects form the Class \code{ModelEquations} can be created by calls of the form \code{ModelEquations(...)} where
#' (...) are the parameters for the \code{ModelEquations} objects.
#'
#' @section Slots for  \code{ModelEquations} objects:
#' \describe{
#' \item{\code{equations}:}{A list giving the equations of the model.}
#' \item{\code{allParameters}:}{A vector giving all the parameters of the model.}
#' }


ModelEquations <- setClass(Class = "ModelEquations",
                               representation = representation
                               (
                                 equations = "list",
                                 allParameters = "vector"
                               ))


# -------------------------------------------------------------------------------------------------------------------
#' Function to remplace a dose
#' @name  remplaceDose
#' @param ex expression ex
#' @param progression expression progression
#' @param all expression all
#' @return expression of the equation with dose expression
#'
remplaceDose<-function( ex, progression, all )
{
  for( i in 1:length( ex ) )
  {
    if ( is.symbol( ex[[i]] ) )
      if ( ex[[ i ]] == "dose" )
      {
        progression=c(progression,i)
        all[[ length(all) + 1 ]] = progression
      }
    if ( !is.symbol( ex[[ i ]] ) && !is.double( ex[[ i ]] ) )
    {
      all<-remplaceDose( ex[[ i ]], c(progression,i), all )
    }
  }
  return(all)
}


setMethod(
  f="initialize",
  signature="ModelEquations",
  definition= function (.Object, equations )
  {

    validObject(.Object)

    allParams = list()
    replaceIn = list()
    exception = c( "t", "dose", "Tinf", "tau" )
    for( equationName in names( equations ) )
    {
      e = equations[[ equationName ]]

      ### Replace dose with "dose_RespI"

      all<-remplaceDose(e , c(), list())
      if ( length( all ) > 0 )
      {
        for( i in 1:length( all ))
        {
          l<-all[[ i ]]
          m="e[["
          for( j in 1:length( l ))
          {
            v=paste0("all[[",i,"]]")
            m=paste0(m, v, "[",j,"]]][[")
          }
          m=paste0(m,"]]")

          options(useFancyQuotes = FALSE)
          str=m
          eval(parse(text=paste(strtrim(str,nchar(str)-4),paste0("=\"dose_",equationName,"\"" ) )))
        }
        str = sQuote( e )
        withoutQuote = gsub( "\'", "", str )
        withoutQuote = gsub( "\"", "", withoutQuote )

        equations[[ equationName ]] = parse( text = withoutQuote )
      }

      ### Parse all parameters of the equation
      equationParams = all.vars( equations[[ equationName ]] )
      for( param in equationParams )
      {
        if ( param %in% names( equations ) )
        {
          replaceIn[[ equationName ]]<- param
        }
        else
        if ( !( param %in% exception ) )
        {
          allParams[[ param ]] = 1
        }
      }
    }

       # Recursive responses
        for( equationName in names( equations ) )
        {
          assign( equationName, equations[[ equationName ]] )
        }
        options(useFancyQuotes = FALSE)
         for( replace in names( replaceIn ) )
         {
           f = sQuote( equations[[ replace ]] )
           g = paste( "(", sQuote( equations[[ replaceIn[[ replace ]] ]] ), ")" )
           quoted = gsub( replaceIn[[ replace ]], g, f )
           withoutQuote = gsub( "\'", "", quoted )

           equations[[ replace ]]<-parse( text = withoutQuote )
         }


    .Object@allParameters = names( allParams )



    if(!missing(equations))
      .Object@equations <- equations


    return ( .Object )
  }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the parameters of a \code{ModelEquations} object
#' @name getParameters
#' @param object A \code{ModelEquations} object
#' @return A vector \code{allParameters} giving the parameters of the model

setGeneric("getParameters",
           function(object)
           {
             standardGeneric("getParameters")
           }
)
setMethod("getParameters",
          "ModelEquations",
          function(object)
          {
            return( object@allParameters )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the number of parameters of a \code{ModelEquations} object
#' @name getNumberOfParameters
#' @param object A \code{ModelEquations} object
#' @return A numeric \code{allParameters} giving the number of parameters


setGeneric("getNumberOfParameters",
           function(object)
           {
             standardGeneric("getNumberOfParameters")
           }
)
setMethod("getNumberOfParameters",
          "ModelEquations",
          function(object)
          {
            return( length( object@allParameters ) )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the equation of a \code{ModelEquations} object with respect to its name
#' @rdname getEquation
#' @param object A \code{ModelEquations} object
#' @param equationName A character string giving the name of the response of the equations
#' @return An expression  \code{equations} giving the equation of a model with respect to its name

setMethod("getEquation",
          "ModelEquations",
          function(object, equationName)
          {
            return(object@equations[[ equationName ]])
          })

# -------------------------------------------------------------------------------------------------------------------
#' Get the equations of a \code{ModelEquations} object
#' @rdname getEquations
#' @aliases getEquations
#' @param object A \code{ModelEquations} object
#' @return A list of expression \code{equations} giving the equations of the model after the change of variable in the model

setGeneric("getEquations",
           function(object)
           {
             standardGeneric("getEquations")
           })

setMethod("getEquations",
          "ModelEquations",
          function(object)
          {
            return(object@equations)
          })

# -------------------------------------------------------------------------------------------------------------------
#' Get the index of the response of a \code{ModelEquations} object
#' @name getResponseIndice
#' @param object A \code{ModelEquations} object
#' @param equationName A character string giving the name of the response of the equations
#' @return A numeric giving the index of the equation in the model

setGeneric("getResponseIndice",
           function(object, equationName)
           {
             standardGeneric("getResponseIndice")
           }
)
setMethod("getResponseIndice",
          "ModelEquations",
          function(object, equationName)
          {
            responseNames<-names( unlist( object@equations ) )

            return( which( responseNames == equationName ) )
          }
)

#' Get the derivate of an equation of a \code{ModelEquations} object.
#'
#' @param object A \code{ModelEquations} object.
#' @param equationName A character string giving the name of the response of the equations.
#' @param parameter An \code{ModelParameter} object.
#'
#' @return A list of expression of the derivate of an equation of a \code{ModelEquations}
#'
#' @rdname getDerivate
#'
#' @docType methods

setGeneric("getDerivate",
           function(object, equationName, parameter )
           {
             standardGeneric("getDerivate")
           }
)

#' @rdname getDerivate

setMethod("getDerivate",
          "ModelEquations",
          function(object, equationName, parameter )
          {
            return( D( object@equations[[ equationName ]], parameter ) )
          }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the equations of the PK and PD models of a \code{ModelEquations} object
#' @name getEquationsModelPKPD
#' @param modelEquationsPKmodel An expression giving the equation of the PK model
#' @param modelEquationsPDmodel An expression giving the equation of the PD model
#' @return A list \code{output} giving:
#' \itemize{
#' \item{expressions for the equations of the PK and PD models}{, for a analytic PK and a analytic PD models}
#' \item{expressions for the equations of the PK and the infusion equations PD models}{, for a PD model in infusion}
#' \item{expressions for the equations of the PK and PD models}{, for a PD model in ODE}
#'}

setGeneric(
  "getEquationsModelPKPD",
  function(modelEquationsPKmodel, modelEquationsPDmodel) {
    standardGeneric("getEquationsModelPKPD")
  })

setMethod(
  "getEquationsModelPKPD",
  signature("InfusionEquations","ModelEquations"),
  function(modelEquationsPKmodel, modelEquationsPDmodel){

    # verifier type infusion

    equationPKmodel = getInfusionEquations(modelEquationsPKmodel)
    equationPDmodel = modelEquationsPDmodel@equations

    # names for the equations of the PDmodel with infusion
    equationInfusionPDModel = vector("list", length = 2)
    names(equationInfusionPDModel) = c("DuringInfusion_RespPD", "AfterInfusion_RespPD")

    # change the variables
    equationInfusionPDModel[[1]] = as.expression(do.call('substitute', list(equationPDmodel[[1]][[1]], list(RespPK = quote(DuringInfusion_RespPK)))))
    equationInfusionPDModel[[2]] = as.expression(do.call('substitute', list(equationPDmodel[[1]][[1]], list(RespPK = quote(AfterInfusion_RespPK)))))

    output = InfusionEquations(c(equationPKmodel,equationInfusionPDModel))

    return(output)

  })

setMethod(
  "getEquationsModelPKPD",
  signature("ModelEquations","ModelEquations"),
  function(modelEquationsPKmodel, modelEquationsPDmodel){

    #equationPKmodel = getEquations(modelEquationsPKmodel)
    #equationPDmodel = getEquations(modelEquationsPDmodel)

    equationPKmodel = modelEquationsPKmodel@equations
    equationPDmodel = modelEquationsPDmodel@equations

    # return the model equation
    output =  ModelEquations(c(equationPKmodel,equationPDmodel))

    return(output)

  })

setMethod("getEquationsModelPKPD",

          signature("ModelEquations","ModelODEquations"),

          function(modelEquationsPKmodel, modelEquationsPDmodel){

            equationDerivativesPDModel =  getDerivatives( modelEquationsPDmodel )

            # Number of PKModel Responses
            numberResponsePKPDmodelODE = length( modelEquationsPKmodel ) + length( equationDerivativesPDModel )

            # convert PK analytic to ODE
            pkModelODE = convertAnalyticToODE( modelEquationsPKmodel )

            names( pkModelODE ) =  paste0( "Deriv_","C", "1")
            names( equationDerivativesPDModel) =  paste0( "Deriv_","C", "2")

            # all modelODE equations
            allEquations = c( pkModelODE, equationDerivativesPDModel )

            # change variable names
            pkModelODE[[1]] = as.expression(do.call('substitute', list(pkModelODE[[1]][[1]], list(RespPK = quote(C1)))))
            equationDerivativesPDModel[[1]] = as.expression(do.call('substitute', list(equationDerivativesPDModel[[1]][[1]], list(RespPK = quote(C1)))))
            equationDerivativesPDModel[[1]] = as.expression(do.call('substitute', list(equationDerivativesPDModel[[1]][[1]], list(E = quote(C2)))))

            responsesPKPDModel = list()
            derivativesPKPDModel = list()

            responsesPKPDModel$RespPK = expression( C1 )
            responsesPKPDModel$RespPD = expression( C2 )

            derivativesPKPDModel$Deriv_C1 = pkModelODE$Deriv_C1
            derivativesPKPDModel$Deriv_C2 = equationDerivativesPDModel$Deriv_C2

            output = ModelODEquations( responsesPKPDModel, derivativesPKPDModel )

            return(output)

          })




# -------------------------------------------------------------------------------------------------------------------
#' Convert an equation of a PD model of a \code{ModelEquations} object from analytic to ODE
#' @name convertAnalyticToODE
#' @param object \code{ModelEquations} object
#' @return A list of expression \code{output} giving the equations of the analytic PD model in ODE form

setGeneric(
  "convertAnalyticToODE",

  function(object) {
    standardGeneric("convertAnalyticToODE")
  })

setMethod(
  "convertAnalyticToODE",
  signature("ModelEquations"),
  function(object){

    output = list()

    # get the equations of the PKmodel
    equationsModelPKmodel = object@equations ##getEquations(object)

    # equation for the PKmodel is an ODE of the form : dC/dc+kC=B

    for (i in 1:length(equationsModelPKmodel)){

      B = expression(dtEquationPK + k*equationPK)

      equationPKsubstitute = equationsModelPKmodel[[i]][[1]]

      dtEquationPKsubstitute = D(equationPKsubstitute, "t")

      B = Simplify(do.call('substitute', list(B[[1]], list(equationPK = equationPKsubstitute,
                                                           k = quote(Cl/V),
                                                           dtEquationPK = dtEquationPKsubstitute))))

       expr = expression(dCdt - (Cl/V)*RespPK)
      #expr = expression(dCdt - k*RespPK)

      dCdt = Simplify(do.call('substitute', list(expr[[1]], list(dCdt = B))))
      dCdt = as.expression(dCdt)

      output[[i]] = dCdt

    }

    return(output)

  })

# ########################################################################################################################
# END Class ModelEquations
# ########################################################################################################################
