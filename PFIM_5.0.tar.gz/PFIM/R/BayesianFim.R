##########################################################################################################
#' Class "BayesianFim" representing the population Fisher information matrix.
#'
#' @description
#' A class storing information regarding the population Fisher computation matrix
#' (computation method: first order linearisation (FO)).
#' @name BayesianFim-class
#' @docType class
#' @include IndividualFim.R
#' @exportClass BayesianFim
#' @section Objects from the Class:
#' Objects  are typically created by calls to \code{BayesianFim} and contain the following slots:
#'
#' \describe{
#' \item{Bayesianfim:}{Create a new \code{BayesianFim}}
#' }
#'
#'@include IndividualFim.R
#' @exportClass BayesianFim
#'
##########################################################################################################

BayesianFim<-setClass(
  Class="BayesianFim",
  contains = "IndividualFim"
)

##########################################################################################################

#' Calculates the shrinkage of individual parameters from a \code{BayesianFim} object
#'
#' @name getShrinkage
#' @param object An object \code{BayesianFim}
#' @return A numeric vector giving theshrinkage of individual parameters from a Bayesian matrix

setGeneric("getShrinkage",
           function( object )
             {
                standardGeneric("getShrinkage")
             }
)

setMethod(
  f ="getShrinkage",
  signature = "BayesianFim",
  definition = function ( object )
  {
      n = length(  object@mu )
      object@mfisher = object@mfisher[1:n,1:n]
      shrinkage <- diag( solve( object@mfisher ) %*% solve( diag( object@mu ) %*% object@omega %*% diag( object@mu ) ) ) * 100

    return(shrinkage)
  }
)

##########################################################################################################

#' Get the description \code{BayesianFim} object
#' @rdname getDescription
#' @return A string giving the description of the object \code{BayesianFim}

setMethod(
  f ="getDescription",
  signature = "BayesianFim",
  definition = function ( object )
  {
    return( "Bayesian Fisher information matrix")
  }
)

##########################################################################################################

#' Show the shrinkage of random effects of a \code{BayesianFim} object
#'
#' @rdname show
#' @param object An object \code{BayesianFim}
#' @return The numeric vector of the shrinkage of random effects of a \code{BayesianFim} object

setMethod(f = "show",
          signature = "BayesianFim",
          definition = function(object)
          {
            callNextMethod(object)
            cat("\n Shrinkage of random effects\n")
            print( getShrinkage( object ) )
          }
)

##########################################################################################################

#' Show the Bayes Expected standard errors and the variance of random effects for a  \code{BayesianFim} object
#'
#' @rdname showStatisticalModelStandardErrors
#' @param object An object \code{BayesianFim}
#' @param modelParameters An object \code{ModelParameter} from the class \linkS4class{ModelParameter}
#' @return The Bayes Expected standard errors and the variance of random effects for the \code{BayesianFim} object

setMethod("showStatisticalModelStandardErrors",
          "BayesianFim",
          function (object, modelParameters)
          {
            cat("\n Bayes Expected standard errors\n**** fixed effects \n")
            effectFrames <- getStatisticalModelStandardErrors(object, modelParameters)
            n=names( effectFrames$fixed )
            effectFrames$fixed = cbind( effectFrames$fixed, getShrinkage( object ) )

            colnames( effectFrames$fixed ) = c( n, "shrinkage(%)" )

            print(effectFrames$fixed)

            cat("\n**** variance of random effects \n")
            print(effectFrames$random)

           }

)

###########################################################################
# End Class BayesianFIM
###########################################################################
