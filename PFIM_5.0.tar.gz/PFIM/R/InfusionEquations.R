##################################################################################
##' Class "InfusionEquations" representing a model with infusion equations
##'
##' @description
##' A class giving information on the infusion equations regarding theequations of the model.
##'
##' @name InfusionEquations-class
##' @aliases InfusionEquations
##' @include ModelEquations.R
##' @docType class
##' @exportClass InfusionEquations
##'
##' @section Objects from the Class: InfusionEquations objects are typically created by calls to \code{InfusionEquations} and contain the following slots:
##'
##' \describe{
##' \item{\code{object}:}{An object from the class \code{ModelEquations}}
##' }

InfusionEquations<-setClass(
  Class = "InfusionEquations",
  contains = "ModelEquations",
  representation = representation(),
  validity = function(object)
  {
    return(TRUE)
  }
)

# -------------------------------------------------------------------------------------------------------------------
#' Get the Infusion Equations.
#' @name getInfusionEquations
#' @param object A \code{InfusionEquations} object.
#' @return A list \code{equations} of the expressions giving the infusion equations of the  \code{InfusionEquations} object

setGeneric(
  "getInfusionEquations",
  function(object) {
    standardGeneric("getInfusionEquations")
  })

setMethod("getInfusionEquations",
          signature("InfusionEquations"),
          function(object)
          {
            return(object@equations)
          })
