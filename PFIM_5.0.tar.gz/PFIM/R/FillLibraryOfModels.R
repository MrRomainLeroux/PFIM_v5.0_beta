##################################################################################
#' Function "FillLibraryOfModels"
#' @name FillLibraryOfModels
#' @description This function is used to define the models PK, PD and PKPD models and load these models in the library of models.
#'
#' @include ModelEquations.R
#' @include ModelODEquations.R
#' @include InfusionEquations.R
#' @include LibraryOfModels.R
#' @include PDModel.R
#' @include PKModel.R


options(warn=-1)

# ################################################################################################

# LibraryOfModels

# ################################################################################################



PFIMLibraryOfModels <- LibraryOfModels(nameLibraryOfModels = "Models PK & PD & PKPD")

# -------------------------------------------------------------------------------------------------------------------------
# PK Models
# -------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------------
# Linear elimination
# -------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------------
# 1 compartment
# -------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------------
# intravenous bolus
# -------------------------------------------------------------------------------------------------------------------------


# single dose
Linear1BolusSingleDose_k = PKModel( nameModel = "Linear1BolusSingleDose_k",
                                    descriptionModel = list("Linear Elimination", "1 Compartment","Bolus","Single Dose"),
                                    equationsModel = ModelEquations( list("RespPK" = expression( dose/V * (exp(-k* t))))))


Linear1BolusSingleDose_ClV = PKModel( nameModel = "Linear1BolusSingleDose_ClV",
                                      descriptionModel = list("Linear Elimination", "1 Compartment","Bolus","Single Dose"),
                                      equationsModel = ModelEquations( list("RespPK" = expression( dose/V * (exp(-(Cl/V) * t))))))

#  steady state
#à corriger !
Linear1BolusSingleDose_ClVtau = PKModel( nameModel = "Linear1BolusSingleDose_ClVtau",
                                         descriptionModel = list("Linear Elimination", "1 Compartment","Bolus","Steady State"),
                                         equationsModel = ModelEquations( list("RespPK" = expression( dose/V * ( exp(-(Cl/V))/(1-exp(-(Cl/V)*tau

                                         )))))))

# -------------------------------------------------------------------------------------------------------------------------
# infusion
# -------------------------------------------------------------------------------------------------------------------------

# single dose
Linear1InfusionSingleDose_VCl = PKModel( nameModel = "Linear1InfusionSingleDose_VCl",
                                         descriptionModel = list("Linear Elimination","1 Compartment", "Infusion", "Single Dose"),
                                         equationsModel = InfusionEquations(list(
                                           "DuringInfusion_RespPK" = expression((dose/Tinf)/(Cl) * (1 - exp(-(Cl/V) * t ) ) ) ,
                                           "AfterInfusion_RespPK"  = expression((dose/Tinf)/(Cl) * (1 - exp(-(Cl/V) * Tinf)) * (exp(-(Cl/V) * (t - Tinf)))))))

Linear1InfusionSingleDose_Vk = PKModel( nameModel = "Linear1InfusionSingleDose_Vk",
                                        descriptionModel = list("Linear Elimination","1 Compartment", "Infusion", "Single Dose"),
                                        equationsModel = InfusionEquations(list(
                                          "DuringInfusion_RespPK" = expression((dose/Tinf)/(k*V) * (1 - exp(-(k) * t ) ) ) ,
                                          "AfterInfusion_RespPK"  = expression((dose/Tinf)/(k*V) * (1 - exp(-(k) * Tinf)) * (exp(-(k) * (t - Tinf)))))))

Linear1InfusionSingleDose_kVCl = PKModel( nameModel = "Linear1InfusionSingleDose_kVCl",
                                          descriptionModel = list("Linear Elimination","1 Compartment", "Infusion", "Single Dose"),
                                          equationsModel = InfusionEquations(list(
                                            "DuringInfusion_RespPK" = expression((dose/Tinf)/(Cl) * (1 - exp(-(Cl/V) * t ) ) ) ,
                                            "AfterInfusion_RespPK"  = expression((dose/Tinf)/(Cl) * (1 - exp(-(Cl/V) * Tinf)) * (exp(-(Cl/V) * (t - Tinf)))))))


# Steady State
Linear1InfusionSteadyState_Vktau = PKModel( nameModel = "Linear1InfusionSteadyState_Vktau",
                                            descriptionModel = list("Linear Elimination","1 Compartment", "Infusion", "Steady State"),
                                            equationsModel = InfusionEquations(list(
                                              "DuringInfusion_RespPK" = expression(
                                                (dose/Tinf)/(k*V) *
                                                  ( (1 - exp(-k * t)) + exp(-k*tau) * ( (1 - exp(-k*Tinf)) * exp(-k*(t-Tinf)) / (1-exp(-k*tau))) )),

                                              "AfterInfusion_RespPK" = expression(
                                                (dose/Tinf)/(k*V) *
                                                  ( (1 - exp(-k*Tinf)) * exp(-k*(t-Tinf)) / (1-exp(-k*tau)))))))

# -------------------------------------------------------------------------------------------------------------------------
# first order absorption
# -------------------------------------------------------------------------------------------------------------------------

# single dose
Linear1FirstOrderSingleDose_kaVCl = PKModel( nameModel = "Linear1FirstOrderSingleDose_kaVCl",
                                             descriptionModel = list("Linear Elimination","1 Compartment", "First Order Absorption", "Single Dose"),
                                             equationsModel = ModelEquations( list("RespPK" = expression( dose/V * ka/(ka - (Cl/V)) * (exp(-(Cl/V) * t) - exp(-ka * t))))))

Linear1FirstOrderSingleDose_kVCl = PKModel( nameModel = "Linear1FirstOrderSingleDose_kVCl",
                                            descriptionModel = list("Linear Elimination","1 Compartment", "First Order Absorption", "Single Dose"),
                                            equationsModel = ModelEquations( list("RespPK" = expression( dose/V * ka/(ka - (k)) * (exp(-k * t) - exp(-ka * t))))))


# Steady State
Linear1FirstOrderSteadyState_kaVCltau = PKModel( nameModel = "Linear1FirstOrderSteadyState_kaVCltau",
                                                 descriptionModel = list("Linear Elimination","1 Compartment", "First Order Absorption", "Steady State"),
                                                 equationsModel = ModelEquations( list("RespPK" = expression( dose/V * ka/(ka - (Cl/V)) * ( (exp(-(Cl/V) * t))/(1-exp(-(Cl/V) * tau)) - (exp(-ka * t))/(1-exp(-ka * tau)))))))


# -------------------------------------------------------------------------------------------------------------------------
# 2 compartments
# -------------------------------------------------------------------------------------------------------------------------

## Bolus
# Single Dose
model_expression = function(){

alpha = expression((Q/V2 * Cl/V1)/beta)
alpha_expression = quote((Q/V2 * Cl/V1)/beta)
beta_expression = quote(0.5*(Q/V1+Q/V2+Cl/V1-sqrt((Q/V1 + Q/V2 + Cl/V1)**2 - 4* Q/V2 * Cl/V1 )))

alpha_substitute = do.call('substitute', list(alpha[[1]],
                                              list(beta=beta_expression)))

A = expression(1/V1 * (alpha-Q/V2)/(alpha-beta))
B = expression(1/V1 * (beta-Q/V2)/(beta-alpha))

A_substitute = do.call('substitute', list(A[[1]], list(beta = beta_expression, alpha = alpha_substitute)))
B_substitute = do.call('substitute', list(B[[1]], list(beta = beta_expression, alpha = alpha_substitute)))

model_expression = expression(dose * (A * exp(-alpha*t) + B * exp(-beta*t)))

model_expression = do.call('substitute', list(model_expression[[1]], list(beta = beta_expression,
                                                                          alpha = alpha_substitute,
                                                                          A = A_substitute,
                                                                          B = B_substitute)))
return( as.expression( model_expression ) )

}

model_expression = model_expression ()


Linear2BolusSingleDose_ClQV1V2 = PKModel( nameModel = "Linear2BolusSingleDose_ClQV1V2",
                                          descriptionModel = list("Linear Elimination","2 Compartments", "Bolus", "SingleDose"),
                                          equationsModel = ModelEquations( list("RespPK" = model_expression)))



model_expression = function(){

alpha = expression((k21 * k)/beta)
alpha_expression = quote((k21 * k)/beta)
beta_expression = quote(0.5*(k12+k21+k-sqrt((k12 + k21 + k)**2 - 4* k21 * k )))

alpha_substitute = do.call('substitute', list(alpha[[1]],
                                              list(beta=beta_expression)))

A = expression(1/V * (alpha-k21)/(alpha-beta))
B = expression(1/V * (beta-k21)/(beta-alpha))

A_substitute = do.call('substitute', list(A[[1]], list(beta = beta_expression, alpha = alpha_substitute)))
B_substitute = do.call('substitute', list(B[[1]], list(beta = beta_expression, alpha = alpha_substitute)))

model_expression = expression(dose * (A * exp(-alpha*t) + B * exp(-beta*t)))

model_expression = do.call('substitute', list(model_expression[[1]], list(beta = beta_expression,
                                                                          alpha = alpha_substitute,
                                                                          A = A_substitute,
                                                                          B = B_substitute)))
return( as.expression( model_expression ) )

}

model_expression = model_expression()

Linear2BolusSingleDose_ClVkk12k21 = PKModel( nameModel = "Linear2BolusSingleDose_ClVkk12k21",
                                             descriptionModel = list("Linear Elimination","2 Compartments", "Bolus", "SingleDose"),
                                             equationsModel = ModelEquations( list("RespPK" = model_expression)))

# -------------------------------------------------------------------------------------------------------------------------
# Michaelis-Menten elimination
# -------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------------
# 1 compartment
# -------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------------
# intravenous bolus
# -------------------------------------------------------------------------------------------------------------------------


MichaelisMentenBolusSingleDose_VmKmC = PKModel( nameModel = "MichaelisMentenBolusSingleDose_VmKmC",
                                                descriptionModel =  list("Michaelis-Menten", "1 Compartment", "Bolus", "SingleDose"),
                                                equationsModel = ModelODEquations(
                                                  list("RespPK" = expression(C1)),
                                                  list("Deriv_C1" = expression(-1.0*(Vm*C1)/(Km+C1)))))



MichaelisMentenFirstOrderSingleDose_VmKmC = PKModel( nameModel = "MichaelisMentenFirstOrderSingleDose_VmKmC",
                                                     descriptionModel =  list("Michaelis-Menten", "1 Compartment", "FirstOrder", "SingleDose"),
                                                     equationsModel = ModelODEquations(
                                                       list("RespPK" = expression(C1)),
                                                       list("Deriv_C1" = expression(-1.0*(Vm*C1)/(Km+C1) + dose_RespPK/V*ka*exp(-ka*t)))))



MichaelisMentenBolusInfusionSingleDose_VVmKmC = PKModel( nameModel = "MichaelisMentenBolusInfusionSingleDose_VVmKmC",
                                                         descriptionModel = list("Bolus","1 Compartment", "Infusion", "Single Dose"),
                                                         equationsModel = ModelODEquations(
                                                           list("RespPK" = expression(C1)),
                                                           list("Deriv_C1" = expression(-1.0*(Vm*C1)/(Km+C1) + dose_RespPK/(V*Tinf)))))






# -------------------------------------------------------------------------------------------------------------------------
# PD Models
# -------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------------
# Immediate Response Models
# -------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------------
# Drug action models
# -------------------------------------------------------------------------------------------------------------------------

# linear
ImmediateDrugLinear_Alin = PDModel( nameModel = "ImmediateDrugLinear_Alin",
                                    descriptionModel = list("Immediate Response","Drug action ", "Linear"),
                                    equationsModel = ModelEquations( list("RespPD" = expression( RespPK * Alin ))))

# quadratic
ImmediateDrugImaxQuadratic_Alin_Aquad = PDModel( nameModel = "ImmediateDrugImaxQuadratic_Alin_Aquad",
                                                 descriptionModel = list("Immediate Response", "Drug action ", "Quadratic"),
                                                 equationsModel = ModelEquations( list("RespPD" = expression( RespPK * Alin + Alin * (RespPK)**2))))

# logarithmic
ImmediateDrugImaxLogarithmic_Alog = PDModel( nameModel = "ImmediateDrugImaxLogarithmic_Alog",
                                             descriptionModel = list("Immediate Response", "Drug action ", "Logarithmic"),
                                             equationsModel = ModelEquations( list("RespPD" = expression( Alog * log(RespPK)))))
# Emax
ImmediateDrugEmax_EmaxC50 = PDModel( nameModel = "ImmediateDrugEmax_EmaxC50",
                                     descriptionModel = list("Immediate Response", "Drug action ", "Emax"),
                                     equationsModel = ModelEquations(list("RespPD" = expression( (Emax*(RespPK))/(RespPK+C50)))))

# Sigmoid Emax
ImmediateDrugSigmoidEmax_EmaxC50gamma = PDModel( nameModel = "ImmediateDrugSigmoidEmax_EmaxC50gamma",
                                                 descriptionModel = list("Immediate Response", "Drug action ", "Emax"),
                                                 equationsModel = ModelEquations(list("RespPD" = expression( (Emax*(RespPK**gamma))/(RespPK**gamma+C50**gamma)))))

# Imax
ImmediateDrugImax_S0ImaxC50 = PDModel( nameModel = "ImmediateDrugImax_S0ImaxC50",
                                       descriptionModel = list("Immediate Response","Drug action", "Imax"),
                                       equationsModel = ModelEquations( list("RespPD" = expression( S0 * (1 - Imax * RespPK/( RespPK + C50 ))))))

# Sigmoid Imax
ImmediateDrugImax_S0ImaxC50_gamma = PDModel( nameModel = "ImmediateDrugImax_S0ImaxC50_gamma",
                                             descriptionModel = list("Immediate Response","Drug action", "Imax"),
                                             equationsModel = ModelEquations( list("RespPD" = expression(S0 * (1 - Imax * RespPK/(RespPK**gamma + C50**gamma ))))))

# -------------------------------------------------------------------------------------------------------------------------
# Baseline/disease models
# -------------------------------------------------------------------------------------------------------------------------

# Constant
ImmediateBaselineConstant_S0 = PDModel( nameModel = "ImmediateBaselineConstant_S0",
                                        descriptionModel = list("Immediate Response", "BaselineDisease", "Constant"),
                                        equationsModel = ModelEquations( list("RespPD" = expression(S0))))

# Linear
ImmediateBaselineLinear_S0kprog = PDModel( nameModel = "ImmediateBaselineLinear_S0kprog",
                                           descriptionModel = list("Immediate Response", "BaselineDisease", "Linear"),
                                           equationsModel = ModelEquations( list("RespPD" = expression(S0 + kprog*t))))

# Exponential disease increase
ImmediateBaselineExponentialincrease_S0kprog = PDModel( nameModel = "ImmediateBaselineExponentialincrease_S0kprog",
                                                        descriptionModel = list("Immediate Response", "BaselineDisease", "Exponential disease increase"),
                                                        equationsModel = ModelEquations( list("RespPD" = expression(S0*exp(-kprog*t)))))
# Exponential disease decrease
ImmediateBaselineExponentialincrease_S0kprog = PDModel( nameModel = "ImmediateBaselineExponentialincrease_S0kprog",
                                                        descriptionModel = list("Immediate Response", "BaselineDisease", "Exponential disease decrease"),
                                                        equationsModel = ModelEquations( list("RespPD" = expression(S0*(1-exp(-kprog*t))))))

# -------------------------------------------------------------------------------------------------------------------------
# Turnover Models
# -------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------------
# Models with impact on the input (Rin)
# -------------------------------------------------------------------------------------------------------------------------

# Emax
TurnoverRinEmax_RinEmaxCC50koutE = PDModel( nameModel = "TurnoverRinEmax_RinEmaxCC50koutE",
                                            descriptionModel = list("Turnover", "Rin", "Emax"),
                                            equationsModel = ModelODEquations(
                                              list("RespPD" = expression( E )),
                                              list("Deriv_E" = expression(Rin*(1+(Emax*RespPK)/(RespPK+C50))-kout*E))))

# Sigmoid Emax
TurnoverRinSigmoidEmax_RinEmaxCC50koutE = PDModel(nameModel = "TurnoverRinSigmoidEmax_RinEmaxCC50koutE",
                                                  descriptionModel = list("Turnover", "Rin", "Sigmoid Emax"),
                                                  equationsModel = ModelODEquations(
                                                    list("RespPD" = expression( E )),
                                                    list("Deriv_E" = expression(Rin*(1+(Emax*RespPK**gamma)/(RespPK**gamma+C50**gamma))-kout*E))))

# Imax
TurnoverRinImax_RinImaxCC50koutE = PDModel(nameModel = "TurnoverRinImax_RinImaxCC50koutE",
                                           descriptionModel = list("Turnover", "Rin", "Imax"),
                                           equationsModel = ModelODEquations(
                                             list("RespPD" = expression( E )),
                                             list("Deriv_E" = expression(Rin*(1+(Imax*RespPK)/(RespPK+C50))-kout*E))))

# Sigmoid Imax
TurnoverRinSigmoidImax_RinImaxCC50koutE = PDModel(nameModel = "TurnoverRinSigmoidImax_RinImaxCC50koutE",
                                                  descriptionModel = list("Turnover", "Rin", "Sigmoid Imax"),
                                                  equationsModel = ModelODEquations(
                                                    list("RespPD" = expression( E )),
                                                    list("Deriv_E" = expression(Rin*(1+(Imax*RespPK**gamma)/(RespPK**gamma+C50**gamma))-kout*E))))

# Full Imax
TurnoverRinFullImax_RinCC50koutE = PDModel( nameModel = "TurnoverRinFullImax_RinCC50koutE",
                                            descriptionModel =  list("Turnover", "Rin", "Full Imax"),
                                            equationsModel = ModelODEquations(
                                              list("RespPD" = expression( E )),
                                              list("Deriv_E" = expression(Rin*(1-(RespPK)/(RespPK+C50))-kout*E))))

# Sigmoid Full Imax
TurnoverRinSigmoidFullImax_RinCC50koutE = PDModel( nameModel = "TurnoverRinSigmoidFullImax_RinCC50koutE",
                                                   descriptionModel = list("Turnover", "Rin", "Sigmoid Full Imax"),
                                                   equationsModel = ModelODEquations(
                                                     list("RespPD" = expression( E )),
                                                     list("Deriv_E" = expression(Rin*(1-RespPK**gamma/(RespPK**gamma+C50**gamma))-kout*E))))

# -------------------------------------------------------------------------------------------------------------------------
# Models with impact on the output (kout)
# -------------------------------------------------------------------------------------------------------------------------

# Emax
TurnoverkoutEmax_RinEmaxCC50koutE = PDModel( nameModel = "TurnoverRinEmax_RinEmaxCC50koutE",
                                             descriptionModel = list("Turnover", "Rin", "Emax"),
                                             equationsModel = ModelODEquations(
                                               list("RespPD" = expression( E )),
                                               list("Deriv_E" = expression( Rin*(1+(Emax*RespPK)/(RespPK+C50))-kout*E))))

# Sigmoid Emax
TurnoverkoutSigmoidEmax_RinEmaxCC50koutEgamma = PDModel( nameModel = "TurnoverkoutSigmoidEmax_RinEmaxCC50koutEgamma",
                                                         descriptionModel = list("Turnover", "kout", "Sigmoid Emax"),
                                                         equationsModel = ModelODEquations(
                                                           list("RespPD" = expression( E )),
                                                           list("Deriv_E" = expression(Rin-kout*(1+(Emax*RespPK**gamma)/(RespPK**gamma+C50**gamma))*E))))
# Imax
TurnoverkoutImax_RinImaxCC50koutE = PDModel( nameModel = "TurnoverkoutImax_RinImaxCC50koutE",
                                             descriptionModel = list("Turnover", "kout", "Imax"),
                                             equationsModel = ModelODEquations(
                                               list("RespPD" = expression( E )),
                                               list("Deriv_E" = expression(Rin-kout*(1-Imax*RespPK/(RespPK+C50))*E))))

# Sigmoid Imax
TurnoverkoutSigmoidImax_RinImaxCC50koutEgamma = PDModel( nameModel = "TurnoverkoutSigmoidImax_RinImaxCC50koutEgamma",
                                                         descriptionModel = list("Turnover", "kout", "Sigmoid Imax"),
                                                         equationsModel = ModelODEquations(
                                                           list("RespPD" = expression( E )),
                                                           list("Deriv_E" = expression(Rin-kout*(1-Imax*RespPK**gamma/(RespPK**gamma+C50**gamma))*E))))

# Full Imax
TurnoverkoutFullImax_RinCC50koutE = PDModel( nameModel = "TurnoverkoutFullImax_RinCC50koutE",
                                             descriptionModel = list("Turnover", "kout", "Full Imax"),
                                             equationsModel = ModelODEquations(
                                               list("RespPD" = expression( E )),
                                               list("Deriv_E" = expression(Rin-kout*(1-RespPK/(RespPK+C50))*E))))


# Sigmoid Full Imax
TurnoverkoutSigmoidFullImax_RinCC50koutE = PDModel( nameModel = "TurnoverkoutSigmoidFullImax_RinCC50koutE",
                                                    descriptionModel = list("Turnover", "kout", "Sigmoid Full Imax"),
                                                    equationsModel = ModelODEquations(
                                                      list("RespPD" = expression( E )),
                                                      list("Deriv_E" = expression(Rin-kout*(1-RespPK**gamma/(RespPK**gamma+C50**gamma))*E))))

# -------------------------------------------------------------------------------------------------------------------------
# Add PK and PD models to the library
# -------------------------------------------------------------------------------------------------------------------------

PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels, Linear1BolusSingleDose_ClV)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels, Linear1BolusSingleDose_k)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels, Linear1BolusSingleDose_ClVtau)

PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels, Linear1InfusionSingleDose_Vk)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels, Linear1InfusionSingleDose_VCl)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels, Linear1FirstOrderSingleDose_kVCl)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels, Linear1InfusionSingleDose_kVCl)

PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels, MichaelisMentenBolusSingleDose_VmKmC)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels, MichaelisMentenFirstOrderSingleDose_VmKmC)

PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels, Linear1InfusionSteadyState_Vktau)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels, Linear1FirstOrderSingleDose_kaVCl)
PFIMLibraryOfModels <- addModel(PFIMLibraryOfModels,  Linear1FirstOrderSteadyState_kaVCltau)
PFIMLibraryOfModels <- addModel(PFIMLibraryOfModels,  Linear2BolusSingleDose_ClVkk12k21)
PFIMLibraryOfModels <- addModel(PFIMLibraryOfModels,  Linear2BolusSingleDose_ClQV1V2)

PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  ImmediateDrugLinear_Alin)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  ImmediateDrugImaxQuadratic_Alin_Aquad)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  ImmediateDrugImaxLogarithmic_Alog)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  ImmediateDrugEmax_EmaxC50)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  ImmediateDrugSigmoidEmax_EmaxC50gamma)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  ImmediateDrugImax_S0ImaxC50)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  ImmediateDrugImax_S0ImaxC50_gamma)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  ImmediateBaselineConstant_S0)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  ImmediateBaselineLinear_S0kprog)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  ImmediateBaselineExponentialincrease_S0kprog)

PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  TurnoverRinSigmoidEmax_RinEmaxCC50koutE)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  TurnoverRinImax_RinImaxCC50koutE)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  TurnoverRinSigmoidImax_RinImaxCC50koutE)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  TurnoverRinFullImax_RinCC50koutE)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  TurnoverRinSigmoidFullImax_RinCC50koutE)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  TurnoverkoutEmax_RinEmaxCC50koutE)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  TurnoverkoutSigmoidEmax_RinEmaxCC50koutEgamma)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  TurnoverkoutImax_RinImaxCC50koutE)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  TurnoverkoutSigmoidImax_RinImaxCC50koutEgamma)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  TurnoverkoutFullImax_RinCC50koutE)
PFIMLibraryOfModels <- addModel( PFIMLibraryOfModels,  TurnoverkoutSigmoidFullImax_RinCC50koutE)




