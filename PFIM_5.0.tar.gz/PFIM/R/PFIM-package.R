#' @name PFIM-package
#' @aliases package-PFIM
#' @docType package
#' @title PFIM for optimal design in nonlinear mixed effects models.
#' @section Evaluation:
#' The nonlinear mixed effects models (NLMEM) are
#' widely used in model-based drug development to analyse longitudinal data.
#' On the other hand, the use of the Fisher Information Matrix (FIM) is a good alternative to clinical trial
#' simulation to optimize the design of these studies. For these two reasons,
#' PFIM 4.0 has an R package \pkg{PFIM} (using the S4 object system) for evaluating and/or optimizing population designs based on
#' the Fisher information matrix (FIM) in NLMEMs [1].
#' This \pkg{PFIM} is developed with the object-oriented system S4 of R.
#' This new version of PFIM now includes a library of models implemented in that way.
#' This new library contains two libraries of PK and PD models respectively.
#' The PK library includes model with different administration routes (bolus, infusion, first-order absorption),
#' different number of compartments (from 1 to 3), and different types of eliminations (linear or Michaelis-Menten).
#' The PD model library, contains direct immediate models (e.g. Emax and Imax) with various baseline models,
#' and turnover response models. The PK/PD models, on the other hand, are obtained with combination of the models
#' from the PK and PD model libraries. PFIM handles both analytical and ODE models and offers the possibility to
#' the user to define his own models.
#' @section Optimisation:
#' \pkg{PFIM} offers a great flexibility to conduct population design evaluation and optimization.
#' These design evaluation and optimization are based on the evaluation of the FIM. In the new version of PFIM, the FIM is
#' evaluated by first order linearization of the model [3], as in PFIM 4.0. Bayesian FIM is also available to give
#' shrinkage predictions [4]. \pkg{PFIM} offers now several algorithms to conduct design optimization given design constraints and based on the D-criterion: simplex algorithm (Nelder-Mead) [5], multiplicative algorithm [6], Fedorov-Wynn algorithm [7], PSO (\emph{Particle Swarm Optimization}) and PGBO (\emph{Population Genetics Based Optimizer}) [9].
#' @section Validation:
#' It also provides quality control with tests and validation using the evaluated FIM to assess the validity
#' of the new version and its new features. Finally, display all the results with both clear graphical form and a
#' data summary, while ensuring their easy manipulation in R. The standard data visualization package ggplot2 for R is used to display all the results with clear graphical form [10]. A quality control using a criterion based on the evaluation of the determinant of the FIM is also provided.
#'
#' @references
#' [1] Dumont C, Lestini G, Le Nagard H, Mentré F, Comets E, Nguyen TT, et al. PFIM 4.0, an extended R program for design evaluation and optimization in nonlinear mixed-effect models. Comput Methods Programs Biomed. 2018;156:217-29.
#' @references [2] Chambers JM. Object-Oriented Programming, Functional Programming and R. Stat Sci. 2014;29:167-80.
#' @references [3] Mentré F, Mallet A, Baccar D. Optimal Design in Random-Effects Regression Models. Biometrika. 1997;84:429-42.
#' @references [4] Combes FP, Retout S, Frey N, Mentré F. Prediction of shrinkage of individual parameters using the bayesian information matrix in non-linear mixed effect models with evaluation in pharmacokinetics. Pharm Res. 2013;30:2355-67.
#' @references [5] Nelder, John A., and Roger Mead. 1965. “A Simplex Method for Function Minimization.” Computer Journal 7: 308–13.
#' @references [6] Yu Y. Monotonic convergence of a general algorithm for computing optimal designs. Ann Stat. 2010;38:1593-606.
#' @references [7] Fedorov, V. V. 1972. Theory of Optimal Experiments by v.v. Fedorov. Translated and Edited by w.j. Studden and e.m. Klimko. Book. Academic Press New York.
#' @references [8] Eberhart, R. and Kennedy, J. (1995) A new optimizer using particle swarm theory. In Micro Machine and Human Science, 1995. MHS’95., Proceedings of the Sixth International Symposium on, 39–43. IEEE.
#' @references [9] Le Nagard, Hervé, Lin Chao, and Olivier Tenaillon. 2011. “The emergence of complexity and restricted pleiotropy in adapting networks.” BMC Evolutionary Biology 11 (1): 326.
#' @references [10] Wickham H., ggplot2: Elegant Graphics for Data Analysis, Springer-Verlag New York, 2016; 978-3-319-24277-4.
#'
#' @section Organization of the source code / files in the \code{/R} folder:
#' The \pkg{PFIM} contains a hierarchy of S4 classes with corresponding methods and functions serving as constructors.
#' All of the source code related to the specification of a certain class is contained in a file named
#' \code{[Name_of_the_class]-Class.R}. These classes include:
#'
#' \itemize{
#' \item{1.} all roxygen \code{@@include} to insure the correctly generated collate for the DESCRIPTION file,
#' \item{2.} \code{\\setClass} preceded by a roxygen documentation that describes the purpose and slots of the class,
#' \item{3.} specification of an initialize method,
#' \item{4.} all getter and setter, respectively returning attributes of the object and associated objects.
#' }
#'
#' The following class diagrams provide an overview on the structure of the package.
#' \if{html}{\figure{PFIMClassDiagram.png}{options: width=960}}
#' \if{latex}{\figure{PFIMClassDiagram.pdf}{options: width=14cm}}
#'
#' @section Content of the source code and files in the \code{/R} folder:

#'
#' \itemize{
#'
#' \item {Class \code{\link{Administration}}}{
#'
#'   \itemize{
#'      \item \code{\link{getAllowedDose}}
#'      \item \code{\link{getAllowedTime}}
#'      \item \code{\link{getAllowedTinf}}
#'      \item \code{\link{getAmountDose}}
#'      \item \code{\link{getNameAdministration}}
#'      \item \code{\link{getTau}}
#'      \item \code{\link{getTimeDose}}
#'      \item \code{\link{getTinf}}
#'      \item \code{\link{is.multidose}}
#'      \item \code{\link{setAllowedDose}}
#'      \item \code{\link{setAllowedTime<-}}
#'      \item \code{\link{setAllowedTinf<-}}
#'      \item \code{\link{setAmountDose}}
#'      \item \code{\link{setTau}}
#'      \item \code{\link{setTimeDose<-}}
#'      \item \code{\link{setTinf}}
#'    }
#'}
#'
#'\item{Class \code{\link{AdministrationConstraint}}}{
#'
#'   \itemize{
#'    \item   \code{\link{AllowedDoses}}
#'    \item   \code{\link{fixedDoses}}
#'    \item   \code{\link{getAllowedDoses}}
#'    \item   \code{\link{getDoseOptimisability}}
#'    \item   \code{\link{getNumberOfDoses}}
#'    \item   \code{\link{getResponseName}}
#'    }
#'}
#'
#'\item{Class \code{\link{Arm}} } {
#'
#'   \itemize{
#'    \item   \code{\link{addAdministration}}
#'    \item   \code{\link{addSampling}}
#'    \item   \code{\link{EvaluateStatisticalModel}}
#'    \item   \code{\link{getAdministration}}
#'    \item   \code{\link{getAdministrationByOutcome}}
#'    \item   \code{\link{getArmSize}}
#'    \item   \code{\link{getCondInit}}
#'    \item   \code{\link{getSamplings}}
#'    \item   \code{\link{setArmSize}}
#'    \item   \code{\link{setInitialConditions}}
#'    \item   \code{\link{setSamplings<-}}
#'    }
#'}
#'
#'\item{Class \code{\link{BayesianFim}}}{
#'
#'   \itemize{
#'    \item   \code{\link{getDescription}}
#'    \item   \code{\link{getShrinkage}}
#'    \item   \code{\link{show}}
#'    \item   \code{\link{showStatisticalModelStandardErrors}}
#'    }
#'}
#'
#'\item{Classes \code{\link{Combined1}}, \code{\link{Combined1c}}, \code{\link{Combined2}}, \code{\link{Combined2c}}}{
#'
#'   \itemize{
#'    \item   \code{\link{getSigmaNames}}
#'    \item   \code{\link{getSigmaValues}}
#'    \item   \code{\link{show}}
#'    }
#'}
#'
#'\item{Class \code{\link{Constant}}} {
#'
#'   \itemize{
#'    \item   \code{\link{getSigmaNames}}
#'    \item   \code{\link{getSigmaValues}}
#'    \item   \code{\link{show}}
#'    }
#'}
#'
#'
#'
#'\item{Class \code{\link{Constraint}}}
#'
#'\item{Class \code{\link{ContinuousConstraint}}} {
#'
#'   \itemize{
#'    \item   \code{\link{getRange}}
#'    \item   \code{\link{setRange<-}}
#'    }
#'}
#'
#'\item{Class \code{\link{Design}}}{
#'
#'   \itemize{
#'    \item   \code{\link{addArm}}
#'    \item   \code{\link{EvaluateDesignForEachArm}}
#'    \item   \code{\link{EvaluateRSEforEachDesign}}
#'    \item   \code{\link{EvaluateSEforEachDesign}}
#'    \item   \code{\link{getAmountOfArms}}
#'    \item   \code{\link{getArms}}
#'    \item   \code{\link{getFimOfDesign}}
#'    \item   \code{\link{getNameDesign}}
#'    \item   \code{\link{getNumberSamples}}
#'    \item   \code{\link{setNumberSamples<-}}
#'    \item   \code{\link{getOptimizationResult}}
#'    \item   \code{\link{getTotalSize}}
#'    \item   \code{\link{modifyArm}}
#'    \item   \code{\link{setAmountOfArms}}
#'    \item   \code{\link{setArms}}
#'    \item   \code{\link{setNameDesign}}
#'    \item   \code{\link{setTotalSize<-}}
#'    \item   \code{\link{show}}
#'    \item   \code{\link{showArmData}}
#'    \item   \code{\link{summary}}
#'    \item   \code{\link{summaryArmData}}
#'    }
#'}
#'
#'\item{Class  \code{\link{DesignConstraint}}}{
#'
#'   \itemize{
#'    \item   \code{\link{addAdministrationConstraint}}
#'    \item   \code{\link{addDesignConstraints}}
#'    \item   \code{\link{addSamplingConstraint}}
#'    \item   \code{\link{getAdministrationConstraint}}
#'    \item   \code{\link{getNameDesignConstraint}}
#'    \item   \code{\link{getTotalNumberOfIndividuals}}
#'    \item   \code{\link{getSamplingConstraints}}
#'    \item   \code{\link{setAmountOfArmsAim}}
#'    \item   \code{\link{setPossibleArms}}
#'    \item   \code{\link{setTotalNumberOfIndividuals}}
#'    \item   \code{\link{show}}
#'    }
#'}
#'
#'\item{Class DiscreteConstraint}{
#'
#'   \itemize{
#'    \item   \code{\link{getDiscret}}
#'    \item   \code{\link{setDiscret<-}}
#'    }
#'}
#'
#'\item{Class \code{\link{Distribution}}}
#'
#'\item{Class \code{\link{FedorovWynnAlgorithm}}}{
#'   \itemize{
#'  \item \code{\link{FedorovWynnAlgorithm_Rcpp}}
#'    \item \code{\link{resizeFisherMatrix}}
#'    \item \code{\link{indicesVectorsInElementaryProtocols}}
#'    \item \code{\link{PrepareFIMs}}
#'    \item \code{\link{Optimize}}
#'   }
#'}
#'
#'\item{Class \code{\link{Fim}}}{
#'
#'   \itemize{
#'    \item   \code{\link{FinalizeFIMForOneElementaryDesign}}
#'    \item   \code{\link{getConditionNumberMatrix}}
#'    \item   \code{\link{getCorr}}
#'    \item   \code{\link{getDcriterion}}
#'    \item   \code{\link{getDescription}}
#'    \item   \code{\link{getDeterminant}}
#'    \item   \code{\link{getEigenValue}}
#'    \item   \code{\link{getFimComputMethod}}
#'    \item   \code{\link{getMfisher}}
#'    \item   \code{\link{getSE}}
#'    \item   \code{\link{getStatisticalModelStandardErrors}}
#'    \item   \code{\link{setFimComputMethod<-}}
#'    \item   \code{\link{setMfisher<-}}
#'    \item   \code{\link{setMu}}
#'    \item   \code{\link{setOmega}}
#'    \item   \code{\link{show}}
#'    \item   \code{\link{showStatisticalModelStandardErrors}}
#'    }
#'}
#'
#'\item{Class \code{\link{IndividualFim}}}{
#'
#'   \itemize{
#'    \item   \code{\link{getDescription}}
#'    \item   \code{\link{getStatisticalModelStandardErrors}}
#'    \item   \code{\link{show}}
#'    \item   \code{\link{showStatisticalModelStandardErrors}}
#'   }
#'}
#'
#'\item{Class code{\link{InfusionEquations}}}{
#'
#'   \itemize{
#'    \item   \code{\link{getInfusionEquations}}
#'   }
#'}
#'
#'
#'\item{Class \code{\link{LibraryOfModels}}}{
#'
#'   \itemize{
#'    \item   \code{\link{addModel}}
#'    \item   \code{\link{getContentsLibraryOfModels}}
#'    \item   \code{\link{getModel}}
#'    \item   \code{\link{getModelNameList}}
#'    \item   \code{\link{getPKPDModel}}
#'   }
#'}
#'
#'\item{Class \code{\link{LogNormalDistribution}}} {
#'
#'   \itemize{
#'    \item   \code{\link{AdjustLogNormalDistribution}}
#'   }
#'}
#'
#'\item{Class \code{\link{Model}}}{
#'
#'   \itemize{
#'    \item   \code{\link{getEquations}}
#'    \item   \code{\link{getEquationsModel}}
#'    \item   \code{\link{getModelName}}
#'    \item   \code{\link{setParametersModel}}
#'   }
#'}
#'
#'\item{Class \code{\link{ModelEquations}}}{
#'
#'   \itemize{
#'    \item   \code{\link{convertAnalyticToODE}}
#'    \item   \code{\link{getDerivate}}
#'    \item   \code{\link{getEquation}}
#'    \item   \code{\link{getEquations}}
#'    \item   \code{\link{getEquationsModelPKPD}}
#'    \item   \code{\link{getNumberOfParameters}}
#'    \item   \code{\link{getParameters}}
#'    \item   \code{\link{getResponseIndice}}
#'    \item   \code{\link{remplaceDose}}
#'   }
#'}
#'
#'\item{Class \code{\link{ModelError}}} {
#'
#'   \itemize{
#'    \item   \code{\link{g}}
#'    \item   \code{\link{getCError}}
#'    \item   \code{\link{getDVSigma}}
#'    \item   \code{\link{getEquation}}
#'    \item   \code{\link{getErrorModelParameters}}
#'    \item   \code{\link{getNumberOfParameter}}
#'    \item   \code{\link{getSig}}
#'    \item   \code{\link{getSigmaInter}}
#'    \item   \code{\link{getSigmaNames}}
#'    \item   \code{\link{getSigmaSlope}}
#'    \item   \code{\link{getSigmaValues}}
#'    \item   \code{\link{setCError<-}}
#'    \item   \code{\link{setSigmaInter<-}}
#'    \item   \code{\link{setSigmaSlope<-}}
#'    \item   \code{\link{show}}
#'   }
#'}
#'
#'\item{Class \code{\link{ModelODEquations}}}{
#'
#'   \itemize{
#'    \item   \code{\link{EvaluateDerivatives}}
#'    \item   \code{\link{getDerivatives}}
#'   }
#'}
#'
#'\item{Class \code{\link{ModelParameter}}}{
#'
#'   \itemize{
#'    \item   \code{\link{getDerivatesAdjustedByDistribution}}
#'    \item   \code{\link{getDistribution}}
#'    \item   \code{\link{getMu}}
#'    \item   \code{\link{getNameModelParameter}}
#'    \item   \code{\link{getOmega}}
#'    \item   \code{\link{isFixed}}
#'    \item   \code{\link{isFixedMu}}
#'    \item   \code{\link{isNotFixed}}
#'    \item   \code{\link{isNotFixedMu}}
#'   }
#'}
#'
#'\item{Class \code{\link{ModelVariable}}}{
#'
#'   \itemize{
#'    \item   \code{\link{getNameModelVariable}}
#'   }
#'}
#'
#'\item{Class \code{\link{MultiplicativeAlgorithm}}}{
#'
#'   \itemize{
#'    \item   \code{\link{getOptimalDesign}}
#'    \item   \code{\link{getWeightFrame}}
#'    \item   \code{\link{MultiplicativeAlgorithm_Rcpp}}
#'    \item   \code{\link{Optimize}}
#'    \item   \code{\link{PrepareFIMs}}
#'    \item   \code{\link{setDelta}}
#'    \item   \code{\link{setIteration}}
#'    \item   \code{\link{setShowProcess}}
#'    \item   \code{\link{show}}
#'   }
#'}
#'
#'\item{Class \code{\link{NormalDistribution}}}{
#'
#'   \itemize{
#'    \item   \code{\link{AdjustNormalDistribution}}
#'   }
#'}
#'
#'\item{Class ODEStatisticalModel}{
#'
#'   \itemize{
#'    \item   \code{\link{defineVariable}}
#'    \item   \code{\link{Evaluate}}
#'   }
#'}
#'
#'\item{Class \code{\link{Optimization}}}{
#'
#'   \itemize{
#'    \item   \code{\link{Combinaison}}
#'    \item   \code{\link{EvaluateFIMsAndDesigns}}
#'    \item   \code{\link{getElementaryProtocols}}
#'    \item   \code{\link{getOptimalDesign}}
#'    \item   \code{\link{setOptimalDesign}}
#'    \item   \code{\link{Optimize}}
#'    \item   \code{\link{PrepareFIMs}}
#'    \item   \code{\link{setShowProcess}}
#'    \item   \code{\link{show}}
#'   }
#'}
#'
#'\item{Class \code{\link{PDModel}}}
#'
#'\item{Class \code{\link{PFIMProject}}}{
#'
#'   \itemize{
#'    \item   \code{\link{addDesign}}
#'    \item   \code{\link{addDesigns}}
#'    \item   \code{\link{defineStatisticalModel}}
#'    \item   \code{\link{EvaluateBayesianFIM}}
#'    \item   \code{\link{EvaluateDesign}}
#'    \item   \code{\link{EvaluateIndividualFIM}}
#'    \item   \code{\link{EvaluatePopulationFIM}}
#'    \item   \code{\link{getDesign}}
#'    \item   \code{\link{getFim}}
#'    \item   \code{\link{getFims}}
#'    \item   \code{\link{getFisherMatrices}}
#'    \item   \code{\link{getGraphOptions}}
#'    \item   \code{\link{getNamePFIMProject}}
#'    \item   \code{\link{getStatisticalModel}}
#'    \item   \code{\link{getWeights}}
#'    \item   \code{\link{OptimizeDesign}}
#'    \item   \code{\link{plotCriteria}}
#'    \item   \code{\link{plotResponse}}
#'    \item   \code{\link{plotRSE}}
#'    \item   \code{\link{plotSE}}
#'    \item   \code{\link{plotSensitivity}}
#'    \item   \code{\link{plotWeightOptimisation}}
#'    \item   \code{\link{resultsFedorovWynnAlgorithm}}
#'    \item   \code{\link{setConstraint}}
#'    \item   \code{\link{setDesign}}
#'    \item   \code{\link{setGraphOptions<-}}
#'    \item   \code{\link{setNamePFIMProject<-}}
#'    \item   \code{\link{setPreviousFim<-}}
#'    \item   \code{\link{show}}
#'    \item   \code{\link{showConstraints}}
#'    \item   \code{\link{showDesigns}}
#'    \item   \code{\link{showFims}}
#'    \item   \code{\link{summary}}
#'    \item   \code{\link{summaryProjectPFIM}}
#'   }
#'}
#'
#'\item{Class \code{\link{PKModel}}}{
#'
#'   \itemize{
#'    \item   \code{\link{changeVariablePKModel}}
#'    \item   \code{\link{getEquations}}
#'   }
#'}
#'
#'\item{Class \code{\link{PKPDModel}}}{
#'
#'   \itemize{
#'    \item   \code{\link{getEquations}}
#'    \item   \code{\link{getPDModel}}
#'    \item   \code{\link{getPKModel}}
#'   }
#'}
#'
#'\item{Class \code{\link{PopulationFim}}}{
#'
#'   \itemize{
#'    \item   \code{\link{FinalizeFIMForOneElementaryDesign}}
#'    \item   \code{\link{getDescription}}
#'    \item   \code{\link{getStatisticalModelStandardErrors}}
#'    \item   \code{\link{showStatisticalModelStandardErrors}}
#'   }
#'}
#'
#'
#'\item{Class \code{\link{Response}}}{
#'
#'   \itemize{
#'    \item   \code{\link{computeODE}}
#'    \item   \code{\link{computeODEInfusion}}
#'    \item   \code{\link{computeAnalytic}}
#'    \item   \code{\link{dataForLsoda}}
#'    \item   \code{\link{EvaluateErrorModelDerivatives}}
#'    \item   \code{\link{EvaluateFirstDerivatives}}
#'    \item   \code{\link{EvaluateODEErrorModelDerivatives}}
#'    \item   \code{\link{getModelError}}
#'    \item   \code{\link{getNameResponse}}
#'    \item   \code{\link{getSigmaNames}}
#'    \item   \code{\link{IndividualFIMEvaluateVariance}}
#'    \item   \code{\link{PopulationFIMEvaluateVariance}}
#'    \item   \code{\link{setModelError<-}}
#'   }
#'}
#'
#'\item{Class \code{\link{SamplingConstraint}}}{
#'
#'   \itemize{
#'    \item   \code{\link{allowedContinuousSamplingTimes}}
#'    \item   \code{\link{allowedDiscretSamplingTimes}}
#'    \item   \code{\link{FixTimeValues}}
#'    \item   \code{\link{getallowedDiscretSamplingTimes}}
#'    \item   \code{\link{getfixedTimes}}
#'    \item   \code{\link{getnumberOfSamplingTimes}}
#'    \item   \code{\link{getOptimisability}}
#'    \item   \code{\link{getResponseName}}
#'    \item   \code{\link{isLessThanDelay}}
#'    \item   \code{\link{isTimeInBetweenBounds}}
#'    \item   \code{\link{numberOfSamplingTimesIsOptimisable}}
#'   }
#'}
#'
#'\item{Class \code{\link{SamplingTimes}}}{
#'
#'   \itemize{
#'    \item   \code{\link{getNameSampleTime}}
#'    \item   \code{\link{getSampleTime}}
#'    \item   \code{\link{setSampleTime}}
#'    \item   \code{\link{getNumberTime}}
#'    \item   \code{\link{getInitialTime}}
#'   }
#'}
#'
#'\item{Class \code{\link{StandardDistribution}}}
#'
#'\item{Class \code{\link{StatisticalModel}}}{
#'
#'   \itemize{
#'    \item   \code{\link{addResponse}}
#'    \item   \code{\link{addResponses}}
#'    \item   \code{\link{CalculatedResidualVariance}}
#'    \item   \code{\link{defineCorelation}}
#'    \item   \code{\link{defineModelEquations}}
#'    \item   \code{\link{defineParameter}}
#'    \item   \code{\link{defineParameters}}
#'    \item   \code{\link{Evaluate}}
#'    \item   \code{\link{getEquationsStatisticalModel}}
#'    \item   \code{\link{getErrorModelStandardErrors}}
#'    \item   \code{\link{getFixedEffectParameterNamesAndNumber}}
#'    \item   \code{\link{getModelParameters}}
#'    \item   \code{\link{getNotZeroRandomEffectParameterNames}}
#'    \item   \code{\link{getResponsesStatisticalModel}}
#'    \item   \code{\link{getStatisticalModelParameters}}
#'    \item   \code{\link{show}}
#'    \item   \code{\link{showErrorModelStandardErrors}}
#'   }
#'}
#'
#'\item{Class \code{\link{summaryPFIM}}}{
#'
#'   \itemize{
#'    \item   \code{\link{show}}
#'   }
#'}
#'
#'}

"_PACKAGE"






