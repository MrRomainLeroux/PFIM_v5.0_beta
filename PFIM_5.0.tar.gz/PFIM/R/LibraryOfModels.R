##################################################################################
#' Class for the library of models.
#'
#' @description
#' \code{LibraryOfModels} is an S4 class that implements the library of models, consisting
#' of two libraries of PK and PD models respectively.
#'
#' The PK library includes model with different administration routes (bolus, infusion, first-order absorption),
#' different number of compartments (from 1 to 3), and different types of eliminations (linear or Michaelis-Menten).
#' The PD model library, contains direct immediate models (e.g. Emax and Imax) with various baseline models,
#' and turnover response models. The PK/PD models, on the other hand, are obtained with combination of the models
#' from the PK and PD model libraries. Throught the use of the \code{LibraryOfModels} PFIM handles both analytical and ODE models and offers the possibility to the user to define his own models.
#'
#' @name LibraryOfModels-class
#' @aliases LibraryOfModels
#' @docType class
#' @exportClass LibraryOfModels
#'
#' @section Objects from the Class: \linkS4class{LibraryOfModels} objects are created by calls to \code{\link{LibraryOfModels}} and contain the following slots:
#' \describe{
#' \item{\code{nameLibraryOfModels}:}{A character string giving the name of the library of models.}
#' \item{\code{contentsLibraryOfModels}:}{A list of the PK, PD and PKPD models that are in the library of models.}
#'}
#'
#' @section Methods:
#' \describe{
#' \item{\code{getContentsLibraryOfModels(name="PFIMLibraryOfModels")}}{Get the content for the library of models named "PFIMLibraryOfModels".}
#' \item{\code{getModelNameList(PFIMLibraryOfModels)}}{Get the names of all the models for the library of models.}
#' \item{\code{getModel(nameModel)}}{Get the model nameModel.}
#' }
#'
#' @section Equations for the models in the library: The equations described below are the the pharmacokinetic and pharmacodynamic models implemented in the PFIM package and avalaible in the LibraryOfModels.
#' \describe{
#'
#' \item{1.}{{Pharmacokinetic models}}
#'
#' \item{1.1}{Models with linear elimination}
#'
#' \item{1.1.1}{One-compartment models}
#'
#' \item{1.1.1.1}{Intravenous bolus}
#'
#' \item{-}{single dose:  \code{Linear1BolusSingleDose_ClV}}
#'
#' \item{}{\deqn{C\left(t\right)=\frac{D}{V}e^{-k\left(t-t_{D}\right)}}}
#'
#' \item{-}{multiple doses: \code{Linear1BolusSingleDose_ClV}}
#'
#' \item{}{\deqn{C\left(t\right)=\sum^{n}_{i=1}\frac{D_{i}}{V}e^{-k\left(t-t_{D_{i}}\right)}}}
#'
#' \item{-}{steady state: \code{Linear1BolusSingleDose_ClVtau}}
#'
#' \item{}{\deqn{C(t)=\frac{D}{V}\frac{e^{-k(t-t_D)}}{1-e^{-k\tau}}}}
#'
#' \item{1.1.1.2}{Infusion}
#' \cr
#' \item{-}{single dose: \code{Linear1InfusionSingleDose_kVCl}}
#'
#' \item{}{\deqn{C\left(t\right)=
#' \begin{cases}
#' {\frac{D}{Tinf}\frac{1}{kV}\left(1-e^{-k\left(t-t_{D}\right)}\right)
#' \cr
#' \frac{D}{Tinf}\frac{1}{kV}\left(1-e^{-kTinf}\right)e^{-k\left(t-t_{D}-Tinf\right)}}
#' \end{cases}}}
#'
#' \item{-}{multiple doses: \code{Linear1InfusionSingleDose_kVCl}}
#'
#' \item{}{\deqn{C\left(t\right)=
#' \begin{cases}
#' {\sum^{n-1}_{i=1}\frac{D_{i}}{Tinf_{i}}\frac{1}{kV}\left(1-e^{-kTinf_{i}}\right)e^{-k\left(t-t_{D_{i}}-Tinf_i\right)}+\frac{D_{n}}{Tinf_{n}}\frac{1}{kV}\left(1-e^{-k\left(t-t_{D_{n}}\right)}\right)
#' {~if~t-t_{D_{n}}\leq Tinf_{n}}
#' \cr\cr\cr
#' \frac{D}{Tinf}\frac{1}{kV}\left(1-e^{-kTinf}\right)e^{-k\left(t-t_{D}-Tinf\right)}
#' {~if~not}}
#' \end{cases}}}
#'
#' \item{-}{steady state: \code{Linear1InfusionSteadyState_kVCltau}}
#'
#' \item{}{\deqn{C\left(t\right)=
#' \begin{cases}
#' {\frac{D}{Tinf}\frac{1}{kV}\left[\left(1-e^{-k(t-t_D)}\right)+e^{-k\tau}{\frac{\left(1-e^{-kTinf}\right)e^{-k\left(t-t_D-Tinf\right)}}{1-e^{-k\tau}}}\right]
#' {~if~t-t_{D}\leq Tinf}
#' \cr\cr\cr
#' \frac{D}{Tinf}\frac{1}{kV}\frac{\left(1-e^{-kTinf}\right)e^{-k\left(t-t_D-Tinf\right)}}{1-e^{-k\tau}}
#' {~if~not}}
#' \end{cases}}}
#' \cr
#' \item{1.1.1.3}{First order absorption}
#' \cr
#' \item{-}{single dose: \code{Linear1FirstOrderSingleDose_kaVCl}}
#'
#' \item{}{\deqn{C\left(t\right)=\sum^{n}_{i=1}\frac{D_{i}}{V}\frac{k_{a}}{k_{a}-k}\left(e^{-k\left(t-t_{D_{i}}\right)}-e^{-k_{a}\left(t-t_{D_{i}}\right)}\right)}}
#'
#' \item{-}{multiple doses: \code{Linear1FirstOrderSingleDose_kaVCl}}
#'
#' \item{}{\deqn{C\left(t\right)=\sum^{n}_{i=1}\frac{D_{i}}{V}\frac{k_{a}}{k_{a}-k}\left(e^{-k\left(t-t_{D_{i}}\right)}-e^{-k_{a}\left(t-t_{D_{i}}\right)}\right)}}
#'
#' \item{-}{steady state: \code{Linear1FirstOrderSteadyState_kaVCltau}}
#'
#' \item{}{\deqn{C\left(t\right)=\frac{D}{V}\frac{k_{a}}{k_{a}-k}\left(\frac{e^{-k(t-t_D)}}{1-e^{-k\tau}}-\frac{e^{-k_{a}(t-t_D)}}{1-e^{-k_a\tau}}\right)}}
#' }
#'
#' \describe{
#' \item{2.}{{Pharmacodynamic models}}
#' \item{2.1}{Immediate response models}
#' \item{2.1.1}{Drug action models}
#' \cr
#' \item{-}{linear model: \code{ImmediateDrugLinear_Alin}}
#' \item{}{\deqn{A\left(t\right)=A_{lin}C\left(t\right)}}
#'
#' \item{-}{quadratic model: \code{ImmediateDrugImaxQuadratic_Alin_Aquad}}
#' \item{}{\deqn{A\left(t\right)=A_{lin}C\left(t\right)+A_{quad}C\left(t\right)^{2}}}
#'
#' \item{-}{logarithmic model: \code{ImmediateDrugImaxLogarithmic_Alog}}
#' \item{}{\deqn{A\left(t\right)=A_{log}log(C\left(t\right))}}
#'
#' \item{-}{Emax model: \code{ImmediateDrugEmax_EmaxC50}}
#' \item{}{\deqn{A\left(t\right)=\frac{E_{max}C\left(t\right)}{C\left(t\right)+C_{50}}}}
#'
#' \item{-}{sigmoid model: \code{ImmediateDrugSigmoidEmax_EmaxC50gamma}}
#' \item{}{\deqn{A\left(t\right)=\frac{E_{max}C\left(t\right)^{\gamma}}{C\left(t\right)^{\gamma}+C_{50}^{\gamma}}}}
#'
#' \item{-}{Imax model: \code{ImmediateDrugImax_S0ImaxC50}}
#' \item{}{\deqn{A\left(t\right)=1-\frac{I_{max}C\left(t\right)}{C\left(t\right)+C_{50}}}}
#'
#' \item{-}{sigmoid Imax model: \code{ImmediateDrugImax_S0ImaxC50_gamma}}
#' \item{}{\deqn{A\left(t\right)=1-\frac{I_{max}C\left(t\right)^{\gamma}}{C\left(t\right)^{\gamma}+C_{50}^{\gamma}}}}
#'
#'#' \item{2.1.2}{constant baseline with no disease progression: \code{ImmediateBaselineConstant_S0}}
#' \item{}{\deqn{S\left(t\right)=S_{0}}}
#'
#' \item{-}{linear disease progression: \code{ImmediateBaselineLinear_S0kprog}}
#' \item{}{\deqn{S\left(t\right)=S_{0}+k_{prog}t}}
#'
#' \item{-}{exponential disease increase: \code{ImmediateBaselineExponentialincrease_S0kprog}}
#' \item{}{\deqn{S\left(t\right)=S_{0}e^{-k_{prog}t}}}
#'
#' \item{-}{exponential disease decrease: \code{ImmediateBaselineExponentialincrease_S0kprog}}
#' \item{}{\deqn{S\left(t\right)=S_{0}\left(1-e^{-k_{prog}t}\right)}}
#'
#' \item{2.2}{Turnover response models}
#' \item{2.2.1}{Models with impact on the input (Rin)}
#' \cr
#' \item{-}{Emax model: \code{TurnoverRinEmax_RinEmaxCC50koutE}}
#' \item{}{\deqn{\frac{dE}{dt}=R_{in}\left(1+\frac{E_{max}C}{C+C_{50}}\right)-k_{out}E}}
#'
#' \item{-}{sigmoid Emax model: \code{TurnoverRinSigmoidEmax_RinEmaxCC50koutE}}
#' \item{}{\deqn{\frac{dE}{dt}=R_{in}\left(1+\frac{E_{max}C^{\gamma}}{C^{\gamma}+C_{50}^{\gamma}}\right)-k_{out}E	}}
#' \cr
#' \item{-}{Imax model: \code{TurnoverRinImax_RinImaxCC50koutE}}
#' \item{}{\deqn{\frac{dE}{dt}=R_{in}\left(1-\frac{I_{max}C}{C+C_{50}}\right)-k_{out}E}}
#'
#' \item{-}{sigmoid Imax model: \code{TurnoverRinSigmoidImax_RinImaxCC50koutE}}
#' \item{}{\deqn{\frac{dE}{dt}=R_{in}\left(1-\frac{I_{max}C^{\gamma}}{C^{\gamma}+C_{50}^{\gamma}}\right)-k_{out}E	}}
#'
#' \item{-}{full Imax model: \code{TurnoverRinFullImax_RinCC50koutE}}
#' \item{}{\deqn{\frac{dE}{dt}=R_{in}\left(1-\frac{C}{C+C_{50}}\right)-k_{out}E	}}
#'
#' \item{-}{sigmoid full Imax model: \code{TurnoverRinSigmoidFullImax_RinCC50koutE}}
#' \item{}{\deqn{\frac{dE}{dt}=R_{in}\left(1-\frac{C^{\gamma}}{C^{\gamma}+C_{50}^{\gamma}}\right)-k_{out}E	}}
#'
#' \item{2.2.2}{Models with impact on the input (kout)}
#' \cr
#' \item{-}{Emax model : \code{TurnoverRinEmax_RinEmaxCC50koutE}}
#' \item{}{\deqn{\frac{dE}{dt}=R_{in}-k_{out}\left(1+\frac{E_{max}C}{C+C_{50}}\right)E}}
#'
#' \item{-}{sigmoid Emax model : \code{TurnoverkoutSigmoidEmax_RinEmaxCC50koutEgamma}}
#' \item{}{\deqn{	\frac{dE}{dt}=R_{in}-k_{out}\left(1+\frac{E_{max}C^{\gamma}}{C^{\gamma}+C_{50}^{\gamma}}\right)E}}
#'
#' \item{-}{Imax model: \code{TurnoverkoutImax_RinImaxCC50koutE}}
#' \item{}{\deqn{\frac{dE}{dt}=R_{in}-k_{out}\left(1-\frac{I_{max}C}{C+C_{50}}\right)E	}}
#'
#' \item{-}{sigmoid Imax model: \code{TurnoverkoutSigmoidImax_RinImaxCC50koutEgamma}}
#' \item{}{\deqn{\frac{dE}{dt}=R_{in}-k_{out}\left(1-\frac{I_{max}C^{\gamma}}{C^{\gamma}+C_{50}^{\gamma}}\right)E	}}
#'
#' \item{-}{full Imax model: \code{TurnoverkoutFullImax_RinCC50koutE}}
#' \item{}{\deqn{\frac{dE}{dt}=R_{in}-k_{out}\left(1-\frac{C}{C+C_{50}}\right)E	}}
#'
#' \item{-}{sigmoid full Imax model: \code{TurnoverkoutSigmoidFullImax_RinCC50koutE}}
#' \item{}{\deqn{\frac{dE}{dt}=R_{in}-k_{out}\left(1-\frac{C^{\gamma}}{C^{\gamma}+C_{50}^{\gamma}}\right)E}}
#' }
#'

LibraryOfModels <- setClass(
  Class ="LibraryOfModels",
  representation = representation(nameLibraryOfModels = "character",
                                  contentsLibraryOfModels = "list"),
  prototype = prototype(nameLibraryOfModels = character(0)))

# -------------------------------------------------------------------------------------------------------------------
#' Get the content of the \code{LibraryOfModels} object.
#' @name getContentsLibraryOfModels
#' @param object A \code{LibraryOfModels} object.
#' @return A list \code{contentsLibraryOfModels} giving the two lists that respectively corresponds to the two librairies of the PK and PD models contained in the \code{\link{LibraryOfModels}}.

setGeneric(
  "getContentsLibraryOfModels",
  function(object) {
    standardGeneric("getContentsLibraryOfModels")
  })

setMethod(
  "getContentsLibraryOfModels",
  signature("LibraryOfModels"),
  function(object){
    contentsLibraryOfModels = list()
    contentsLibraryOfModels <- object@contentsLibraryOfModels
    return(contentsLibraryOfModels)
  })

# -------------------------------------------------------------------------------------------------------------------
#' Add a \code{model} in the \code{LibraryOfModels} object.
#' @name addModel
#' @param object A \code{LibraryOfModels} object.
#' @param model The model to add in the library (PK, PD or PKPD model).
#' @return The \code{LibraryOfModels} object with the loaded library of models.

setGeneric(
  "addModel",
  function(object, model) {
    standardGeneric("addModel")
  })

setMethod(
  "addModel",
  signature("LibraryOfModels"),
  function(object, model){
    object@contentsLibraryOfModels <- append(object@contentsLibraryOfModels,model)
    return(object)
  })

# -------------------------------------------------------------------------------------------------------------------
#' Get the list of all the models in the \code{LibraryOfModels} object.
#' @name getModelNameList
#' @param object A \code{LibraryOfModels} object.
#' @return The list \code{ModelNameList} of the names of the PK, PD and PKPD models in the \code{LibraryOfModels} object.

setGeneric(
  "getModelNameList",
  function(object) {
    standardGeneric("getModelNameList")
  })

setMethod(
  "getModelNameList",
  signature("LibraryOfModels"),
  function(object){

    contentsLibraryOfModels = getContentsLibraryOfModels(object)

    listOfModel = lapply(contentsLibraryOfModels, slot, name = "nameModel")
    listClassModel = lapply(contentsLibraryOfModels,class)

    indexPDModels = which(listClassModel=="PDModel")
    indexPKModels = which(listClassModel=="PKModel")
    indexPKPDModels = which(listClassModel=="PKPDModel")

    pkModelsNameList = listOfModel[indexPKModels]
    pdModelsNameList = listOfModel[indexPDModels]
    pkpdModelsNameList = listOfModel[indexPKPDModels]

    ModelNameList = list(pkModelsNameList,pdModelsNameList,pkpdModelsNameList)

    names(ModelNameList) = c("pkModel","pdModel","pkpdModel")

    return(ModelNameList)

  })

# -------------------------------------------------------------------------------------------------------------------
#' Get a model of the \code{LibraryOfModels} object.
#' @name getModel
#' @param object A \code{LibraryOfModels} object.
#' @param ... The three-dots for passing one name or two names as arguments. One name to get a PK or PD model and two names for the PK and PD models of a PKPD model.
#' @return Return a \code{Model} object giving a PK or PD model.

setGeneric(
  "getModel",
  function(object, ...) {
    standardGeneric("getModel")
  })

setMethod(
  "getModel",
  signature("LibraryOfModels"),
  function(object, ...){

    listNames = list(...)
    listNames = unlist(listNames[!unlist(lapply(listNames, is.null))])

    if (length(listNames)==1){

      nameModel = listNames[[1]]

      contentsLibraryOfModels = getContentsLibraryOfModels(object)

      listOfModel = lapply(contentsLibraryOfModels, slot, name = "nameModel")
      indexNameModel = which(listOfModel==nameModel)

      if (length(indexNameModel)==0){

        print("Model not in the Library")

        return(Model())

      }

      return(contentsLibraryOfModels[[indexNameModel]])

    } else if (length(listNames)==2){

      modelOne = getModel(object, listNames[[1]])
      modelTwo = getModel(object, listNames[[2]])

      listModel = c(modelOne,modelTwo)

      indexPkModel = which((lapply(listModel, is, class = "PKModel"))==TRUE)
      indexPdModel = which((lapply(listModel, is, class = "PDModel"))==TRUE)

      namePKModel = listNames[indexPkModel]
      namePDModel = listNames[indexPdModel]

      return(getPKPDModel(object,namePKModel,namePDModel))
    }

    else

    {

      print("Too many names given in the function getModel.")
    }

  })

# -------------------------------------------------------------------------------------------------------------------

#' Get a PKPD model of the \code{LibraryOfModels} object.
#' @name getPKPDModel
#' @param object A \code{LibraryOfModels} object.
#' @param namePKModel A character string giving the name of the PK model.
#' @param namePDModel A character string giving the name of the PD model.
#' @return Return a \code{Model} giving the PKPD model consisting of the PK and PD models named namePKModel and namePDModel respectively.

setGeneric(
  "getPKPDModel",
  function(object,namePKModel,namePDModel) {
    standardGeneric("getPKPDModel")
  })

setMethod(
  "getPKPDModel",
  signature("LibraryOfModels"),

  function(object,namePKModel,namePDModel){

    # get the contents of the library of models
    contentsLibraryOfModels = getContentsLibraryOfModels(object)

    namesModel = sapply(contentsLibraryOfModels,getModelName)

    indexpkModel = which(namePKModel == namesModel)
    indexpdModel = which(namePDModel == namesModel)

    if (length(indexpkModel)==0) {
      print("Model PK not in the Library")
      return(Model())
    }

    else if (length(indexpdModel)==0) {
      print("Model PD not in the Library")
      return(Model())
    }

    else {

      pkModel = getModel(object, namesModel[[indexpkModel]])
      pdModel = getModel(object, namesModel[[indexpdModel]])

      # define the PKPD model
      output = PKPDModel(pkModel=pkModel,pdModel=pdModel)

      # get the equations of the PK and PD models
      equationsModelPK = getEquationsModel(pkModel)
      equationsModelPD = getEquationsModel(pdModel)

      # get the parameters of the PK and PD models
      parametersPKModel = getParameters(equationsModelPK)
      parametersPDModel = getParameters(equationsModelPD)
      allParameters = c(parametersPKModel,parametersPDModel)

      # set the parameters for the PKPD model
      output = setParametersModel(output,allParameters)

    }

    return(output)

  })

##########################################################################################################
# END Class "LibraryOfModels"
##########################################################################################################
