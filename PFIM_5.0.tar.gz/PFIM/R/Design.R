##########################################################################################################
##' Class "Design"
##'
##' @description The Class "Design" defines information concerning the parametrization of the designs.
#'
##' @name Design-class
##' @aliases Design
##' @docType class
##' @include Optimization.R
##' @include Fim.R
##' @exportClass Design
##'
#' @section Objects from the Class Design:
#' Objects form the Class \linkS4class{Design} can be created by calls of the form \code{Design(...)} where
#' (...) are the parameters for the \code{Design} objects.
#'
##'@section Slots for the \code{Design} objects:
##' \describe{
##' \item{\code{isOptimalDesign}:}{A Boolean for testing if the Design is optimal (isOptimalDesign=TRUE) or not.}
##' \item{\code{name}:}{A character string giving the name of the design - optional.}
##' \item{\code{total_size}:}{A numeric giving the total number of subjects in the design - optional.}
##' \item{\code{arms}:}{List of objects from the Class \linkS4class{Arm}.}
##' \item{\code{number_samples}:}{A numeric giving the constraint on the number of samples for one subject - optional.
##' Default to the set of possible number of sampling points present in the sampling windows
##' defining the different arms or the design spaces.}
##' \item{\code{arms}:}{A list of arm objects from the Class \linkS4class{Arm}.}
##' \item{\code{amountOfArm}:}{A numeric giving the number of arms in the study.}
##' \item{\code{optimizationResult}:}{An optimization object from the Class \linkS4class{Optimization} giving the results from the optimizsation process.}
##' \item{\code{fimOfDesign}:}{A character string giving the Fisher Information Matrix of the design (Population, Individual or Bayesian).}
##' }
##'
##########################################################################################################

Design <- setClass(
  Class = "Design",
  representation = representation(
    isOptimalDesign = "logical",
    name = "character",
    total_size = "numeric",
    number_samples  = "vector",
    arms = "list",                                           # List of objects from Arm class
    amountOfArm = "numeric",
    optimizationResult = "Optimization",
    fimOfDesign = "Fim",
    concentration = "list",
    sensitivityindices = "list",
    samplingTimesWithTauAndTinf = "list",
    samplingTinfTauForPlot = "list"
  ),
  prototype = prototype(
    isOptimalDesign = FALSE,
    name =  paste("Design_",  ceiling( runif(1) * 100000 ), sep="" ),
    total_size = 0,
    arms = list(),
    amountOfArm = 0,
    optimizationResult = Optimization(),
    fimOfDesign = Fim()
  )

)

# Initialize method
setMethod(
  f = "initialize",
  signature = "Design",
  definition = function (.Object, name, total_size, number_samples, amountOfArm, arms, fimOfDesign, total_cost,
                         cost_function, covariates, concentration, sensitivityindices, samplingTimesWithTauAndTinf, samplingTinfTauForPlot )
  {
    if(!missing(name))
      .Object@name<-name
    if(!missing(total_size))
      .Object@total_size<-total_size
    if(!missing(number_samples))
      .Object@number_samples<-number_samples
    if(!missing(arms))
      .Object@arms<-arms
    if(!missing(amountOfArm))
      .Object@amountOfArm<-amountOfArm
    if(!missing(fimOfDesign))
      .Object@fimOfDesign<-fimOfDesign
    if(!missing(total_cost))
      .Object@total_cost<-total_cost
    if(!missing(cost_function))
      .Object@cost_function<-cost_function
    if(!missing(covariates))
      .Object@covariates<-covariates

    if(!missing(concentration))
      .Object@concentration<-concentration

    if(!missing(sensitivityindices))
      .Object@sensitivityindices<-sensitivityindices

    if(!missing(samplingTimesWithTauAndTinf))
      .Object@samplingTimesWithTauAndTinf<-samplingTimesWithTauAndTinf

    if(!missing(samplingTinfTauForPlot))
      .Object@samplingTinfTauForPlot<-samplingTinfTauForPlot

    return (.Object )
  }
)

##########################################################################################################

#' Get the results of the optimization process
#'
#' @name getOptimizationResult
#' @param object An object \code{Design}
#' @return A \code{Optimization} object giving the resultsof the potimization process

setGeneric("getOptimizationResult",
           function(object)
           {
             standardGeneric("getOptimizationResult")
           }
)

setMethod("getOptimizationResult",
          "Design",
          function(object)
          {

            return(object@optimizationResult)
          }
)

##########################################################################################################

#' Modify an arm of a design
#'
#' @name modifyArm
#' @param object An object \code{Design}
#' @param name A character string giving the name of the \code{Arm} object to be modified in the \code{Design} object
#' @param arm An \code{Arm} object
#' @return The \code{Design} object with the modified arm

setGeneric("modifyArm",
           function(object, name, arm)
           {
             standardGeneric("modifyArm")
           }
)

setMethod("modifyArm",
          "Design",
          function(object, name, arm)
          {

            if ( name %in% names( object@arms ) )
            {
              object@arms[[ name ]] <- arm
            }
            return(object)
          }
)


##########################################################################################################

#' Get the name of the design
#'
#' @name getNameDesign
#' @param object An object \code{Design}
#' @return A character string \code{name} giving the name of design

setGeneric("getNameDesign",
           function(object)
           {
             standardGeneric("getNameDesign")
           }
)

setMethod("getNameDesign",
          "Design",
          function(object)
          {
            return(object@name)
          }
)

##########################################################################################################

#' Set the name of the design
#'
#' @name setNameDesign
#' @param object An object \code{Design}
#' @param name A character string \code{name} giving the new name of design
#' @return The \code{Design} object with its new name

setGeneric("setNameDesign",
           function(object, name)
           {
             standardGeneric("setNameDesign")
           }
)

setMethod("setNameDesign",
          "Design",
          function(object, name)
          {
            object@name = name
            return( object )

          }
)

##########################################################################################################

#' Get the total size of a design
#' @name getTotalSize
#' @param object An object \code{Design}
#' @return A numeric \code{total_size} giving the size of a design

setGeneric("getTotalSize",
           function(object)
           {
             standardGeneric("getTotalSize")
           }
)

setMethod("getTotalSize",
          "Design",
          function(object)
          {
            return(object@total_size)
          }
)

##########################################################################################################

#' Set the total size of a Design
#' @name setTotalSize<-
#' @param object An object \code{Design}
#' @param value A numeric giving the new value of the size of the design
#' @return The \code{Design} object with the new size

setGeneric("setTotalSize<-",
           function(object, value)
           {
             standardGeneric("setTotalSize<-")
           }
)

setReplaceMethod( f="setTotalSize",
                  signature="Design",
                  definition = function(object, value)
                  {
                    object@total_size <- value
                    validObject(object)
                    return(object)
                  }
)

##########################################################################################################

#' Get the number of sampled in a Design
#'
#' @name getNumberSamples
#' @param object An object \code{Design}
#' @return A numeric \code{number_samples} giving the number of sample of the design

setGeneric("getNumberSamples",
           function(object)
           {
             standardGeneric("getNumberSamples")
           }
)

setMethod("getNumberSamples",
          "Design",
          function(object)
          {
            return(object@number_samples)
          }
)

##########################################################################################################

#' Set the number of Sample in a Design
#'
#' @name setNumberSamples<-
#' @param object An object \code{Design}
#' @param value A numeric giving the new value of samples
#' @return The \code{Design} object with the new number of samples


setGeneric("setNumberSamples<-",
           function(object, value)
           {
             standardGeneric("setNumberSamples<-")
           }
)

setReplaceMethod( f="setNumberSamples",
                  signature="Design",
                  definition = function(object, value)
                  {
                    object@number_samples <- value
                    validObject(object)
                    return(object)
                  }
)

##########################################################################################################

#' Get the amount of arms in a Design
#'
#' @name getAmountOfArms
#' @param object An object \code{Design}
#' @return A numeric \code{amountOfArm} giving the number of arms in the design

setGeneric("getAmountOfArms",
           function(object)
           {
             standardGeneric("getAmountOfArms")
           }
)

setMethod("getAmountOfArms",
          "Design",
          function(object)
          {
            return(length(object@arms))
          }
)

##########################################################################################################

#' Set the amount of arms in a Design
#'
#' @name setAmountOfArms
#' @param object An object \code{Design}
#' @param value A numeric giving the new value of the amount of arms in the design
#' @return The \code{Design} object with the new vamue of amount of arms

setGeneric("setAmountOfArms",
           function(object, value)
           {
             standardGeneric("setAmountOfArms")
           }
)

setMethod(f="setAmountOfArms",
          signature="Design",
          definition = function(object, value)
          {
            object@amountOfArm <- value
            validObject(object)
            return(object)
          }
)

##########################################################################################################

#' Get the Fisher Information Matrix of a design
#'
#' @name getFimOfDesign
#' @param object An object \code{Design}
#' @return A \code{Fim} object giving the Fisher Information Matrix of a design

setGeneric("getFimOfDesign",
           function(object)
           {
             standardGeneric("getFimOfDesign")
           }
)

setMethod("getFimOfDesign",
          signature = "Design",
          definition = function(object)
          {
            return(object@fimOfDesign)
          }
)

##########################################################################################################

#' Get the arms of a design
#' @name getArms
#' @param object An object \code{Design}
#' @return A list \code{arms} of the arms of a design

setGeneric("getArms",
           function(object)
           {
             standardGeneric("getArms")
           }
)

setMethod("getArms",
          "Design",
          function(object)
          {
            return(object@arms)
          }
)

##########################################################################################################

#' Set the arms of a design
#'
#' @name setArms
#' @param object An object \code{Design}
#' @param value A \code{Arm} object
#' @return The design \code{Design} with the new arm

setGeneric("setArms",
           function(object, value)
           {
             standardGeneric("setArms")
           }
)


setMethod( f="setArms",
           signature="Design",
           definition = function(object, value)
           {
             for(arm in value){
               object@arms[[ getNameArm(arm) ]] <- arm
               object@total_size = object@total_size + getArmSize(arm)
               object@amountOfArm = object@amountOfArm + 1
             }
             validObject(object)
             return(object)
           }
)

##########################################################################################################

#' Add an arm to a design
#'
#' @name addArm
#' @param object An object \code{Design}
#' @param arm An \code{Arm} object
#' @return The \code{Design} object with the new arm

setGeneric("addArm",
           function(object, arm)
           {
             standardGeneric("addArm")
           }
)

setMethod( f="addArm",
           signature="Design",
           definition = function(object, arm)
           {
             if(length(object@arms[[ getNameArm( arm ) ]]) == 0)
             {
               object@arms[[ getNameArm( arm ) ]] <- arm
               object@total_size = object@total_size + getArmSize(arm)
               object@amountOfArm = object@amountOfArm + 1
             }
             else
               cat("You have already used this name for an arm.\n")

             validObject(object)
             return(object)
           })


##########################################################################################################

#' Add an arm to a design
#'
#' @name addArms
#' @param object An object \code{Design}
#' @param listOfArms A list \code{Arm} object
#' @return The \code{Design} object with the new arm

setGeneric("addArms",
           function(object, listOfArms)
           {
             standardGeneric("addArms")
           }
)

setMethod( f="addArms",
           signature="Design",
           definition = function(object, listOfArms)
           {
             for ( i in 1:length( listOfArms) ){

               arm = listOfArms[[i]]

               if(length(object@arms[[ getNameArm( arm ) ]]) == 0)
               {
                 object@arms[[ getNameArm( arm ) ]] <- arm
                 object@total_size = object@total_size + getArmSize(arm)
                 object@amountOfArm = object@amountOfArm + 1
               }
               else
                 cat("You have already used this name for an arm.\n")

               validObject(object)
             }
             return(object)
           })

##########################################################################################################

#' Evaluate the RSE for each design
#'
#' @name EvaluateRSEforEachDesign
#' @param object An object \code{Design}
#' @param statisticalModel \code{statisticalModel} object
#' @return A list giving the The RSE for each design and the name of the designs

setGeneric("EvaluateRSEforEachDesign",
           function(object,statisticalModel)
           {
             standardGeneric("EvaluateRSEforEachDesign")
           })

setMethod("EvaluateRSEforEachDesign",
          "Design",
          function(object,statisticalModel)
          {

            nameDesign = getNameDesign(object)
            fimOfDesign  = getFimOfDesign(object)
            mfisher = getMfisher( fimOfDesign )

            results = list()

            if (is(fimOfDesign,"PopulationFim")) {

              name_of_design = "Population FIM"

              SE = getSE(fimOfDesign)

              MyStatisticalModelParameters = getStatisticalModelParameters(statisticalModel)
              n = length(MyStatisticalModelParameters)

              mu = matrix(0.0,n,1)
              omega = matrix(0.0,n,1)
              sigma = list()

              for( k in 1:n){
                mu[k] = getMu(MyStatisticalModelParameters[[k]])
                omega[k] = getOmega(MyStatisticalModelParameters[[k]])
              }

              MyStatisticalModelResponses = getResponsesStatisticalModel(statisticalModel)

              for (k in 1 : length(MyStatisticalModelResponses)){
                sigma = append(sigma, getSigmaValues(slot(MyStatisticalModelResponses[[k]],"model_error")))
              }

              sigma = unlist(sigma)

              indexPositiveMu = which( mu != 0 )
              indexPositivesOmega = which( omega != 0 )
              indexPositiveSigma = which( sigma != 0 )

              mu = mu[ indexPositiveMu ]
              omega = omega[ indexPositivesOmega ]
              sigma = sigma[ indexPositiveSigma ]

              numberPositiveMu = length( indexPositiveMu )
              numberPositivesOmega  = length( indexPositivesOmega )
              numberPositiveSigma = length( indexPositiveSigma )

              SE_mu = SE[1:numberPositiveMu]
              SE_omega = SE[(numberPositiveMu+1):(numberPositiveMu+numberPositivesOmega)]
              SE_sigma = SE[(numberPositiveMu+numberPositivesOmega+1):(numberPositiveMu+numberPositivesOmega+numberPositiveSigma)]

              RSE_mu = data.frame(data.frame(matrix(ncol = 3, nrow = numberPositiveMu)))
              RSE_omega = data.frame(data.frame(matrix(ncol = 3, nrow = numberPositivesOmega)))
              RSE_sigma = data.frame(data.frame(matrix(ncol = 3, nrow = numberPositiveSigma)))

              colnames(RSE_mu) = c("Parameters","Values","RSE")
              colnames(RSE_omega) = c("Parameters","Values","RSE")
              colnames(RSE_sigma) = c("Parameters","Values","RSE")

              RSE_mu$Values = SE_mu / mu * 100
              RSE_omega$Values = SE_omega / omega * 100
              RSE_sigma$Values = SE_sigma / sigma * 100

              RSE_mu$RSE = "RSE~mu"
              RSE_omega$RSE = "RSE~omega^2"
              RSE_sigma$RSE = "RSE~sigma"

              names(SE_mu) = colnames(mfisher)[1:numberPositiveMu]
              names(SE_omega) = colnames(mfisher)[(numberPositiveMu+1):(numberPositiveMu+numberPositivesOmega)]
              names(SE_sigma) = colnames(mfisher)[(numberPositiveMu+numberPositivesOmega+1):(numberPositiveMu+numberPositivesOmega+numberPositiveSigma)]

              RSE_mu$Parameters = substring( names(SE_mu), 3)
              RSE_omega$Parameters = substring( names(SE_omega), 4)
              RSE_sigma$Parameters = substring( names(SE_sigma), 3)
              RSE_sigma$Parameters = gsub("_", "\n", RSE_sigma$Parameters)

              data_RSE_population = rbind(RSE_mu,RSE_omega,RSE_sigma)
              colnames(data_RSE_population) = c("Parameters","Values","RSE")

              return(list(data_RSE_population,name_of_design))

            }

            # plot RSE : Individual Fisher information matrix

            else if (is(fimOfDesign,"IndividualFim")){

              name_of_design = "Individual FIM"

              SE = getSE(fimOfDesign)

              MyStatisticalModelParameters = getStatisticalModelParameters( statisticalModel )
              n = length(MyStatisticalModelParameters)

              mu = matrix(0.0,n,1)
              sigma = list()

              for( k in 1:n){
                mu[k] = getMu(MyStatisticalModelParameters[[k]])
              }

              MyStatisticalModelResponses = getResponsesStatisticalModel( statisticalModel )

              for (k in 1 : length(MyStatisticalModelResponses)){
                sigma = append(sigma, getSigmaValues(slot(MyStatisticalModelResponses[[k]],"model_error")))
              }

              sigma = unlist(sigma)

              indexPositiveMu = which( mu != 0 )
              indexPositiveSigma = which( sigma != 0 )

              mu = mu[ indexPositiveMu ]
              sigma = sigma[ indexPositiveSigma ]

              numberPositiveMu = length( indexPositiveMu )
              numberPositiveSigma = length( indexPositiveSigma )

              SE_mu = SE[1:numberPositiveMu]
              SE_sigma = SE[(numberPositiveMu+1):(numberPositiveMu+numberPositiveSigma)]

              RSE_mu = data.frame(data.frame(matrix(ncol = 3, nrow = length(SE_mu))))
              RSE_sigma = data.frame(data.frame(matrix(ncol = 3, nrow = length(sigma))))

              colnames(RSE_mu) = c("Parameters","Values","RSE")
              colnames(RSE_sigma) = c("Parameters","Values","RSE")

              RSE_mu$Values = SE_mu / mu * 100
              RSE_sigma$Values = SE_sigma / sigma * 100

              RSE_mu$RSE = "RSE~mu"
              RSE_sigma$RSE = "RSE~sigma"

              names(SE_mu) = colnames(mfisher)[1:numberPositiveMu]
              names(SE_sigma) = colnames(mfisher)[(numberPositiveMu+1):(numberPositiveMu+numberPositiveSigma)]

              RSE_mu$Parameters = substring( names(SE_mu), 3)
              RSE_sigma$Parameters = substring( names(SE_sigma), 3)
              RSE_sigma$Parameters = gsub("_", "\n", RSE_sigma$Parameters)

              data_RSE_individual = rbind(RSE_mu,RSE_sigma)
              colnames(data_RSE_individual) = c("Parameters","Values","RSE")
              return(list(data_RSE_individual,name_of_design))


            }

          })

##########################################################################################################

#' Evaluate the SE for each design
#'
#' @name EvaluateSEforEachDesign
#' @param object An object \code{Design}
#' @param statisticalModel A \code{statisticalModel} object
#' @return A list giving the The SE for each design and the name of the designs

setGeneric("EvaluateSEforEachDesign",
           function(object,statisticalModel)
           {
             standardGeneric("EvaluateSEforEachDesign")
           })

setMethod("EvaluateSEforEachDesign",
          "Design",
          function(object,statisticalModel)
          {

            nameDesign = getNameDesign(object)
            fimOfDesign  = getFimOfDesign(object)
            mfisher = getMfisher( fimOfDesign )

            if (is(fimOfDesign,"PopulationFim")) {

              name_of_design = "Population FIM"

              SE = getSE(fimOfDesign)

              MyStatisticalModelParameters = getStatisticalModelParameters(statisticalModel)
              n = length(MyStatisticalModelParameters)

              mu = matrix(0.0,n,1)
              omega = matrix(0.0,n,1)
              sigma = list()

              for( k in 1:n){
                mu[k] = getMu(MyStatisticalModelParameters[[k]])
                omega[k] = getOmega(MyStatisticalModelParameters[[k]])
                omega[k] = omega[k]^2
              }

              MyStatisticalModelResponses = getResponsesStatisticalModel(statisticalModel)

              for (k in 1 : length(MyStatisticalModelResponses)){
                sigma = append(sigma, getSigmaValues(slot(MyStatisticalModelResponses[[k]],"model_error")))
              }

              sigma = unlist(sigma)

              indexPositiveMu = which( mu != 0 )
              indexPositivesOmega = which( omega != 0 )
              indexPositiveSigma = which( sigma != 0 )

              mu = mu[ indexPositiveMu ]
              omega = omega[ indexPositivesOmega ]
              sigma = sigma[ indexPositiveSigma ]

              numberPositiveMu = length( indexPositiveMu )
              numberPositivesOmega  = length( indexPositivesOmega )
              numberPositiveSigma = length( indexPositiveSigma )

              SE_mu = SE[1:numberPositiveMu]
              SE_omega = SE[(numberPositiveMu+1):(numberPositiveMu+numberPositivesOmega)]
              SE_sigma = SE[(numberPositiveMu+numberPositivesOmega+1):(numberPositiveMu+numberPositivesOmega+numberPositiveSigma)]

              RSE_mu = data.frame(data.frame(matrix(ncol = 3, nrow = length(SE_mu))))
              RSE_omega = data.frame(data.frame(matrix(ncol = 3, nrow = length(SE_omega))))
              RSE_sigma = data.frame(data.frame(matrix(ncol = 3, nrow = length(sigma))))

              colnames(RSE_mu) = c("Parameters","Values","SE")
              colnames(RSE_omega) = c("Parameters","Values","SE")
              colnames(RSE_sigma) = c("Parameters","Values","SE")

              RSE_mu$Values = SE_mu
              RSE_omega$Values = SE_omega
              RSE_sigma$Values = SE_sigma

              RSE_mu$SE = "SE~mu"
              RSE_omega$SE = "SE~omega^2"
              RSE_sigma$SE = "SE~sigma"

              names(SE_mu) = colnames(mfisher)[1:numberPositiveMu]
              names(SE_omega) = colnames(mfisher)[(numberPositiveMu+1):(numberPositiveMu+numberPositivesOmega)]
              names(SE_sigma) = colnames(mfisher)[(numberPositiveMu+numberPositivesOmega+1):(numberPositiveMu+numberPositivesOmega+numberPositiveSigma)]

              RSE_mu$Parameters = substring( names(SE_mu), 3)
              RSE_omega$Parameters = substring( names(SE_omega), 4)
              RSE_sigma$Parameters = substring( names(SE_sigma), 3)
              RSE_sigma$Parameters = gsub("_", "\n", RSE_sigma$Parameters)

              data_RSE_population = rbind(RSE_mu,RSE_omega,RSE_sigma)
              colnames(data_RSE_population) = c("Parameters","Values","SE")
              return(list(data_RSE_population,name_of_design))

            }

            # plot SE : Individual Fisher information matrix

            else if (is(fimOfDesign,"IndividualFim")){

              name_of_design = "Individual FIM"

              SE = getSE(fimOfDesign)

              MyStatisticalModelParameters = getStatisticalModelParameters(statisticalModel)
              n = length(MyStatisticalModelParameters)

              mu = matrix(0.0,n,1)
              sigma = list()

              SE_mu = SE[1:n]
              SE_sigma = SE[(n+1):length(SE)]

              RSE_mu = data.frame(data.frame(matrix(ncol = 3, nrow = length(SE_mu))))

              for( k in 1:n){
                mu[k] = getMu(MyStatisticalModelParameters[[k]])
              }

              MyStatisticalModelResponses = getResponsesStatisticalModel(statisticalModel)

              for (k in 1 : length(MyStatisticalModelResponses)){
                sigma = append(sigma, getSigmaValues(slot(MyStatisticalModelResponses[[k]],"model_error")))
              }

              sigma = unlist(sigma)

              RSE_sigma = data.frame(data.frame(matrix(ncol = 3, nrow = length(sigma))))

              colnames(RSE_mu) = c("Parameters","Values","SE")
              colnames(RSE_sigma) = c("Parameters","Values","SE")

              RSE_mu$Values = SE_mu
              RSE_sigma$Values = SE_sigma

              RSE_mu$SE = "SE~mu"
              RSE_sigma$SE = "SE~sigma"

              RSE_mu$Parameters = substring( names(SE_mu), 3)
              RSE_sigma$Parameters = substring( names(SE_sigma), 3)
              RSE_sigma$Parameters = gsub("_", "\n", RSE_sigma$Parameters)

              data_RSE_individual = rbind(RSE_mu,RSE_sigma)
              colnames(data_RSE_individual) = c("Parameters","Values","SE")
              return(list(data_RSE_individual,name_of_design))

            }
          })

##########################################################################################################

#' Evaluate Design for each arm
#'
#' @name EvaluateDesignForEachArm
#' @param object An object \code{Design}
#' @param statistical_model A \code{statisticalModel} object
#' @param fim A \code{fim} object
#' @return The object \code{Design} evaluated for each of its arm

setGeneric("EvaluateDesignForEachArm",
           function(object, statistical_model, fim )
           {
             standardGeneric("EvaluateDesignForEachArm")
           }
)

setMethod(f="EvaluateDesignForEachArm",
          signature=  "Design",
          definition=function(object, statistical_model, fim )
          {
            MF_i_total = NA
            first = T
            if (length(object@arms)==0) { }
            else
            {
              for (arm in object@arms)
              {
                results = EvaluateStatisticalModel( arm, statistical_model, fim )

                nameArm = getNameArm( arm )

                object@concentration[[ nameArm ]] = results$concentrationModel
                object@sensitivityindices[[ nameArm ]] = results$sensitivityIndicesModel
                object@samplingTimesWithTauAndTinf[[ nameArm ]] = results$samplingTimesWithTauAndTinfModel
                object@samplingTinfTauForPlot[[ nameArm ]] = results$samplingTinfTauForPlot

                resultFIM = results$resultFim

                MF_i = getMfisher( resultFIM )

                if ( first )
                {
                  first = F
                  MF_i_total = MF_i
                }
                else
                  MF_i_total = MF_i_total + MF_i
              }
            }

            if(object@isOptimalDesign)
              fim@isOptimizationResult <- TRUE

            resultFIM <- `setMfisher<-`( resultFIM, MF_i_total )

            object@fimOfDesign <- resultFIM

            return( object )
          }
)


##########################################################################################################

#' Show the data of an arm for a design
#'
#' @name showArmData
#' @rdname showArmData
#' @aliases showArmData
#' @param object An object \code{Design}
#' @return Return a character string giving the data summary of an arm for a design

setGeneric("showArmData",
           function(object)
           {
             standardGeneric("showArmData")
           }
)

setMethod(f = "showArmData",
          "Design",
          function(object)
          {
            armData = summaryArmData(object)
            print(armData)
            cat("\n Total size of design : ", getTotalSize(object),"\n")
          }
)


##########################################################################################################

#' Gives a summary of all the parameters of an arm for a design.
#'
#' @name summaryArmData
#' @param object An object \code{Design}
#' @return Display a summary of all the parameters of the arms for a design

setGeneric("summaryArmData",
           function(object)
           {
             standardGeneric("summaryArmData")
           }
)

setMethod("summaryArmData",
          "Design",
          function(object)
          {

            armData = data.frame()

            for(arm in object@arms)
            {

              samplings = getSamplings(arm)
              namesSamplings = names(samplings)

              for ( nameSampling in namesSamplings )
              {

                sampling = samplings[[nameSampling]]

                admins = getAdministration(arm)

                for(admin in admins)
                {

                  sampleTime = getSampleTime(sampling)

                  sampleTime = round( sampleTime, 2 )

                  armLine2 = c(getNameArm(arm),
                               nameSampling,
                               getTimeDose(admin),
                               getAmountDose(admin),
                               paste0( "(", toString(sampleTime), ")"),getArmSize(arm))

                  armData = rbind( armData, armLine2, stringsAsFactors = FALSE )

                }}}

            cnames <- c( "Arm_name", " Response", "Time_dose", "Amount_dose" ,"Sampling_times", "Subjects")

            colnames(armData) =  cnames

            return(armData)
          })

##########################################################################################################

#' Show a design
#'
#' @rdname show
#' @param object An object \code{Design}
#' @return Return the FIM of the design and the data summary of the arm in the design

setMethod(f = "show",
          signature = "Design",
          definition = function(object)
          {
            if(length(object@arms)>0)
            {
              cat("\n\n**************************** ",object@name," ******************************* \n")

              showArmData(object)

            }
          }
)

##########################################################################################################

#' summary
#'
#' @rdname summary
#' @param object An object \code{Design}
#' @return Return a list giving the name, the number of individuals, the total size of the design, the
#' the summary of all the parameters of the arms for a design and the amount of arm in the design

setMethod("summary",
          "Design",
          function(object)
          {
            return(list(name = object@name, numberOfIndividuals = object@total_size,
                        arms = summaryArmData(object), amountOfArms = object@amountOfArm))
          }

)

##########################################################################################################
# END Class "Design"
##########################################################################################################







