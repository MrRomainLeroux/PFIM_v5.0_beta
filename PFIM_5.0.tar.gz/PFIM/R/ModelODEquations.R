##################################################################################
#' Class "ModelODEquations" representing the equations of an ODE model
#'
#' @description
#' A class storing information concerning the equations for the ODE models in the \code{LibraryOfModels}.
#'
#' @name ModelODEquations-class
#' @aliases ModelODEquations
#' @docType class
#' @include Constraint.R
#' @exportClass ModelEquations
#'
#' @section Objects from the Class \linkS4class{ModelODEquations}: Model objects are typically created by calls to \code{ModelODEquations} and contain the following slots:
#'
#' \describe{
#' \item{\code{derivatives}:}{A list of expression giving the the derivatives of the model.}
#' \item{\code{ODEFunction}:}{A lsoda template for the ODEFunction.}
#' \item{\code{ODEHessianFunction}:}{ lsoda template for the ODEHessianFunction function.}
#' }

ModelODEquations <- setClass(Class = "ModelODEquations",
                             contains = "ModelEquations",
                             representation = representation
                             (
                               derivatives = "list",
                               ODEFunction = "function",
                               ODEHessianFunction = "function"
                             )
)

# ODETemplateFunction for the ode models
ODETemplateFunction = function( t, y, p ) {}

# ODEHessianTemplateFunction for the ode models
ODEHessianTemplateFunction = function( p ) {}

setMethod(
  f="initialize",
  signature="ModelODEquations",
  definition= function (.Object, responsesEquations, derivatives )
  {
    .Object = callNextMethod(.Object, responsesEquations )
    .Object@derivatives = derivatives

    return ( .Object )
  }
)

#' Get the derivatives of a \code{ModelODEquations} object
#' @name getDerivatives
#' @param object \code{ModelODEquations} object
#' @return A list of expression \code{derivatives} giving the derivatives of a \code{ModelODEquations} object

setGeneric("getDerivatives",
           function(object)
           {
             standardGeneric("getDerivatives")
           }
)
setMethod("getDerivatives",
          "ModelODEquations",
          function(object)
          {
            return(object@derivatives)
          }
)

#' Evaluate the derivatives of a \code{ModelODEquations} object
#' @name EvaluateDerivatives
#' @param .Object A \code{ModelODEquations} object
#' @param times A numeric vector for the times
#' @param cond_init A list of the initial condition
#' @param model_parameters A vector of character string of the model parameters
#' @param compute_C_trough A boolean compute_C_trough
#' @param responseIndice A numeric giving the indice of the response of the \code{ModelODEquations} object
#' @param doseIndice A numeric doseIndice
#' @param equation An expression equation
#' @param administrations A list of \code{Administration} objects
#' @param solverLsodaOptions A vector of for solverLsodaOptions
#' @return A list of expression giving the derivatives of a \code{ModelODEquations} object

setGeneric("EvaluateDerivatives",
           function( .Object, times, cond_init, model_parameters, compute_C_trough, responseIndice, doseIndice, equation, administrations, solverLsodaOptions  )
           {
             standardGeneric("EvaluateDerivatives")
           }
)

#' Evaluate the derivatives of a \code{ModelODEquations} object
#' @name EvaluateDerivativesOLD
#' @param .Object A \code{ModelODEquations} object
#' @param times A vector of the times
#' @param cond_init A list of the initial condition
#' @param model_parameters A vector of character string of the model parameters.
#' @param compute_C_trough A boolean compute_C_trough
#' @param responseIndice A numeric giving the indice of the response of the \code{ModelODEquations} object
#' @param doseIndice A numeric doseIndice
#' @param equation An expression equation
#' @param administrations The \code{Administration} object
#' @param solverLsodaOptions A vector of for solverLsodaOptions
#' @return A list of expression giving the derivatives of a \code{ModelODEquations} object
#'
setGeneric("EvaluateDerivativesOLD",
           function( .Object, times, cond_init, model_parameters, compute_C_trough, c_trough, responseIndice, doseIndice, equation, administrations, solverLsodaOptions  )
           {
             standardGeneric("EvaluateDerivativesOLD")
           }
)

setMethod(f = "EvaluateDerivativesOLD",
          signature="ModelODEquations",
          definition= function (.Object, times, cond_init, model_parameters, compute_C_trough, c_trough, responseIndice, doseIndice, equation, administrations, solverLsodaOptions  )
          {
            rtol = solverLsodaOptions$rtol
            atol = solverLsodaOptions$atol
            hmax = solverLsodaOptions$hmax

            dynamicFunction="{ "
            hessianDynamicFunction="{ "
            derivBody = ""
            eqBody = ""
            params = "c( "

            i = 1

            for (parameter in model_parameters)
            {
              parameterName = getNameModelParameter( parameter )
              dynamicFunction = paste0( dynamicFunction, parameterName, "=p[", i, "] ; " )
              hessianDynamicFunction = paste0( hessianDynamicFunction, parameterName, "=p[", i, "] ; " )
              params = paste0( params, parameterName )
              if ( i < length( model_parameters ) )
              {
                params = paste0( params, ", " )
              }
              i = i + 1
            }

            params = paste0( params, " )" )

            for(administration in administrations)
            {
              outcome = getNameAdministration( administration )

              dose_resp = paste0( "dose_", outcome)
              doses = getAmountDose( administration )
              dose = doses[doseIndice]

              hessianDynamicFunction = paste0( hessianDynamicFunction, dose_resp ," = ", dose, " ; " )
              dynamicFunction = paste0( dynamicFunction, dose_resp, "=", dose, " ; " )

              i = i + 1
            }

            hessianDynamicFunction = unique(hessianDynamicFunction)
            dynamicFunction = unique(dynamicFunction)

            # sampling times
            numberOfVariables = length( cond_init )

            hessianDynamicFunction = paste( hessianDynamicFunction, "samplingTimes=c( ",
                                            paste( c( times[1], ',' , times[2]), collapse="") ," ) ;
                                            Ctrough = tail(p, ", numberOfVariables, " ) ; initialConditions=c( " , collapse="")

            # cond_initial and its index
            if ( length( cond_init ) == 0 )
              cat(" Warning : the initial conditions are not specified.")

            i = 1

            ## no Ctrough in cond_initial
            for( cond_initial in cond_init )
            {
              if ( i > 1 )
                hessianDynamicFunction = paste0( hessianDynamicFunction, "," )
              dynamicFunction = paste0( dynamicFunction, paste0("C", i) , "=y[", i , "] ; ")

              hessianDynamicFunction = paste0( hessianDynamicFunction, cond_initial, " + Ctrough[ ", i, " ] " )

              i = i + 1
            }

            # params and responseIndice
            hessianDynamicFunction = paste0(
              hessianDynamicFunction, " ) ;
               ls = lsoda( y=initialConditions, times=samplingTimes, ODEFunction,","rtol=",rtol,",","atol=",atol,",","hmax=",",", params, " ) ;
                 return( ls[2 , ", 1 + length( cond_init ) + responseIndice," ] ) }" )

            i = 1

            for( deriv in .Object@derivatives )
            {
              dynamicFunction = paste0( dynamicFunction, "dy", i, "=eval(expression(", deparse1(deriv[[1]]), ")) ; " )

              if ( i > 1 )
                derivBody = paste0( derivBody, "," )

              derivBody = paste0( derivBody, "dy", i )
              i = i + 1
            }

            i = 1

            for( eq in .Object@equations )
            {
              dynamicFunction = paste0( dynamicFunction, "Resp", i, "=eval(expression(", deparse1(eq[[1]]), ")) ; " )

              if ( i > 1 )
                eqBody = paste0( eqBody, "," )
              eqBody = paste0( eqBody, "Resp", i )
              i = i + 1
            }

            dynamicFunction = paste0( dynamicFunction, "return( list( c(", derivBody, " ), c(", eqBody ,") ) ) ; " )

            dynamicFunction = paste0( dynamicFunction, "} " )

            body( ODETemplateFunction ) = parse( text = dynamicFunction )
            .Object@ODEFunction = ODETemplateFunction

            ### Compute Hessian values
            body( ODEHessianTemplateFunction ) = parse( text = hessianDynamicFunction )
            .Object@ODEHessianFunction = ODEHessianTemplateFunction

            return ( .Object )
          }
)

##########################################################################################################
# END Class "ModelODEquations"
##########################################################################################################

