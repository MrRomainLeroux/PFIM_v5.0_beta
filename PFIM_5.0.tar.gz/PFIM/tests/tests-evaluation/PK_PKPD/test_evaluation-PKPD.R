options(warn = -1)
source("'../../init.R")

library(nlme)
library(Deriv)
library(Matrix)
library(ggplot2)
library(deSolve)
library(Rcpp)
library(gtable)
library(grid)
library(testthat)
library(pracma)

#########################################################################

# Evaluation of PKPD models
# The PKPD models are from the library of model PFIMLibraryOfModels

#########################################################################

# PK analytic & PD analytic

# context("Model PKPD : PK Linear1FirstOrderSingleDose_kaVCl & PD ImmediateDrugImaxConstant_S0ImaxC50")
#
# test_that("", {

### Create PFIM project
MyProject<-PFIM(name = "Test PFIM")

### Create the statistical model
MyStatisticalModel<-StatisticalModel()

### Create PKPD model
MyPKPDModel = getModel(PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl", "ImmediateDrugImax_S0ImaxC50")

### Assign the equations to the statistical model
MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyPKPDModel)

### Set mu and omega for each parameter
pV = ModelParameter( "V", mu = 8,
                     omega = sqrt( 0.020 ),
                     distribution = LogNormalDistribution() )

pCl = ModelParameter( "Cl", mu = 0.13,
                      omega = sqrt( 0.06 ),
                      distribution = LogNormalDistribution() )

pS0 = ModelParameter( "S0", mu = 100,
                      omega = sqrt( 0.1 ),
                      distribution = LogNormalDistribution() )

pC50 = ModelParameter( "C50", mu = 0.17,
                       omega = sqrt(0.7),
                       distribution = LogNormalDistribution() )

pka = ModelParameter( "ka", mu = 1.6,
                      omega = sqrt( 0.1 ),
                      distribution = LogNormalDistribution() )

pImax = ModelParameter( "Imax", mu = 0.73,
                        omega = sqrt(0.3),
                        distribution = LogNormalDistribution() )

### Assign the parameters to the statistical model
MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )
MyStatisticalModel = defineParameter( MyStatisticalModel, pC50 )
MyStatisticalModel = defineParameter( MyStatisticalModel, pS0 )
MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
MyStatisticalModel = defineParameter( MyStatisticalModel, pImax )

### Create and add the responses to the statistical model
MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )
MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPD", Constant( sigma_inter = 2 ) ) )

### Finaly assign the statistical model to the project
MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

### Create a design
MyDesign<- Design()

### For each arm create and add the sampling times for each response
brasTest <- Arm( name="Bras test", arm_size = 32 )

brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0, 2, 3, 8, 12, 24, 36, 72, 120, 144 ) ) )
brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPD", sample_time = c( 0, 4, 8, 12, 24, 36, 72, 100, 120, 144 ) ) )

brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c( 100 ) ) )
brasTest <- addAdministration( brasTest, Administration( outcome = "RespPD", time_dose = c(0), amount_dose = c( 100 ) ) )

### Add the arm to the design
MyDesign <- addArm( MyDesign, brasTest )

### Add the design to the project
MyProject <- addDesign( MyProject, MyDesign )

### Evaluate the Fisher Information Matrix for the IndividualFIM
MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

### Evaluate the Fisher Information Matrix for the PopulationFIM
MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

# Check the consitency of FIM Ind and Pop with the value of their determinant
matrixFisherIndividualFIM = getFim(MyEvaluationInd)
matrixFisherPopulationFIM = getFim(MyEvaluationPop)

detIndividualFim = det(matrixFisherIndividualFIM)
detPopulationFim = det(matrixFisherPopulationFIM)

valueDetIndividualFim = 8.632751e+14

print( c(detIndividualFim, valueDetIndividualFim ))
# tol = 1e-6
#
# expect_equal(detIndividualFim,valueDetIndividualFim, tol)
#
# }) # end test


############################################################################################################################

# PK Infusion analytic & PD analytic
#
# context("Model PKPD : PK Linear1InfusionSingleDose_kVCl & PD ImmediateDrugLinear_Alin")
#
# test_that("", {

### Create PFIM project
MyProject<-PFIM(name = "Test PFIM")

### Create the statistical model
MyStatisticalModel<-StatisticalModel()

### Create PKPD model
MyPKPDModel = getModel(PFIMLibraryOfModels, "Linear1InfusionSingleDose_kVCl", "ImmediateDrugLinear_Alin")

### Assign the equations to the statistical model
MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyPKPDModel)

### Set mu and omega for each parameter
pV = ModelParameter( "V", mu = 3.5,
                     omega = sqrt( 0.09 ),
                     distribution = LogNormalDistribution() )

pCl = ModelParameter( "Cl", mu = 2,
                      omega = sqrt( 0.09 ),
                      distribution = LogNormalDistribution() )

pAlin = ModelParameter( "Alin", mu = 10,
                        omega = sqrt( 0.5 ),
                        distribution = LogNormalDistribution() )

### Assign the parameters to the statistical model
MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )
MyStatisticalModel = defineParameter( MyStatisticalModel, pAlin )

### Create and add the responses to the statistical model
MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )
MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPD", Constant( sigma_inter = 0.8 ) ) )

### Finaly assign the statistical model to the project
MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

### Create a design
MyDesign<- Design()

### For each arm create and add the sampling times for each response
brasTest <- Arm( name="Bras test", arm_size = 40 )
brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0, 1,2,5,7,8, 10,12,14, 15, 16, 20, 21, 30) ) )
brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPD", sample_time = c(0, 2, 10, 12, 14, 20, 30)  ) )

brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2,2,3,3), time_dose = c(0,12,24,36) , amount_dose = c(30) ) )

### Add the arm to the design
MyDesign <- addArm( MyDesign, brasTest )

### Add the design to the project
MyProject <- addDesign( MyProject, MyDesign )

### Evaluate the Fisher Information Matrix for the IndividualFIM
MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

### Evaluate the Fisher Information Matrix for the PopulationFIM
MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

# Check the consitency of FIM Ind and Pop with the value of their determinant
matrixFisherIndividualFIM = getFim( MyEvaluationInd )
matrixFisherPopulationFIM = getFim( MyEvaluationPop )

detIndividualFim = det( matrixFisherIndividualFIM )
detPopulationFim = det( matrixFisherPopulationFIM )

valueDetIndividualFim = 5.675546e+12
valueDetPopulationFim = 7.249833e+23

print( c( detPopulationFim, valueDetPopulationFim ) )

# tol = 1e-6
#
# expect_equal(detIndividualFim,valueDetIndividualFim, tol)
# expect_equal(detPopulationFim,valueDetPopulationFim, tol)
#
# })

############################################################################################################################

# context("Model PKPD : PK Linear1FirstOrderSingleDose_kaVCl & PD TurnoverRinFullImax_RinCC50koutE")
#
# test_that("", {

MyProject <- PFIM(name = "Test PFIM")

### Create the ODE model
MyModel <- ODEStatisticalModel()

MyPKPDModel = getModel( PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl", "TurnoverRinFullImax_RinCC50koutE" )

### Assign the equations to the statistical model
MyModel = defineModelEquations( MyModel, MyPKPDModel )

### Define the variables of the ode model
vC1 <- ModelVariable( "C1" )
vC2 <- ModelVariable( "C2" )

MyModel <- defineVariable( MyModel, vC1 )
MyModel <- defineVariable( MyModel, vC2 )

### Set fixed effects (mu), standard deviation of random effects (omega) and distribution of each parameter
pka <- ModelParameter( "ka", mu = 1.6,
                       omega = sqrt( 0.7 ),
                       distribution = LogNormalDistribution() )

pV <- ModelParameter( "V", mu = 8,
                      omega = sqrt( 0.02 ),
                      distribution = LogNormalDistribution() )

pCl <- ModelParameter( "Cl", mu = 0.13,
                       omega = sqrt( 0.06 ),
                       distribution = LogNormalDistribution() )

pRin <- ModelParameter( "Rin", mu = 5.4,
                        omega = sqrt( 0.2 ),
                        distribution = LogNormalDistribution() )

pkout <- ModelParameter( "kout", mu = 0.06,
                         omega = sqrt( 0.02 ),
                         distribution = LogNormalDistribution() )

pC50 <- ModelParameter( "C50", mu = 1.2,
                        omega = sqrt( 0.01 ),
                        distribution = LogNormalDistribution() )

### Assign the parameters to the statistical model
MyModel <- defineParameter( MyModel, pka )
MyModel <- defineParameter( MyModel, pV )
MyModel <- defineParameter( MyModel, pCl )
MyModel <- defineParameter( MyModel, pRin )
MyModel <- defineParameter( MyModel, pkout )
MyModel <- defineParameter( MyModel, pC50 )

### Error model (standard deviations)
MyModel <- addResponse( MyModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )
MyModel <- addResponse( MyModel, Response( "RespPD", Constant( sigma_inter = 4 ) ) )

### Assign the model to the project
MyProject <- defineStatisticalModel( MyProject, MyModel )

### Create a design
MyDesign<- Design()

### For each arm create and add the sampling times for each response
arm1 <- Arm( name="Bras test", arm_size = 32, cond_init=list( "C1"=0, "C2"= 90 ))

arm1 <- addSampling( arm1, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120) , initialTime = 0 ) )
arm1 <- addSampling( arm1, SamplingTimes( outcome = "RespPD", sample_time = c(0, 24, 36, 48, 72, 96, 120, 144), initialTime = 0 ) )

### Add administration
arm1 <- addAdministration( arm1, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

### Add the arm to the design
MyDesign <- addArm( MyDesign, arm1 )

### Add the design to the project
MyProject <- addDesign( MyProject, MyDesign )

### Evaluate the PopulationFIM
MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

matrixFisherPopulationFIM = getFim(MyEvaluationPop)
detPopulationFim = det(matrixFisherPopulationFIM)

valueDetPopulationFim = 3.627313e+40

print( c( detPopulationFim, valueDetPopulationFim ) )

# tol = 1e-6
# expect_equal(detPopulationFim,valueDetPopulationFim, tol)

#})

###########################################################################################
# END CODE
###########################################################################################





