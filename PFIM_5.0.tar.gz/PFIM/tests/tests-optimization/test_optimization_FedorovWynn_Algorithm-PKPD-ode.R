options(warn=-1)
library(nlme)
library(Deriv)
library(Matrix)
library(ggplot2)
library(deSolve)
library(Rcpp)
library(gtable)
library(grid)

########################################################################################

# Optimisation

# Fedorov-Wynn algorithm

########################################################################################

### Create PFIM project

MyProject<-PFIMProject(name = "Test PFIM")
MyStatisticalModel <- ODEStatisticalModel()

### Create a list of model equations
MyModelEquations <- ModelODEquations( list("RespPK" = expression( C1 ),
                                           "RespPD" = expression( C2 ) ) ,

                                      list("Deriv_C1" = expression( dose_RespPK / ( V ) - Vm * C1/(km + C1) ) ,
                                           "Deriv_C2" = expression(Rin * (1-(Imax*C1)/(C1+C50))-kout*C2 ) ) )

### Assign the equations to the model
MyStatisticalModel <- defineModelEquations( MyStatisticalModel, MyModelEquations )

### Define the variables of the ode model
vC1 <- ModelVariable( "C1" )
vC2 <- ModelVariable( "C2" )

MyStatisticalModel <- defineVariable( MyStatisticalModel, vC1 )
MyStatisticalModel <- defineVariable( MyStatisticalModel, vC2 )

#### Set mu and omega for each parameter

pV = ModelParameter( "V", mu = 12.2,
                     omega = sqrt( 0.25 ),
                     distribution = LogNormalDistribution() )

pVm = ModelParameter( "Vm", mu = 0.082,
                      omega = sqrt( 0.25 ),
                      distribution = LogNormalDistribution() )

pkm = ModelParameter( "km", mu = 0.37,
                      omega = sqrt( 0 ),
                      distribution = LogNormalDistribution() )

pImax = ModelParameter( "Imax", mu = 1.0,
                        omega = sqrt( 0.0 ),
                        distribution = LogNormalDistribution() )

pRin = ModelParameter( "Rin", mu = 5.4,
                       omega = sqrt( 0.2 ),
                       distribution = LogNormalDistribution() )

pkout = ModelParameter( "kout", mu = 0.06,
                        omega = sqrt( 0.02 ),
                        distribution = LogNormalDistribution() )

pC50 = ModelParameter( "C50", mu = 1.2,
                       omega = sqrt( 0.01 ),
                       distribution = LogNormalDistribution() )


### Assign the parameters to the statistical model
MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
MyStatisticalModel = defineParameter( MyStatisticalModel, pVm )
MyStatisticalModel = defineParameter( MyStatisticalModel, pkm )
MyStatisticalModel = defineParameter( MyStatisticalModel, pImax )
MyStatisticalModel = defineParameter( MyStatisticalModel, pRin )
MyStatisticalModel = defineParameter( MyStatisticalModel, pkout )
MyStatisticalModel = defineParameter( MyStatisticalModel, pC50 )


### Create and add the responses to the statistical model
MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Proportional( sigma_slope = 0.2 ) ) )
MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPD", Constant( sigma_inter = 0.1 ) ) )

### Finaly assign the statistical model to the project
MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

### Create a design
MyDesign<- Design()

### For each arm create and add the sampling times for each response
brasTest <- Arm( name="Bras test", arm_size = 100 )
brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.5, 2, 14, 30, 110, 150 ) ) )
brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

brasTest <- setInitialConditions( brasTest, list( "C1" = 0 , "C2" = 0) )
brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPD", sample_time = c(0.5, 2, 14, 30, 110, 150 ) ) )

### Add the arm to the design
MyDesign <- addArm( MyDesign, brasTest )

### Add the design to the project
MyProject <- addDesign( MyProject, MyDesign )

### Create a sampling constraint for response
samplingRespPK <- SamplingConstraint( response = "RespPK" )

### Define the vector of allowed sampling times
samplingRespPK <- allowedDiscretSamplingTimes( samplingRespPK, list(c(0.5 ,2 ,14, 30, 49, 110, 150)) )


### Create a sampling constraint for response
samplingRespPD <- SamplingConstraint( response = "RespPD" )

### Define the vector of allowed sampling times
samplingRespPD <- allowedDiscretSamplingTimes( samplingRespPD, list(c(0.5 ,2 ,14, 30, 49, 110, 150 )) )

### inputs for the FedorovWynn algorithm

initialElementaryProtocols = list( c( 0.5 ,2 ,14, 30, 110, 150 ),
                                   c( 0.5 ,2 ,14, 30, 110, 150 ) )

### Population case
samplingRespPK <- numberOfSamplingTimesIsOptimisable( samplingRespPK, F, c(6) )
samplingRespPD <- numberOfSamplingTimesIsOptimisable( samplingRespPD, F, c(6) )

### Fix certain time values
constr1 <- DesignConstraint( )
constr1 <- addSamplingConstraint(constr1, samplingRespPK)
constr1 <- addSamplingConstraint(constr1, samplingRespPD)

### Create an administration for response
administrationResp <- AdministrationConstraint( response = "RespPK" )
### Define the vector of allowed amount of doses
administrationResp <- AllowedDoses( administrationResp, c(100) )
constr1 <- addAdministrationConstraint( constr1, administrationResp )

### Define the total number of individuals to be considered
constr1 <- setTotalNumberOfIndividuals( constr1, 100 )

### Add the design to the project
MyProject <- setConstraint( MyProject, constr1 )

#Vector of initial proportions or numbers of subjects for each elementary design
numberOfSubjects = c(100)
proportionsOfSubjects = c(100)/100

optimizer <- FedorovWynnAlgorithm( initialElementaryProtocols, numberOfSubjects, proportionsOfSubjects, showProcess = F )

# run optimisation
optimization <- OptimizeDesign( MyProject , optimizer, PopulationFim() )

# print the results of the optimization
resultsFedorovWynnAlgorithm( optimization )

# show result evaluation for the optimal designs
show( optimization )

########################################################################################
# END CODE
########################################################################################

