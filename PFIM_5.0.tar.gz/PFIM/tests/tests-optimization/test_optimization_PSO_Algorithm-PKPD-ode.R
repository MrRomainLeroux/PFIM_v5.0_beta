options(warn=-1)
library(nlme)
library(Deriv)
library(Matrix)
library(ggplot2)
library(deSolve)
library(Rcpp)
library(gtable)
library(grid)

########################################################################################

# Optimisation

# PSO ( Particle Swarm Optimization )

########################################################################################

# -------------------------------------------------
# 1.0 Create PFIM project
# -------------------------------------------------

MyProject<-PFIMProject(name = "Test PFIM")

# -------------------------------------------------
# 2.0 Create the statistical model
# -------------------------------------------------

MyStatisticalModel <- ODEStatisticalModel()

### Create a list of model equations
MyModelEquations <- ModelODEquations( list("RespPK" = expression( C1 ),
                                           "RespPD" = expression( C2 ) ) ,

                                      list("Deriv_C1" = expression( dose_RespPK / ( V ) - Vm * C1/(km + C1) ) ,
                                           "Deriv_C2" = expression(Rin * (1-(Imax*C1)/(C1+C50))-kout*C2 ) ) )

### Assign the equations to the model
MyStatisticalModel <- defineModelEquations( MyStatisticalModel, MyModelEquations )

### Define the variables of the ode model
vC1 <- ModelVariable( "C1" )
vC2 <- ModelVariable( "C2" )

MyStatisticalModel <- defineVariable( MyStatisticalModel, vC1 )
MyStatisticalModel <- defineVariable( MyStatisticalModel, vC2 )

#### Set mu and omega for each parameter

pV = ModelParameter( "V", mu = 12.2,
                     omega = sqrt( 0.25 ),
                     distribution = LogNormalDistribution() )

pVm = ModelParameter( "Vm", mu = 0.082,
                      omega = sqrt( 0.25 ),
                      distribution = LogNormalDistribution() )

pkm = ModelParameter( "km", mu = 0.37,
                      omega = sqrt( 0 ),
                      distribution = LogNormalDistribution() )

pImax = ModelParameter( "Imax", mu = 1.0,
                        omega = sqrt( 0.0 ),
                        distribution = LogNormalDistribution() )

pRin = ModelParameter( "Rin", mu = 5.4,
                       omega = sqrt( 0.2 ),
                       distribution = LogNormalDistribution() )

pkout = ModelParameter( "kout", mu = 0.06,
                        omega = sqrt( 0.02 ),
                        distribution = LogNormalDistribution() )

pC50 = ModelParameter( "C50", mu = 1.2,
                       omega = sqrt( 0.01 ),
                       distribution = LogNormalDistribution() )


### Assign the parameters to the statistical model
MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
MyStatisticalModel = defineParameter( MyStatisticalModel, pVm )
MyStatisticalModel = defineParameter( MyStatisticalModel, pkm )
MyStatisticalModel = defineParameter( MyStatisticalModel, pImax )
MyStatisticalModel = defineParameter( MyStatisticalModel, pRin )
MyStatisticalModel = defineParameter( MyStatisticalModel, pkout )
MyStatisticalModel = defineParameter( MyStatisticalModel, pC50 )

# -------------------------------------------------------------
# 5. Create and add the responses to the statistical model
# -------------------------------------------------------------

MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )
MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPD",  Constant( sigma_inter = 8 ) ) )

MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

# -------------------------------------------------------------
# 6. Create a design
# -------------------------------------------------------------

MyDesign<- Design( name = "MyDesign")

# --------------------------------------------------------------------
# 7. For each arm create and add the sampling times for each response
# --------------------------------------------------------------------

## Arm "Bras test"

brasTest <- Arm( name="Bras test", arm_size = 200 )
brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

# Create a sampling constraint for response

brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 8, 20, 115 ) ) )
samplingBoundsConstraintRespPK <- SamplingConstraint( response = "RespPK", continuousSamplingTimes = list( c( 0,40),c(60, 120 ) ) )
samplingMinimalDelayConstraintRespPK <- SamplingConstraint( response = "RespPK", min_delay = 5 )

brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPD", sample_time = c(2, 12, 30, 118 ) ) )
samplingBoundsConstraintRespPD <- SamplingConstraint( response = "RespPD", continuousSamplingTimes = list( c( 0,40),c(60, 120 ) ) )
samplingMinimalDelayConstraintRespPD <- SamplingConstraint( response = "RespPD", min_delay = 5 )

# Create the Design constraint

Constr1 <- DesignConstraint( )
Constr1 <- addSamplingConstraint( Constr1, samplingBoundsConstraintRespPK )
Constr1 <- addSamplingConstraint( Constr1, samplingMinimalDelayConstraintRespPK )
Constr1 <- addSamplingConstraint( Constr1, samplingBoundsConstraintRespPD )
Constr1 <- addSamplingConstraint( Constr1, samplingMinimalDelayConstraintRespPD )
brasTest<- addSamplingConstraints(brasTest,Constr1)

## Arm "Bras ctrl"

brasctrl <- Arm( name="Bras ctrl", arm_size = 200 )
brasctrl <- addAdministration( brasctrl, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )
brasctrl <- addSampling( brasctrl, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 8, 20, 115 ) ) )

# Create a sampling constraint for response

samplingBoundsConstraintRespPK <- SamplingConstraint( response = "RespPK", continuousSamplingTimes = list( c( 0,40),c(60, 120 ) ) )
samplingMinimalDelayConstraintRespPK <- SamplingConstraint( response = "RespPK", min_delay = 5 )

brasctrl <- addSampling( brasctrl, SamplingTimes( outcome = "RespPD", sample_time = c(2, 12, 30, 118 ) ) )
samplingBoundsConstraintRespPD <- SamplingConstraint( response = "RespPD", continuousSamplingTimes = list( c( 0,40),c(60, 120 ) ) )
samplingMinimalDelayConstraintRespPD <- SamplingConstraint( response = "RespPD", min_delay = 5 )

brasTest <- setInitialConditions( brasTest, list( "C1" = 0 , "C2" = 0) )
brasctrl <- setInitialConditions( brasctrl, list( "C1" = 0 , "C2" = 0) )

# Create the Design constraint

Constr2 <- DesignConstraint( )
Constr2 <- addSamplingConstraint( Constr2, samplingBoundsConstraintRespPK )
Constr2 <- addSamplingConstraint( Constr2, samplingMinimalDelayConstraintRespPK )
Constr2 <- addSamplingConstraint( Constr2, samplingBoundsConstraintRespPD )
Constr2 <- addSamplingConstraint( Constr2, samplingMinimalDelayConstraintRespPD )
brasctrl<- addSamplingConstraints(brasctrl,Constr2)

# Add the arms to the design
MyDesign <- addArm( MyDesign, brasTest )
MyDesign <- addArm( MyDesign, brasctrl )

# Add the design to the project
MyProject <- addDesign( MyProject, MyDesign )

# --------------------------------------------------------------------
# Run the optimization
# --------------------------------------------------------------------

psoOptimizer <- PSOAlgorithm( maxIteration = 20,
                              populationSize = 50,
                              personalLearningCoefficient = 2.05,
                              globalLearningCoefficient = 2.05,
                              showProcess = TRUE )

optimizer1 <- OptimizeDesign( MyProject, psoOptimizer, PopulationFim() )

show( optimizer1 )

plotCriteria( optimizer1 )

modelDescription = "PSO PKPD ODE"
summaryProjectPFIM( optimizer1, modelDescription )

########################################################################################
# END CODE
########################################################################################
