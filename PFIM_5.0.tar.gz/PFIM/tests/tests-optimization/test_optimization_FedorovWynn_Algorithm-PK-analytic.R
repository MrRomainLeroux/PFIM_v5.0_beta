library(nlme)
library(Deriv)
library(Matrix)
library(ggplot2)
library(deSolve)
library(Rcpp)
library(gtable)
library(grid)

########################################################################################

# Optimisation

# Fedorov-Wynn algorithm

########################################################################################

# Create PFIM project
MyProject01<-PFIMProject(name = "Test Optimization FedorovWynn algorithm")

# Create a StatisticalModel
MyStatisticalModel<-StatisticalModel()

# Equations of the model
MyModelEquations = ModelEquations( list( "RespPK" = expression( dose / V * ka/(ka - (Cl/V)) * (exp(-(Cl/V) * t) - exp(-ka * t)) )))
MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyModelEquations )

# Define the parameters of the model
pV = ModelParameter( "V", mu = 3.5,
                     omega = sqrt( 0.09 ),
                     distribution = LogNormalDistribution() )

pCl = ModelParameter( "Cl", mu = 2,
                      omega = sqrt( 0.09 ),
                      distribution = LogNormalDistribution() )

pka = ModelParameter( "ka", mu = 1,
                      omega = sqrt( 0.09 ),
                      distribution = LogNormalDistribution() )

# Assign the parameters to the statistical model
MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

# Add response RespPK to the statistical model
MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

# Add the the statistical model to the project PFIM
MyProject01 = defineStatisticalModel( MyProject01, MyStatisticalModel )

# Create a design
MyDesign<- Design()

# For each arm create and add the sampling times for each response
brasTest <- Arm( name="Bras test", arm_size = 40 )
brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.5, 2,4,6 ) ) )
brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(30) ) )

# Add the arm to the design
MyDesign <- addArm( MyDesign, brasTest )

# Add the design to the project
MyProject01 <- addDesign( MyProject01, MyDesign )

# Create a sampling constraint for response
samplingResp <- SamplingConstraint( response = "RespPK" )

# Define the vector of allowed sampling times
samplingResp <- allowedDiscretSamplingTimes( samplingResp, list(c(0.5,2,4,6,8)) )

# Inputs for the FedorovWynn algorithm
initialElementaryProtocols = list( c( 2.0,6,8 ) )

# Population case
samplingResp <- numberOfSamplingTimesIsOptimisable( samplingResp, F, c(3) )

# Fix certain time values
constr1 <- DesignConstraint(  )
constr1 <- addSamplingConstraint( constr1, samplingResp )

# Create an administration for response
administrationResp <- AdministrationConstraint( response = "RespPK" )

# Define the vector of allowed amount of doses
administrationResp <- AllowedDoses( administrationResp, c(30,50,100) )

# Add the administraton constraint ie doses are optimisable
constr1 <- addAdministrationConstraint( constr1, administrationResp )

# Define the total number of individuals to be considered
constr1 <- setTotalNumberOfIndividuals( constr1, 40 )

# Add the design to the project
MyProject01 <- setConstraint( MyProject01, constr1 )

#Vector of initial proportions or numbers of subjects for each elementary design
numberOfSubjects = c(40)
proportionsOfSubjects = c(100)/100

# run optimisation
optimizer <- FedorovWynnAlgorithm( initialElementaryProtocols, numberOfSubjects, proportionsOfSubjects, showProcess = F )
optimization <- OptimizeDesign( MyProject01 , optimizer, PopulationFim() )

# show result evaluation for the optimal designs
show( optimization )

# create report
modelDescription = "Model PK analytic"
summaryProjectPFIM( optimization, modelDescription )

########################################################################################
# END CODE
########################################################################################
