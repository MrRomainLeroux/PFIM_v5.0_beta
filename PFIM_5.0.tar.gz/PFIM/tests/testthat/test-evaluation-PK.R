library(nlme)
library(Deriv)
library(Matrix)
library(ggplot2)
library(deSolve)
library(Rcpp)
library(gtable)
library(grid)
library(pracma)
library(testthat)
context(" Evaluation : model PK 1cpt - Linear1BolusSingleDose_k ")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1BolusSingleDose_k")

  ### Get equations of the PKPD model
  EquationsPKModel = getEquations(PKModel)

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKModel)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 15,
                       omega = sqrt( 0.1 ),
                       distribution = LogNormalDistribution())

  pk = ModelParameter( "k", mu = 0.25,
                       omega = sqrt( 0.25 ),
                       distribution = LogNormalDistribution())

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 200 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.33, 1.5, 5, 12) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  populationFIM = getFim( MyEvaluationPop )
  detPopulationFim = det( populationFIM )

  valueDetPopulationFim = 2.21558e+14

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

############################################################################################################################

context(" Evaluation : model PK 1cpt : Linear1BolusSingleDose_ClV")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1BolusSingleDose_ClV")

  ### Get equations of the PKPD model
  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKModel )

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 15,
                       omega = sqrt( 0.10 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 3.75,
                        omega = sqrt( 0.25),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 200 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.33, 1.5, 5, 12) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  populationFIM = getFim( MyEvaluationPop )
  detPopulationFim = det( populationFIM )

  valueDetPopulationFim = 6.604172e+12

  tol = 1e-6

  expect_equal( detPopulationFim,valueDetPopulationFim, tol )

})


############################################################################################################################

context(" Evaluation : model PK - Linear1InfusionSingleDose_Vk")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1InfusionSingleDose_Vk")

  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKModel)

  #### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  pk = ModelParameter( "k", mu = 0.6,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )


  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 40 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 4, 8) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2), time_dose = c(0) , amount_dose = c(30) ) )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  populationFIM = getFim( MyEvaluationPop )
  detPopulationFim = det( populationFIM )

  valueDetPopulationFim =  6.39828e+20
  tol = 1e-6
  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

############################################################################################################################

context(" Evaluation model PK 1cpt - Linear1InfusionSingleDose_VCl")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1InfusionSingleDose_VCl")

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKModel)

  #### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 2.0,
                        omega = sqrt( 0.09 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 40 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 4, 8) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2), time_dose = c(0) , amount_dose = c(30) ) )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  populationFIM = getFim( MyEvaluationPop )
  detPopulationFim = det( populationFIM )

  valueDetPopulationFim = 2.307205e+19
  tol = 1e-6
  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

############################################################################################################################

context(" Evaluation model PK 1cpt - Linear1FirstOrderSingleDose_kVCl")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kVCl")

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKModel)

  #### Set mu and omega for each parameter
  pka = ModelParameter( "ka", mu = 2,
                        omega = sqrt( 1 ),
                        distribution = LogNormalDistribution() )

  pk = ModelParameter( "k", mu = 0.25,
                       omega = sqrt( 0.25 ),
                       distribution = LogNormalDistribution() )

  pV = ModelParameter( "V", mu = 15,
                       omega = sqrt( 0.1 ),
                       distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 200 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.33, 1.5, 5, 12) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0) , amount_dose = c(100) ) )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  populationFIM = getFim( MyEvaluationPop )
  detPopulationFim = det( populationFIM )

  valueDetPopulationFim = 2.248478e+15
  tol = 1e-6
  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

############################################################################################################################

context(" Evaluation Model PK 1cpt - Linear1FirstOrderSingleDose_kaVCl")

test_that("", {

  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model

  MyStatisticalModel<-StatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl" )

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKmodel)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 8,
                       omega = sqrt( 0.020 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.13,
                        omega = sqrt( 0.06 ),
                        distribution = LogNormalDistribution() )

  pka = ModelParameter( "ka", mu = 1.6,
                        omega = sqrt( 0.7 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 32 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120 ) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  populationFIM = getFim( MyEvaluationPop )
  #individualFIM = getFim( MyEvaluationInd )

  detPopulationFim = det( populationFIM )
  #detIndividualFim = det( individualFIM )

  #valueDetIndividualFim = 1721283292
  valueDetPopulationFim = 2.423249e+15

  tol = 1e-6

  #expect_equal( detIndividualFim,valueDetIndividualFim, tol )
  expect_equal( detPopulationFim,valueDetPopulationFim, tol )

})

############################################################################################################################

context(" Evaluation : model PK 1cpt - Linear1FirstOrderSingleDose_kaVCl (BayesianFIM instead of PopulationFIM)")

test_that("", {

  ### Create a project
  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model

  MyStatisticalModel<-StatisticalModel()

  ### Defineequations of the model
  # Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl" )

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKmodel)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 8,
                       omega = sqrt( 0.020 ),
                       distribution = NormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.13,
                        omega = sqrt( 0.06 ),
                        distribution = NormalDistribution() )

  pka = ModelParameter( "ka", mu = 1.6,
                        omega = sqrt( 0.7 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 1 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120 ) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the IndividualFIM
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationBayes <- EvaluateBayesianFIM( MyProject )

  matrixFisherIndividualFIM = getFim( MyEvaluationInd )
  matrixFisherBayesianFIM = getFim( MyEvaluationBayes )

  detIndividualFim = det( matrixFisherIndividualFIM )
  detBayesianFim = det( matrixFisherBayesianFIM )

  valueDetIndividualFim = 1721283292
  valueDetBayesianFim = 1.313702e+12

  tol = 1e-6

  expect_equal( detIndividualFim,valueDetIndividualFim, tol)
  expect_equal( detBayesianFim,valueDetBayesianFim, tol)

})

###################################################################################################################################

context(" Evaluation model : PK 1cpt - Linear1InfusionSingleDose_kVCl ")

test_that("", {

  ### Create a project
  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Assign the equations to the statistical model
  Linear1InfusionSingleDose_kVCl <- getModel( PFIMLibraryOfModels, "Linear1InfusionSingleDose_kVCl" )

  MyStatisticalModel = defineModelEquations( MyStatisticalModel, Linear1InfusionSingleDose_kVCl )

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 2,
                        omega = sqrt( 0.09 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 40 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0, 1,2,5,7,8, 10,12,14, 15, 16, 20, 21, 30) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2), tau=c(12) , amount_dose = c(30,50,30,50) ) )     #brasTest <- addAdministration( brasTest, Administration( outcome = "Resp1", tinf=c(2,2,3,3), amount_dose = [100][c(30,30,50,50)] )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  matrixFisherPopulationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 1.77481e+24

  tol = 1e-6
  expect_equal(valueDetPopulationFim,detPopulationFim, tol)

})

###################################################################################################################################

context(" Evaluation : model PK 1cpt - Linear1InfusionSingleDose_kVCl")

test_that("", {

  ### Create a project
  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Assign the equations to the statistical model
  MyPKPDModel <- getModel( PFIMLibraryOfModels, "Linear1InfusionSingleDose_kVCl" )
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, MyPKPDModel)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 2,
                        omega = sqrt( 0.09 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model

  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 40 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0, 1,2,5,7,8, 10,12,14, 15, 16, 20, 21, 27, 30) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2,4,4,2), time_dose=c(0,12,28,40) , amount_dose = c(30,50,30,50) ) )     #brasTest <- addAdministration( brasTest, Administration( outcome = "Resp1", tinf=c(2,2,3,3), amount_dose = [100][c(30,30,50,50)] )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  matrixFisherPopulationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 6.065733e+23

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###################################################################################################################################

context("Evaluation model PK 1cpt - Linear1FirstOrderSingleDose_kaVCl")

test_that("", {

  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl" )
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKmodel )

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 8,
                       omega = sqrt( 0.020 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.13,
                        omega = sqrt( 0.06 ),
                        distribution = LogNormalDistribution() )

  pka = ModelParameter( "ka", mu = 1.6,
                        omega = sqrt( 0.7 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 32 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120 ) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  ### Evaluate the Fisher Information Matrix for the IndividualFIM
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  matrixFisherIndividualFIM = getFim(MyEvaluationInd)
  matrixFisherPopulationFIM = getFim(MyEvaluationPop)

  detIndividualFim = det(matrixFisherIndividualFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)

  valueDetIndividualFim = 1721283292
  valueDetPopulationFim = 2.423249e+15

  tol = 1e-6

  expect_equal(detIndividualFim,valueDetIndividualFim, tol)
  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###################################################################################################################################

context(" Evaluation model PK 1cpt - Linear1FirstOrderSingleDose_kaVCl")

test_that("", {

  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl" )
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKmodel)

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 8,
                       omega = sqrt( 0.020 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.13,
                        omega = sqrt( 0.06 ),
                        distribution = LogNormalDistribution() )

  pka = ModelParameter( "ka", mu = 1.6,
                        omega = sqrt( 0.7 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 32 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c( 0.5, 1, 2, 6, 12, 48, 72, 120, 165, 220 ) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0, 80, 160), amount_dose = c(100,100,100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the IndividualFIM
  MyEvaluationInd <- EvaluateIndividualFIM( MyProject )
  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  matrixFisherIndividualFIM = getFim(MyEvaluationInd)
  matrixFisherPopulationFIM = getFim(MyEvaluationPop)

  detIndividualFim = det(matrixFisherIndividualFIM)
  detPopulationFim = det(matrixFisherPopulationFIM)

  valueDetIndividualFim = 215057976
  valueDetPopulationFim = 1.875234e+14

  tol = 1e-6
  expect_equal( detIndividualFim,valueDetIndividualFim, tol )
  expect_equal( detPopulationFim,valueDetPopulationFim, tol )

})

###################################################################################################################################

context(" Evaluation model PK 2cpts - Linear2BolusSingleDose_ClQV1V2")

test_that("", {

  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear2BolusSingleDose_ClQV1V2" )

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKmodel )

  ### Set mu and omega for each parameter
  pCl = ModelParameter( "Cl", mu = 0.4,
                        omega = sqrt( 0.2 ),
                        distribution = LogNormalDistribution() )

  pV1 = ModelParameter( "V1", mu = 10,
                        omega = sqrt( 0.1 ),
                        distribution = LogNormalDistribution() )

  pQ = ModelParameter( "Q", mu = 2,
                       omega = sqrt( 0.05 ),
                       distribution = LogNormalDistribution() )

  pV2 = ModelParameter( "V2", mu = 50,
                        omega = sqrt( 0.4 ),
                        distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV1 )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pQ )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV2 )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 32 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120)  ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  matrixFisherPopulationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 4.949067e+15

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})


###################################################################################################################################

context(" Evaluation model PK 2cpts - Linear2BolusSingleDose_ClVkk12k21")

test_that("", {

  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model

  MyStatisticalModel<-StatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "Linear2BolusSingleDose_ClVkk12k21" )
  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKmodel )

  ### Set mu and omega for each parameter
  pk = ModelParameter( "k", mu = 0.25,
                       omega = sqrt( 0.25 ),
                       distribution = LogNormalDistribution() )

  pV = ModelParameter( "V", mu = 15.00,
                       omega = sqrt( 0.10 ),
                       distribution = LogNormalDistribution() )

  pk12 = ModelParameter( "k12", mu = 1.00,
                         omega = sqrt( 0.4 ),
                         distribution = LogNormalDistribution() )

  pk21 = ModelParameter( "k21", mu = 0.80,
                         omega = sqrt( 0.3 ),
                         distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk12 )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk21 )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 200 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.33, 1.5, 3, 5, 8, 12)  ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  matrixFisherPopulationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim =  1.109796e+20

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)


})

###################################################################################################################################

context(" Evaluation model PK 1cpt - MichaelisMentenFirstOrderSingleDose_VmKmC")

test_that("", {

  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model

  MyStatisticalModel<-ODEStatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "MichaelisMentenFirstOrderSingleDose_VmKmC")
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKmodel )

  ### Define the variables of the ode model
  vC1 <- ModelVariable( "C1" )
  MyModel = defineVariable( MyStatisticalModel, vC1 )

  ### Set fixed effects (mu), standard deviation of random effects (omega) and distribution of each parameter
  pka <- ModelParameter( "ka", mu = 1.00,
                         omega = sqrt( 0.20 ),
                         distribution = LogNormalDistribution() )

  pV <- ModelParameter( "V", mu = 15.00,
                        omega = sqrt( 0.25 ),
                        distribution = LogNormalDistribution() )

  pVm <- ModelParameter( "Vm", mu = 0.08,
                         omega = sqrt( 0.10 ),
                         distribution = LogNormalDistribution() )

  pKm <- ModelParameter( "Km", mu = 0.40,
                         omega = sqrt( 0.30 ),
                         distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel <- defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel <- defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel <- defineParameter( MyStatisticalModel, pVm )
  MyStatisticalModel <- defineParameter( MyStatisticalModel, pKm )

  ### Error model (standard deviations)
  MyModel <- addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

  ### Assign the model to the project
  MyProject <- defineStatisticalModel( MyProject, MyModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 200, cond_init=list( "C1"=0 ))
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK",
                                                    sample_time = c(0, 0.33, 1.5, 3, 5, 8, 11, 12),
                                                    initialTime = 0 ) )

  brasTest <- setInitialConditions( brasTest, list( "C1"=0.0) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  matrixFisherPopulationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 4.034142e-06

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###################################################################################################################################

context(" Model PK 1cpt : MichaelisMentenBolusSingleDose_VmKmC")

test_that("", {

  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model

  MyStatisticalModel<-ODEStatisticalModel()

  ###  Get Equations models
  PKmodel <- getModel( PFIMLibraryOfModels, "MichaelisMentenBolusSingleDose_VmKmC")
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKmodel )

  ### Define the variables of the ode model
  vC1 <- ModelVariable( "C1" )
  MyModel = defineVariable( MyStatisticalModel, vC1 )

  ### Set fixed effects (mu), standard deviation of random effects (omega) and distribution of each parameter
  pV <- ModelParameter( "V", mu = 15.00,
                        omega = sqrt( 0.25 ),
                        distribution = LogNormalDistribution() )

  pVm <- ModelParameter( "Vm", mu = 0.08,
                         omega = sqrt( 0.10 ),
                         distribution = LogNormalDistribution() )

  pKm <- ModelParameter( "Km", mu = 0.40,
                         omega = sqrt( 0.30 ),
                         distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel <- defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel <- defineParameter( MyStatisticalModel, pVm )
  MyStatisticalModel <- defineParameter( MyStatisticalModel, pKm )

  ### Error model (standard deviations)
  MyModel <- addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.5, sigma_slope = 0.15 ) ) )

  ### Assign the model to the project
  MyProject <- defineStatisticalModel( MyProject, MyModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response
  brasTest <- Arm( name="Bras test", arm_size = 200)

  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK",
                                                    sample_time = c(0, 0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120),
                                                    initialTime = 0 ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0), amount_dose = c(100) ) )

  brasTest <- setInitialConditions( brasTest, list( "C1"= expression( dose_RespPK /V) ) )

  ### Add the arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  matrixFisherPopulationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 78983374

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###################################################################################################################################

context(" Model PK 1cpt : Linear1FirstOrderSingleDose_kaVCl")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl")

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKModel)


  #### Set mu and omega for each parameter
  pka = ModelParameter( "ka", mu = 1.050,
                        omega = sqrt( 0.1 ),
                        distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.513,
                        omega = 0,
                        distribution = LogNormalDistribution() )

  pV = ModelParameter( "V", mu = 63.000,
                       omega = 0,
                       distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl  )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0, sigma_slope = 0.0676 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 25 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.01, 1, 3, 5, 7, 10, 13, 17, 24) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0) , amount_dose = c(5500) ) )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the IndividualFIM
  #MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  #matrixFisherIndividualFIM = getFim(MyEvaluationInd)
  #detIndividualFim = det(matrixFisherIndividualFIM)
  #valueDetIndividualFim = 1721283292

  matrixFisherPopulationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 1.170789e+13

  tol = 1e-6

  #♠expect_equal(detIndividualFim,valueDetIndividualFim, tol)
  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###################################################################################################################################

context(" Evaluation model PK 1cpt - Linear1FirstOrderSingleDose_kaVCl")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1FirstOrderSingleDose_kaVCl")

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKModel)


  #### Set mu and omega for each parameter
  pka = ModelParameter( "ka", mu = 1.0,
                        omega = sqrt( 0.09 ),
                        distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 2.0,
                        omega = sqrt( 0.09 ),
                        distribution = LogNormalDistribution() )

  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl  )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 40 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 4, 8, 12.5, 13, 16, 20, 24.5, 25, 28, 32, 36.5, 37, 40, 44, 48.5, 49, 52, 56) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", time_dose = c(0,12,24,36,48) , amount_dose = c(30) ) )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the IndividualFIM
  #MyEvaluationInd <- EvaluateIndividualFIM( MyProject )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  matrixFisherPopulationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 4.301907e+25

  tol = 1e-6

  expect_equal( detPopulationFim,valueDetPopulationFim, tol)

})

###################################################################################################################################

context(" Evaluation model PK 1cpt - Linear1FirstOrderSteadyState_kaVCltau")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIMProject(name = "Test PFIM")

  ### Create the statistical model
  MyStatisticalModel<-StatisticalModel()

  ### Create PK model
  PKModel = getModel(PFIMLibraryOfModels, "Linear1FirstOrderSteadyState_kaVCltau")

  ### Assign the equations to the statistical model
  MyStatisticalModel = defineModelEquations( MyStatisticalModel, PKModel)

  ### Set mu and omega for each parameter
  pka = ModelParameter( "ka", mu = 1.050,
                        omega = sqrt( 0.1 ),
                        distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.513,
                        omega = 0,
                        distribution = LogNormalDistribution() )

  pV = ModelParameter( "V", mu = 63.000,
                       omega = 0,
                       distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pka )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl  )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.0, sigma_slope = 0.0676 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design

  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 25 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.01, 1, 3, 5, 7, 10, 13, 17, 24) ) )
  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK",
                                                           tau = c(24),
                                                           amount_dose = c(50 ) )   )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  matrixFisherPopulationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 2.938767e+15

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###########################################################################################
# END CODE
###########################################################################################


