library(nlme)
library(Deriv)
library(Matrix)
library(ggplot2)
library(deSolve)
library(Rcpp)
library(gtable)
library(grid)
library(pracma)
library(testthat)

context(" Evaluation : Model PK ODE Infusion - 01")

test_that("", {

  ### Create PFIM project
  MyProject <- PFIMProject(name = "Test PFIM")

  ### Create the ODE model
  MyStatisticalModel <- ODEStatisticalModel()

  ### Create a list of model equations
  MyModelEquations <- ModelInfusionODEquations( list("DuringInfusion_RespPK" = expression( C1 ) ) ,

                                                list( "AfterInfusion_RespPK"  = expression( C1 ) ),

                                                list("Deriv_DuringInfusion_C1" = expression( dose_RespPK / ( V * Tinf_RespPK ) - k * C1 ) ),

                                                list("Deriv_AfterInfusion_C1" = expression( -k * C1 ) ) )

  MyStatisticalModel <- defineModelEquations( MyStatisticalModel, MyModelEquations )


  ### Define the variables of the ode model
  vC1 <- ModelVariable( "C1" )
  MyStatisticalModel <- defineVariable( MyStatisticalModel, vC1 )

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  pk = ModelParameter( "k", mu = 0.6,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 40 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 4, 8) ) )

  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2), time_dose = c(0) , amount_dose = c(30) ) )

  ### Initial conditions
  brasTest <- setInitialConditions( brasTest, list( "C1" = 0 ) )

  ### Add arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  populationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(populationFIM)

  valueDetPopulationFim = 2.205257e+23

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###########################################################################################

context(" Evaluation : Model PK ODE Infusion - 02")

test_that("", {

  ### Create PFIM project
  MyProject <- PFIMProject(name = "Test PFIM")

  ### Create the ODE model
  MyStatisticalModel <- ODEStatisticalModel()

  ### Create a list of model equations
  MyModelEquations <- ModelInfusionODEquations( list("DuringInfusion_RespPK" = expression( C1 ) ) ,

                                                list( "AfterInfusion_RespPK"  = expression( C1 ) ),

                                                list("Deriv_DuringInfusion_C1" = expression( dose_RespPK / ( V * Tinf_RespPK ) - k * C1 ) ),

                                                list("Deriv_AfterInfusion_C1" = expression( -k * C1 ) ) )

  MyStatisticalModel <- defineModelEquations( MyStatisticalModel, MyModelEquations )


  ### Define the variables of the ode model
  vC1 <- ModelVariable( "C1" )
  MyStatisticalModel <- defineVariable( MyStatisticalModel, vC1 )

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  pk = ModelParameter( "k", mu = 0.6,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 40 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 4, 8) ) )

  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2,3), time_dose = c(0,5) , amount_dose = c(30,50) ) )

  ### Initial conditions
  brasTest <- setInitialConditions( brasTest, list( "C1" = 0 ) )

  ### Add arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  populationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(populationFIM)

  valueDetPopulationFim = 1.12679e+17

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###########################################################################################

context(" Evaluation : Model PK ODE Infusion - 03")

test_that("", {

  ### Create PFIM project
  MyProject <- PFIMProject(name = "Test PFIM")

  ### Create the ODE model
  MyStatisticalModel <- ODEStatisticalModel()

  ### Create a list of model equations
  MyModelEquations <- ModelInfusionODEquations( list("DuringInfusion_RespPK" = expression( C1 ) ) ,

                                                list( "AfterInfusion_RespPK"  = expression( C1 ) ),

                                                list("Deriv_DuringInfusion_C1" = expression( dose_RespPK / ( V * Tinf_RespPK ) - k * C1 ) ),

                                                list("Deriv_AfterInfusion_C1" = expression( -k * C1 ) ) )

  MyStatisticalModel <- defineModelEquations( MyStatisticalModel, MyModelEquations )


  ### Define the variables of the ode model
  vC1 <- ModelVariable( "C1" )
  MyStatisticalModel <- defineVariable( MyStatisticalModel, vC1 )

  ### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 3.5,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  pk = ModelParameter( "k", mu = 0.6,
                       omega = sqrt( 0.09 ),
                       distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pk )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.1, sigma_slope = 0.1 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design()

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 40 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK", sample_time = c(0.5, 1, 4, 8) ) )

  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2), tau = 3 , amount_dose = c(30) ) )
  ### Initial conditions
  brasTest <- setInitialConditions( brasTest, list( "C1" = 0 ) )

  ### Add arm to the design
  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )

  populationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(populationFIM)

  valueDetPopulationFim = 1.562609e+13

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###########################################################################################

context(" Evaluation : Model PKPD ODE Infusion ")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIMProject(name = "Test PFIM")

  MyStatisticalModel <- ODEStatisticalModel()

  ### Create a list of model equations
  MyModelEquations <- ModelInfusionODEquations( list("DuringInfusion_RespPK" = expression( C1 ),
                                                     "DuringInfusion_RespPD" = expression( C2) ) ,

                                                list( "AfterInfusion_RespPK"  = expression( C1 ),
                                                      "AfterInfusion_RespPD"  = expression( C2 ) ),

                                                list("Deriv_DuringInfusion_C1" = expression( dose_RespPK / ( V * Tinf_RespPK ) - (Cl/V) * C1 ) ,
                                                     "Deriv_DuringInfusion_C2" = expression(Rin * (1-(Imax*C1)/(C1+C50))-kout*C2 ) ),

                                                list("Deriv_AfterInfusion_C1" = expression( -(Cl/V) * C1 ),
                                                     "Deriv_AfterInfusion_C2" = expression(Rin * (1-Imax*C1/(C1+C50))-kout*C2 ) ) )

  ### Assign the equations to the model
  MyStatisticalModel <- defineModelEquations( MyStatisticalModel, MyModelEquations )

  ### Define the variables of the ode model
  vC1 <- ModelVariable( "C1" )
  vC2 <- ModelVariable( "C2" )

  MyStatisticalModel <- defineVariable( MyStatisticalModel, vC1 )
  MyStatisticalModel <- defineVariable( MyStatisticalModel, vC2 )

  #### Set mu and omega for each parameter
  pV = ModelParameter( "V", mu = 8.0,
                       omega = sqrt( 0.02 ),
                       distribution = LogNormalDistribution() )

  pCl = ModelParameter( "Cl", mu = 0.13,
                        omega = sqrt( 0.06 ),
                        distribution = LogNormalDistribution() )

  pImax = ModelParameter( "Imax", mu = 1.0,
                          omega = sqrt( 0.0 ),
                          distribution = LogNormalDistribution() )

  pRin = ModelParameter( "Rin", mu = 5.4,
                         omega = sqrt( 0.2 ),
                         distribution = LogNormalDistribution() )

  pkout = ModelParameter( "kout", mu = 0.06,
                          omega = sqrt( 0.02 ),
                          distribution = LogNormalDistribution() )

  pC50 = ModelParameter( "C50", mu = 1.2,
                         omega = sqrt( 0.01 ),
                         distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCl )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pImax )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pRin )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pkout )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pC50 )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPD", Constant( sigma_inter = 4.0 ) ) )

  ### Finaly assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design("MyDesign")

  ### For each arm create and add the sampling times for each response

  brasTest <- Arm( name="Bras test", arm_size = 32 )

  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK",
                                                    sample_time = c( 0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120 ) ) )

  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPD", sample_time = c( 0, 2, 6, 11, 24, 36, 48, 72, 96, 120, 144 ) ) )

  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK", Tinf=c(2),
                                                           time_dose = c(0) , amount_dose = c( 100 ) ) )

  brasTest <- setInitialConditions( brasTest, list( "C1" = 0, "C2" = expression(Rin/kout) ) )

  MyDesign <- addArm( MyDesign, brasTest )

  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evaluate the Fisher Information Matrix for the PopulationFIM
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  matrixFisherPopulationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(matrixFisherPopulationFIM)
  valueDetPopulationFim = 42208896611

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###########################################################################################

context(" Evaluation : Model PKPKPD ODE Infusion ")

test_that("", {

  ### Create PFIM project
  MyProject<-PFIMProject(name = "Test PFIM PKPKPD ODE Infusion")

  MyStatisticalModel <- ODEStatisticalModel()

  ### Create a list of model equations
  MyModelEquations <- ModelInfusionODEquations( list("DuringInfusion_RespPK1" = expression( C1 ),
                                                     "DuringInfusion_RespPK2" = expression( C2 ),
                                                     "DuringInfusion_RespPD"  = expression( C3 ) ),

                                                list( "AfterInfusion_RespPK1"  = expression( C1 ),
                                                      "AfterInfusion_RespPK2"  = expression( C2 ),
                                                      "AfterInfusion_RespPD"  = expression( C3 ) ),

                                                list("Deriv_DuringInfusion_C1" =  expression( dose_RespPK1/(Tinf_RespPK1*V1) - (CL1/V1)*C1 )  ,
                                                     "Deriv_DuringInfusion_C1" =  expression( dose_RespPK2/(Tinf_RespPK2*V2) - (CL2/V2)*C2 )  ,
                                                     "Deriv_DuringInfusion_C3" =  expression( Rin*( 1 - (Imax1*C1)/(C1+C501) - (Imax2*C2)/(C2+C502) )-kout*C3 ) ),

                                                list("Deriv_AfterInfusion_C1" =  expression( -(CL1/V1)*C1 ) ,
                                                     "Deriv_AfterInfusion_C2" =  expression( -(CL2/V2)*C2 ) ,
                                                     "Deriv_AfterInfusion_C3" = expression( Rin*( 1 - (Imax1*C1)/(C1+C501) - (Imax2*C2)/(C2+C502) )-kout*C3 ) ) )

  ### Assign the equations to the model
  MyStatisticalModel <- defineModelEquations( MyStatisticalModel, MyModelEquations )

  ### Define the variables of the ode model
  vC1 <- ModelVariable( "C1" )
  vC2 <- ModelVariable( "C2" )
  vC3 <- ModelVariable( "C3" )

  MyStatisticalModel <- defineVariable( MyStatisticalModel, vC1 )
  MyStatisticalModel <- defineVariable( MyStatisticalModel, vC2 )
  MyStatisticalModel <- defineVariable( MyStatisticalModel, vC3 )

  #### Set mu and omega for each parameter

  pC501 = ModelParameter( "C501", mu = 1.2,
                          omega = sqrt( 0.01 ),
                          distribution = LogNormalDistribution() )

  pC502 = ModelParameter( "C502", mu = 3.0,
                          omega = sqrt( 0.05 ),
                          distribution = LogNormalDistribution() )

  pV1 = ModelParameter( "V1", mu = 8.0,
                        omega = sqrt( 0.02 ),
                        distribution = LogNormalDistribution() )

  pV2 = ModelParameter( "V2", mu = 15.0,
                        omega = sqrt( 0.1 ),
                        distribution = LogNormalDistribution() )

  pCL1 = ModelParameter( "CL1", mu = 0.13,
                         omega = sqrt( 0.06 ),
                         distribution = LogNormalDistribution() )

  pCL2 = ModelParameter( "CL2", mu = 0.60,
                         omega = sqrt( 0.2 ),
                         distribution = LogNormalDistribution() )

  pRin = ModelParameter( "Rin", mu = 5.40,
                         omega = sqrt( 0.2 ),
                         distribution = LogNormalDistribution() )

  pkout = ModelParameter( "kout", mu = 0.06,
                          omega = sqrt( 0.02 ),
                          distribution = LogNormalDistribution() )

  pImax1 = ModelParameter( "Imax1", mu = 0.8,
                           omega = sqrt( 0 ),
                           distribution = LogNormalDistribution() )

  pImax2 = ModelParameter( "Imax2", mu = 0.2,
                           omega = sqrt( 0 ),
                           distribution = LogNormalDistribution() )

  ### Assign the parameters to the statistical model
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV1 )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pV2 )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCL1 )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pCL2 )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pRin )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pkout )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pImax1 )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pImax2 )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pC501 )
  MyStatisticalModel = defineParameter( MyStatisticalModel, pC502 )

  ### Create and add the responses to the statistical model
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK1", Combined1( sigma_inter = 0.6, sigma_slope = 0.07 ) ) )
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPK2", Combined1( sigma_inter = 0.0, sigma_slope = 0.15 ) ) )
  MyStatisticalModel = addResponse( MyStatisticalModel, Response( "RespPD", Constant( sigma_inter = 4.0 ) ) )

  ### Finally assign the statistical model to the project
  MyProject = defineStatisticalModel( MyProject, MyStatisticalModel )

  ### Create a design
  MyDesign<- Design("MyDesign")

  brasTest <- Arm( name="Bras test", arm_size = 32 )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK1",
                                                    sample_time = c( 0.5, 1, 2, 6, 9, 12, 24, 36, 48, 72, 96, 120 ) ) )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPK2",
                                                    sample_time = c( 0.5, 1, 2, 4, 6, 12, 24, 36, 48, 72, 96, 120 ) ) )
  brasTest <- addSampling( brasTest, SamplingTimes( outcome = "RespPD",
                                                    sample_time = c( 0, 24, 36, 48, 72, 96, 120, 144 ) ) )

  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK1",
                                                           Tinf=c(2), time_dose = c(0) , amount_dose = c( 100 ) ) )

  brasTest <- addAdministration( brasTest, Administration( outcome = "RespPK2",
                                                           Tinf=c(4), time_dose = c(0) , amount_dose = c( 150 ) ) )

  # Initial conditions
  brasTest <- setInitialConditions( brasTest, list( "C1" = 0, "C2" = 0, "C3" = expression(Rin/kout) ) )

  ### Design
  MyDesign <- addArm( MyDesign, brasTest )
  ### Add the design to the project
  MyProject <- addDesign( MyProject, MyDesign )

  ### Evalusation of the model
  MyEvaluationPop <- EvaluatePopulationFIM( MyProject )
  matrixFisherPopulationFIM = getFim(MyEvaluationPop)
  detPopulationFim = det(matrixFisherPopulationFIM)

  valueDetPopulationFim = 32589.29

  tol = 1e-6

  expect_equal(detPopulationFim,valueDetPopulationFim, tol)

})

###########################################################################################
# END CODE
###########################################################################################






